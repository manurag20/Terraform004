import os
import sys
import json
import time
import threading
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

# Global flag to signal across execution threads when the timer runs out
exam_forced_complete = False

class QuizEngine:
    def __init__(self, json_path="questions.json", duration_minutes=60):
        self.json_path = json_path
        self.duration_minutes = duration_minutes
        self.questions = []
        self.user_answers = {}  # Map: question_id -> user_choice_string
        self.score = 0
        self.start_time = 0
        
    def load_questions(self):
        if not os.path.exists(self.json_path):
            print(f"[!] Error: System configuration file '{self.json_path}' not found.")
            sys.exit(1)
        with open(self.json_path, "r", encoding="utf-8") as f:
            self.questions = json.load(f)

    def countdown_timer(self):
        global exam_forced_complete
        total_seconds = self.duration_minutes * 60
        while time.time() - self.start_time < total_seconds:
            if exam_forced_complete:
                return
            time.sleep(1)
        
        if not exam_forced_complete:
            exam_forced_complete = True
            print("\n\n" + "!"*70)
            print(" [!] TIME LIMIT EXPIRED! (60 Minutes Concluded) ")
            print("!"*70)
            print("Press [ENTER] to lock state and generate your performance diagnostic report...")

    def run_exam(self):
        global exam_forced_complete
        self.load_questions()
        
        print("=" * 75)
        print("     HASHICORP TERRAFORM ASSOCIATE (TA-004) COMPLIANCE SIMULATOR")
        print("=" * 75)
        print(f" * Total Volumetric Questions: {len(self.questions)}")
        print(f" * Hard Allocation Timer limit: {self.duration_minutes} Minutes")
        print(" * Input Directives: [A, B, C, D] | [S] to Skip | [EXIT] to abort early")
        print("-" * 75)
        input("Press [ENTER] to lock state backend and begin the exam timer...")
        
        self.start_time = time.time()
        
        # Spawn asynchronous background timer thread
        timer_thread = threading.Thread(target=self.countdown_timer, daemon=True)
        timer_thread.start()
        
        for idx, q in enumerate(self.questions):
            if exam_forced_complete:
                break
                
            print(f"\n[Question {idx + 1} of {len(self.questions)}] (ID: {q['id']})")
            print(q['question'])
            for key, val in q['options'].items():
                print(f"  {key}) {val}")
                
            choice = ""
            while True:
                if exam_forced_complete:
                    break
                choice = input("\nYour Answer: ").strip().upper()
                if choice in ["A", "B", "C", "D", "S", "EXIT"]:
                    break
                print("Invalid operational flag. Choose [A, B, C, D, S, EXIT].")
                
            if exam_forced_complete or choice == "EXIT":
                break
                
            self.user_answers[q['id']] = choice
            if choice == "S":
                print("Question skipped and tagged.")
            else:
                print("Choice logged successfully.")
                
        exam_forced_complete = True
        self.evaluate_and_report()

    def evaluate_and_report(self):
        wrong_records = []
        skipped_records = []
        
        for q in self.questions:
            user_ans = self.user_answers.get(q['id'], "S")  # If unanswered due to timeout, mark as skipped
            if user_ans == "S":
                skipped_records.append(q)
            elif user_ans == q['answer']:
                self.score += 1
            else:
                wrong_records.append((q, user_ans))
                
        total_q = len(self.questions)
        pct = (self.score / total_q) * 100 if total_q > 0 else 0
        status = "PASSED" if pct >= 70.0 else "FAILED"
        
        print("\n" + "="*75)
        print("                    EXAM CONCLUDED ENGINE REPORT")
        print("="*75)
        print(f" Final Evaluation Score: {self.score} / {total_q} ({pct:.2f}%)")
        print(f" Exam Target Benchmark: 70.00% | Operational Metric: {status}")
        print(f" Summary: Correct: {self.score} | Incorrect: {len(wrong_records)} | Skipped: {len(skipped_records)}")
        
        pdf_filename = "terraform_exam_report.pdf"
        self.generate_pdf_report(pdf_filename, pct, status, wrong_records, skipped_records)
        print(f"\n[+] Comprehensive analytical report generated successfully: '{pdf_filename}'")
        print("="*75)

    def generate_pdf_report(self, filename, pct, status, wrong_records, skipped_records):
        doc = SimpleDocTemplate(filename, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
        story = []
        
        styles = getSampleStyleSheet()
        # Custom styling setup for professional look
        title_style = ParagraphStyle('DocTitle', parent=styles['Heading1'], fontSize=22, textColor=colors.HexColor("#5C4EE5"), spaceAfter=15)
        meta_style = ParagraphStyle('MetaText', parent=styles['Normal'], fontSize=11, spaceAfter=6)
        heading_style = ParagraphStyle('SectionHeading', parent=styles['Heading2'], fontSize=14, textColor=colors.HexColor("#1A1A1A"), spaceBefore=15, spaceAfter=10)
        body_style = ParagraphStyle('Body', parent=styles['Normal'], fontSize=10, leading=14)
        bold_body = ParagraphStyle('BoldBody', parent=body_style, fontName='Helvetica-Bold')
        expl_style = ParagraphStyle('Expl', parent=body_style, textColor=colors.HexColor("#2E7D32"))

        # Header Section
        story.append(Paragraph("HashiCorp Certified: Terraform Associate Performance Summary", title_style))
        story.append(Spacer(1, 10))
        
        # Metric Table Block
        summary_data = [
            [Paragraph("<b>Metric</b>", body_style), Paragraph("<b>Value Output</b>", body_style)],
            [Paragraph("Overall Score Evaluation", body_style), Paragraph(f"{self.score} / {len(self.questions)}", bold_body)],
            [Paragraph("Percentage Attained", body_style), Paragraph(f"{pct:.2f}%", bold_body)],
            [Paragraph("Passing Threshold", body_style), Paragraph("70.00%", body_style)],
            [Paragraph("Operational Status", body_style), Paragraph(status, ParagraphStyle('Status', parent=bold_body, textColor=colors.HexColor("#D32F2F") if status == "FAILED" else colors.HexColor("#388E3C")))]
        ]
        t = Table(summary_data, colWidths=[200, 300])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (1,0), colors.HexColor("#F5F5F5")),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#DDDDDD")),
            ('PADDING', (0,0), (-1,-1), 6),
        ]))
        story.append(t)
        story.append(Spacer(1, 15))
        
        # Incorrect Questions Segment
        if wrong_records:
            story.append(Paragraph("Diagnostic Review: Incorrectly Answered Questions", heading_style))
            for q, user_ans in wrong_records:
                story.append(Paragraph(f"<b>Question ID {q['id']}:</b> {q['question']}", body_style))
                story.append(Spacer(1, 4))
                # Build option rows
                for key, val in q['options'].items():
                    story.append(Paragraph(f"  {key}) {val}", body_style))
                story.append(Spacer(1, 4))
                story.append(Paragraph(f"<b>Your Selection:</b> {user_ans} | <b>Target True Answer:</b> {q['answer']}", ParagraphStyle('FailLine', parent=body_style, textColor=colors.HexColor("#C62828"))))
                story.append(Paragraph(f"<b>Architectural Explanation:</b> {q['explanation']}", expl_style))
                story.append(Spacer(1, 12))
                
        # Skipped Questions Segment
        if skipped_records:
            story.append(Paragraph("Diagnostic Review: Skipped / Timeout Questions", heading_style))
            for q in skipped_records:
                story.append(Paragraph(f"<b>Question ID {q['id']}:</b> {q['question']}", body_style))
                story.append(Spacer(1, 4))
                for key, val in q['options'].items():
                    story.append(Paragraph(f"  {key}) {val}", body_style))
                story.append(Spacer(1, 4))
                story.append(Paragraph(f"<b>Target True Answer:</b> {q['answer']}", bold_body))
                story.append(Paragraph(f"<b>Architectural Explanation:</b> {q['explanation']}", expl_style))
                story.append(Spacer(1, 12))

        doc.build(story)

if __name__ == "__main__":
    engine = QuizEngine(json_path="questions.json", duration_minutes=60)
    engine.run_exam()