# Terraform Associate 004 - Mock Question Bank
**Batches 1-4 combined (Q1-270)** - Batch 4 targets recurring multi-attempt gaps (console, sensitive, implicit any type, destroy -target, module addressing, state mv vs refresh, complex types, conditional creation idiom) plus two verified-new 004 topics: ephemeral values/write-only arguments (Terraform 1.10/1.11) and the declarative import block (Terraform 1.5+/1.7+).

Question types used: Multiple Choice, Scenario-based, Code/Config snippet, True/False

---

## Domain 1: Understand Infrastructure as Code (IaC) Concepts (~5%)

**Q1.** [Multiple Choice] What is the main advantage of IaC over manually provisioning infrastructure through a cloud console?
A) It removes the need for a cloud provider account
B) It makes infrastructure changes repeatable, versionable, and auditable
C) It guarantees zero downtime deployments
D) It eliminates the need for a state file

**Q2.** [Multiple Choice] Which of the following is NOT typically a benefit of using IaC?
A) Consistency across environments
B) Faster provisioning through automation
C) Automatic cost optimization with no configuration
D) Version-controlled infrastructure history

**Q3.** [Multiple Choice] In IaC terminology, what does "idempotency" mean?
A) Applying the same configuration multiple times produces the same end state
B) Configuration can only be applied once
C) Resources are destroyed after every apply
D) State files are encrypted by default

**Q4.** [Multiple Choice] Which statement best describes a declarative approach to IaC (as opposed to imperative)?
A) You write step-by-step commands to reach the desired state
B) You describe the desired end state and let the tool figure out how to get there
C) You must manually track the order of resource creation
D) It only works with shell scripts

**Q146.** [True/False] True or False: IaC guarantees that infrastructure changes will never cause downtime.
A) True
B) False

**Q147.** [Multiple Choice] Which of the following is a direct consequence of infrastructure being defined declaratively rather than imperatively?
A) You must always specify the exact order of operations yourself
B) The tool can compute a diff between desired and current state and figure out the necessary steps
C) Declarative tools cannot manage cloud resources
D) There is no practical difference in tooling behavior

**Q212.** [Multiple Choice] Which best captures why version-controlling infrastructure code (as IaC enables) is valuable operationally?
A) It provides an audit trail and lets teams review/roll back infrastructure changes the same way they do application code
B) It automatically fixes bugs in the infrastructure
C) It removes the need for testing changes
D) It's only useful for compliance paperwork

**Q267.** [Multiple Choice] Which best describes why treating infrastructure changes like application code (via IaC) improves operational safety?
A) It removes the need for testing changes before applying them
B) It enables review, version history, and rollback of infrastructure changes using the same practices already established for application code
C) It guarantees infrastructure changes never fail
D) It's primarily a compliance/paperwork exercise with no operational benefit

**Q268.** [True/False] True or False: Idempotency in Terraform means that applying the same configuration multiple times without changes in between will not produce additional or different changes.
A) True
B) False

---

## Domain 2: Understand Terraform's Purpose (vs other IaC) (~5%)

**Q5.** [Multiple Choice] How does Terraform differ from configuration management tools like Ansible or Chef?
A) Terraform is primarily used for provisioning infrastructure, while CM tools focus on configuring software on existing servers
B) Terraform cannot manage cloud resources
C) Ansible requires a state file, Terraform does not
D) There is no meaningful difference

**Q6.** [Multiple Choice] Which of the following is a key advantage of Terraform's multi-cloud support?
A) It automatically migrates resources between providers
B) A single workflow and language can manage resources across multiple providers
C) It removes the need for provider-specific credentials
D) It only supports AWS and Azure

**Q7.** [Multiple Choice] What is a key difference between mutable and immutable infrastructure paradigms, and where does Terraform typically fit?
A) Terraform only supports mutable infrastructure
B) Terraform can support both, but is often used to replace resources rather than patch them in place, favoring immutability
C) Immutable infrastructure cannot be described in code
D) Mutable infrastructure requires no state tracking

**Q8.** [Multiple Choice] Why might a team choose Terraform over a cloud-specific tool like AWS CloudFormation?
A) CloudFormation is faster in all cases
B) Terraform provides a cloud-agnostic workflow usable across multiple providers and services
C) CloudFormation cannot create VPCs
D) Terraform does not support AWS

**Q148.** [Scenario] A team is deciding between Terraform and a cloud-provider-specific IaC tool for a project that must eventually span AWS and GCP. Which factor most strongly favors Terraform?
A) Cloud-specific tools are always faster to write
B) Terraform's provider model lets the same workflow and language extend across multiple clouds
C) Cloud-specific tools support more resource types in general
D) There is no meaningful difference for multi-cloud projects

**Q213.** [Multiple Choice] Which statement accurately contrasts Terraform's approach with a purely imperative scripting approach to infrastructure?
A) Imperative scripts also automatically detect and reconcile drift the same way Terraform does
B) Terraform computes a diff between desired and current state and applies only the necessary changes; imperative scripts execute the same steps regardless of current state unless manually guarded
C) There's no practical difference between the two approaches
D) Imperative scripts always run faster because they skip planning

**Q269.** [Multiple Choice] Which factor most distinguishes Terraform's declarative model from an imperative provisioning script when the current infrastructure state is unknown or has drifted?
A) Imperative scripts also compute a diff against current state automatically
B) Terraform's plan step compares desired configuration against actual/tracked state and computes only the necessary changes, which naive imperative scripts don't do unless explicitly coded to
C) There's no meaningful difference in this scenario
D) Imperative scripts are always safer in drift scenarios

**Q270.** [Scenario] A team wants infrastructure changes to be previewable before they're applied, with a clear list of exactly what will be added, changed, or destroyed. Which capability, central to Terraform's design, provides this?
A) The `terraform fmt` command
B) The plan step, which shows a diff-based preview before any changes are made
C) Provider aliases
D) The dependency lock file

---

## Domain 3: Understand Terraform Basics (~15%)

**Q9.** [Multiple Choice] What are the three main sections typically found in a Terraform configuration file?
A) Providers, resources, and modules only
B) Terraform settings block, providers, and resources/data sources (plus optional variables/outputs)
C) Only resources
D) Backend, provider, and outputs only

**Q10.** [Multiple Choice] What is the purpose of a Terraform provider?
A) It stores the state file
B) It is a plugin that lets Terraform interact with an API (cloud platform, SaaS, etc.)
C) It compiles the Terraform binary
D) It only manages variables

**Q11.** [Multiple Choice] Where are providers typically declared for version constraints in modern Terraform?
A) In the `provider` block only
B) In the `required_providers` block inside `terraform {}`
C) In `variables.tf`
D) In the state file

**Q12.** [Multiple Choice] What does the following version constraint mean? `version = "~> 4.16"`
A) Any version greater than 4.16
B) Only version 4.16 exactly
C) Any version >= 4.16.0 and < 4.17.0 (allows patch-level updates only)
D) Any version below 4.16

**Q13.** [Multiple Choice] What happens if you don't specify a version constraint for a provider?
A) Terraform will refuse to run
B) Terraform will download the latest version available at init time
C) Terraform uses version 1.0.0 by default
D) It causes a syntax error

**Q14.** [Multiple Choice] What is the correct syntax to reference an attribute from a resource named `aws_instance.web`?
A) `aws_instance[web]`
B) `aws_instance.web.id`
C) `resource.aws_instance.web`
D) `web.aws_instance.id`

**Q15.** [Multiple Choice] What is a Terraform "data source" used for?
A) To create new infrastructure
B) To fetch read-only information about existing infrastructure or external data, for use elsewhere in configuration
C) To store the state file remotely
D) To define input variables

**Q16.** [Multiple Choice] Which block type would you use to expose a value from a root module for use by other configurations or the CLI?
A) `variable`
B) `output`
C) `local`
D) `data`

**Q17.** [Multiple Choice] What is the difference between an input variable and a local value in Terraform?
A) There is no difference
B) Input variables are parameters supplied to a module; locals are computed/named values reused within a module and not meant to be set externally
C) Local values can be set on the CLI with `-var`
D) Input variables cannot have default values

**Q18.** [Multiple Choice] Which file, if present, does Terraform automatically load to set variable values without needing `-var-file`?
A) `main.tf`
B) `terraform.tfvars`
C) `outputs.tf`
D) `providers.tf`

**Q19.** [Multiple Choice] What is the correct order of precedence (highest to lowest) for variable value sources in Terraform?
A) Environment variables > tfvars files > CLI `-var` flags > defaults
B) CLI `-var`/`-var-file` flags > `*.auto.tfvars` > `terraform.tfvars` > environment variables (`TF_VAR_`) > defaults
C) Defaults always win
D) `terraform.tfvars` always overrides CLI flags

**Q20.** [Multiple Choice] What does HCL stand for?
A) HashiCorp Configuration Language
B) High-level Cloud Language
C) Hosted Configuration Layer
D) Hybrid Cloud Language

**Q89.** [True/False] True or False: A `local` value defined inside a module can be referenced directly from the module that calls it, the same way an output can.
A) True
B) False

**Q90.** [Scenario] You declare `variable "region" { type = string, default = "us-east-1" }`. On the CLI you run `terraform apply -var="region=us-west-2"` while a `terraform.tfvars` file in the same directory also sets `region = "eu-west-1"`. Which value does Terraform use for `region`?
A) us-east-1 (the default)
B) eu-west-1 (from terraform.tfvars)
C) us-west-2 (from the -var flag)
D) Terraform throws a conflict error

**Q91.** [Code/Config] Given this block:
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 4.0, < 5.0"
    }
  }
}
Which installed AWS provider versions satisfy this constraint?
A) Only exactly version 4.0
B) Any version from 4.0.0 up to (but not including) 5.0.0
C) Any version 5.0 or higher
D) Any version at all, the constraint is ignored

**Q92.** [Multiple Choice] Which of the following correctly declares an input variable with a type constraint of a list of strings?
A) variable "names" { type = list }
B) variable "names" { type = list(string) }
C) variable "names" { type = "list-string" }
D) variable "names" { list = string }

**Q93.** [Multiple Choice] What is the effect of declaring `variable "x" { type = string, nullable = false }` without a default?
A) Nothing changes, nullable has no effect without a default
B) Terraform requires a non-null value to be supplied; passing null will cause an error
C) Terraform silently converts null to an empty string
D) nullable is not a valid argument for variables

**Q94.** [True/False] True or False: You can reference a resource's attribute in an expression before that resource has actually been created on the provider's platform, as long as the reference is valid within the configuration.
A) True
B) False

**Q95.** [Scenario] A teammate declares `variable "instance_type" {}` with no `type` argument at all. What type does Terraform assume?
A) string
B) any
C) It's a syntax error - type is mandatory
D) null

**Q96.** [Multiple Choice] Which statement about provider configuration aliases is correct?
A) Aliases let you configure multiple instances of the same provider (e.g. two AWS regions) in one configuration
B) Aliases are used to rename a resource type
C) Aliases only work with the local backend
D) Each provider can only ever have one configuration, aliases are not supported

**Q97.** [Multiple Choice] Which best describes the difference between a resource's `id` and its resource address (e.g. `aws_instance.web`)?
A) They are always identical strings
B) `id` is a provider-assigned attribute of the real infrastructure object; the resource address is how Terraform refers to it in configuration/state
C) The resource address is only used inside modules
D) `id` is only available after `terraform destroy`

**Q98.** [Code/Config] resource "aws_s3_bucket" "data" {
  bucket = "my-app-data"
}

output "bucket_arn" {
  value = aws_s3_bucket.data.arn
}
What will happen if you run `terraform apply` with this configuration?
A) It will fail because `arn` isn't a valid attribute
B) It creates the bucket, then outputs the ARN once known after creation
C) It only prints the ARN without creating anything
D) Outputs cannot reference resource attributes

**Q99.** [Multiple Choice] In Terraform 0.13+, what does the `count.index` value represent inside a resource using `count = 3`?
A) A random UUID for the instance
B) The 0-based position of the current instance (0, 1, 2)
C) The 1-based position of the current instance (1, 2, 3)
D) The total number of instances (3)

**Q100.** [True/False] True or False: Environment variables prefixed with TF_VAR_ can be used to set Terraform input variable values.
A) True
B) False

**Q153.** [Scenario] You define `locals { full_name = "${var.first}-${var.last}" }` inside module B, which is called by root module A. Which statement is correct about accessing `full_name` from module A?
A) Root module A can reference it directly as `module.B.full_name`
B) Root module A cannot access it at all, even indirectly
C) Root module A can only access it if module B also declares an `output` block exposing that local's value
D) Locals are automatically promoted to outputs in Terraform 1.x

**Q154.** [Multiple Choice] Which of these is NOT a valid argument inside a `variable` block?
A) nullable
B) sensitive
C) validation
D) readonly

**Q155.** [Code/Config] variable "port" {
  type    = number
  default = 8080
  validation {
    condition     = var.port > 1024
    error_message = "Port must be greater than 1024."
  }
}
If a caller sets `port = 80`, what happens?
A) Terraform silently accepts it since 80 is a valid number
B) Terraform fails validation and shows the custom error_message before creating any resources
C) Terraform ignores the validation block on numeric types
D) The default value is used instead of the invalid input

**Q156.** [True/False] True or False: In Terraform, `variable "x" {}` (no type argument at all) is equivalent to `variable "x" { type = any }`.
A) True
B) False

**Q157.** [Multiple Choice] Which provider block correctly configures a second, aliased AWS provider for a different region?
A) provider "aws" { region = "us-west-2" }  (only one block is ever allowed)
B) provider "aws" { alias = "west"; region = "us-west-2" }, then reference it with `provider = aws.west` on a resource
C) provider "aws_west" { region = "us-west-2" }
D) Aliases are configured inside the resource block, not the provider block

**Q158.** [Scenario] You set `export TF_VAR_db_password=hunter2` in your shell before running `terraform apply`, and your configuration has `variable "db_password" { type = string, sensitive = true }` with no default. What happens?
A) Terraform errors because sensitive variables cannot be set via environment variables
B) Terraform picks up the value from TF_VAR_db_password and keeps it out of ordinary CLI output because of `sensitive = true`
C) The variable remains unset and Terraform prompts interactively regardless
D) TF_VAR_ only works for non-sensitive variables

**Q159.** [Multiple Choice] In `count.index` usage, if a resource has `count = 5`, what is the value of `count.index` for the last created instance?
A) 5
B) 4
C) 0
D) It depends on the provider

**Q160.** [Code/Config] terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "!= 5.0.0"
    }
  }
}
What does this version constraint mean?
A) Only version 5.0.0 is allowed
B) Any version is allowed except exactly 5.0.0
C) This is invalid syntax, != is not supported
D) Any version below 5.0.0

**Q161.** [True/False] True or False: A `data` block and a `resource` block can reference the same underlying real-world object, but only the `resource` block will attempt to create, modify, or destroy it.
A) True
B) False

**Q162.** [Multiple Choice] What is the effect of setting `sensitive = true` directly on a `variable` block (as opposed to on an `output` block)?
A) It has no effect on variables, only outputs support it
B) It suppresses the variable's value from being shown in plan/apply CLI output wherever it's used
C) It encrypts the value in the provider's API calls
D) It prevents the variable from being used in resource arguments

**Q163.** [Scenario] A `variable "instance_type" { type = string, default = "t3.micro" }` also has `nullable = false`. What happens if someone explicitly passes `instance_type = null`?
A) Terraform silently substitutes the default value
B) Terraform throws an error, since nullable = false forbids an explicit null even though a default exists
C) Nothing, nullable only matters when there's no default
D) It's converted to an empty string

**Q164.** [Multiple Choice] Which best distinguishes a `local` value from an `output` value?
A) Locals are for internal reuse/naming within a module; outputs are how a module deliberately exposes a value to its caller
B) There is no functional difference between them
C) Outputs can only hold strings, locals can hold any type
D) Locals must be declared before resources, outputs after

**Q165.** [True/False] True or False: The dependency lock file (`.terraform.lock.hcl`) records the exact provider versions and checksums selected during `init`, and should generally be committed to version control.
A) True
B) False

**Q214.** [Scenario] A colleague insists that `variable "tags" {}` with absolutely no arguments will fail to load because Terraform requires an explicit type. You disagree. Who is right, and why?
A) The colleague is right - type is mandatory in all modern Terraform versions
B) You are right - omitting type entirely just means the variable accepts any type, equivalent to type = any
C) It depends on whether a default is also provided
D) It only works for module variables, not root module variables

**Q215.** [True/False] True or False: `sensitive = true` on a variable or output causes Terraform to encrypt that value within the state file.
A) True
B) False

**Q216.** [Multiple Choice] Which statement correctly describes what happens when a state file contains a value from a variable marked `sensitive = true`?
A) The value is omitted from the state file entirely
B) The value is stored in the state file in plaintext, exactly as any other attribute would be
C) The value is stored but scrambled with a reversible cipher
D) Terraform refuses to write sensitive values to state

**Q217.** [Code/Config] variable "api_key" {
  type      = string
  sensitive = true
}

output "key_debug" {
  value = var.api_key
}
What happens when you run `terraform apply`?
A) Terraform errors, because a sensitive variable can never be used in an output
B) Terraform requires the output itself to also be marked sensitive = true, or it will raise an error/warning about exposing a sensitive value
C) The value prints normally with no restriction, since only the variable was marked sensitive
D) The apply silently skips creating the output

**Q218.** [Scenario] You want a resource to always be destroyed and recreated when its AMI ID changes, and you want this enforced even if the provider itself doesn't mark that attribute as forcing replacement. What Terraform feature is designed for exactly this kind of explicit trigger?
A) The `replace_triggered_by` argument inside a `lifecycle` block
B) A `precondition` block
C) The `nullable` argument on a variable
D) A `moved` block

**Q219.** [Multiple Choice] Which of these is true about a variable declared as `variable "count" { type = number, nullable = false, default = 1 }`?
A) Passing an explicit null for this variable will error, even though a default of 1 exists
B) nullable has no effect since a default is present
C) The variable can never be overridden by a caller
D) nullable = false only applies to string-typed variables

**Q220.** [True/False] True or False: A provider's version constraint operator `!=` can be combined with other constraints, e.g. `version = ">= 4.0, != 4.5.0"`, to allow a range while excluding one specific broken release.
A) True
B) False

**Q221.** [Multiple Choice] Which best explains why Terraform distinguishes between a variable having 'no value supplied' versus 'explicitly supplied as null'?
A) There's no actual distinction, they're always treated identically
B) A default only applies when nothing is supplied; nullable = false specifically targets the explicit-null case, which a default alone doesn't prevent
C) Explicit null is always converted to the zero value of the type automatically
D) This distinction only matters for module inputs, never root variables

---

## Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)

**Q21.** [Multiple Choice] What does `terraform fmt` do?
A) Formats the state file
B) Rewrites configuration files to a canonical style and formatting
C) Validates provider credentials
D) Deletes unused resources

**Q22.** [Multiple Choice] What is the purpose of `terraform validate`?
A) It checks configuration syntax and internal consistency without accessing remote services
B) It applies the configuration
C) It formats code
D) It checks cloud provider billing

**Q23.** [Multiple Choice] Which command would you use to see a list of resources currently tracked in the state?
A) `terraform show`
B) `terraform state list`
C) `terraform plan`
D) `terraform get`

**Q24.** [Multiple Choice] What does `terraform taint` (or its modern replacement) do?
A) Deletes a resource from the state permanently with no replacement
B) Marks a resource for recreation on the next apply
C) Locks the state file
D) Formats the configuration

**Q25.** [Multiple Choice] In modern Terraform (0.15.2+), what is the recommended replacement for `terraform taint`?
A) `terraform destroy -target`
B) `terraform apply -replace="resource.address"`
C) `terraform refresh`
D) `terraform state rm`

**Q26.** [Multiple Choice] What does `terraform console` allow you to do?
A) Deploy resources interactively
B) Evaluate expressions and inspect values in an interactive REPL against the current state
C) Edit the state file directly
D) SSH into a provisioned instance

**Q27.** [Multiple Choice] What is the function of `terraform graph`?
A) Generates a visual representation of the dependency graph of resources
B) Shows billing graphs
C) Formats HCL as a diagram
D) Displays CPU usage of resources

**Q28.** [Multiple Choice] What does the `-target` flag do when used with `terraform apply`?
A) Applies changes to a specific remote backend
B) Restricts the apply/plan operation to a specific resource and its dependencies
C) Targets a specific workspace only
D) Selects a specific provider version

**Q29.** [Multiple Choice] Why is `-target` generally discouraged for routine use?
A) It's deprecated and no longer works
B) It can produce a state that's inconsistent with the full configuration if used repeatedly instead of as a targeted exception
C) It always destroys resources
D) It requires root permissions

**Q30.** [Multiple Choice] What does `terraform output` do by default?
A) Applies pending changes
B) Displays the values of output variables defined in the root module
C) Lists all providers
D) Deletes all outputs

**Q31.** [Multiple Choice] Which command initializes a working directory containing Terraform configuration files, downloading providers and modules?
A) `terraform plan`
B) `terraform init`
C) `terraform get`
D) `terraform validate`

**Q32.** [Multiple Choice] What is the purpose of the `-upgrade` flag with `terraform init`?
A) Upgrades the Terraform CLI binary itself
B) Upgrades provider and module versions to the latest allowed by constraints, updating the lock file
C) Upgrades the state file format
D) Upgrades the OS

**Q33.** [Multiple Choice] What does `terraform import` do?
A) Creates new resources matching configuration
B) Brings an existing, manually-created resource under Terraform management by adding it to the state
C) Imports variable definitions from another file
D) Downloads provider plugins

**Q34.** [Multiple Choice] After running `terraform import`, what additional manual step is required?
A) Nothing further is needed
B) You must write a matching resource configuration block yourself, since import only updates state, not configuration
C) You must run `terraform destroy` immediately
D) You must delete the state file

**Q101.** [Scenario] You accidentally deleted a resource manually through the cloud console, but it's still present in your Terraform state. What is the safest next command to run to see how Terraform reacts, without changing anything yet?
A) terraform apply -auto-approve
B) terraform plan (Terraform will detect it's missing and propose recreating it)
C) terraform state rm
D) terraform destroy

**Q102.** [Multiple Choice] Which command would you use to rename a resource in your state to match a renamed resource block in configuration, without destroying and recreating the underlying infrastructure?
A) terraform import
B) terraform state mv
C) terraform refresh
D) terraform state rm

**Q103.** [True/False] True or False: `terraform fmt -recursive` formats .tf files in the current directory and all subdirectories.
A) True
B) False

**Q104.** [Scenario] During a CI pipeline run, `terraform init` fails because it can't reach the module registry due to a network policy. Which flag lets you skip re-downloading modules if they're already present locally from a previous run?
A) terraform init -get=false
B) terraform init -backend=false
C) terraform init -upgrade
D) terraform init -reconfigure

**Q105.** [Multiple Choice] What does `terraform providers` (as opposed to `terraform provider`) do?
A) Installs new providers
B) Prints a tree of provider requirements used by the configuration and its modules
C) Deletes unused providers
D) Upgrades all providers to latest

**Q106.** [Code/Config] $ terraform apply -replace="aws_instance.web"
What will this command do?
A) Delete aws_instance.web and never recreate it
B) Force aws_instance.web to be destroyed and recreated on this apply, leaving other resources untouched
C) Replace the entire state file
D) Only works in plan mode, never applies

**Q107.** [True/False] True or False: `terraform validate` requires network access to the provider's API to succeed.
A) True
B) False

**Q108.** [Multiple Choice] Which of these is NOT a valid reason to use `terraform console`?
A) Testing how a function like `cidrsubnet()` behaves with sample inputs
B) Checking the current value of a resource attribute in state
C) Applying infrastructure changes interactively
D) Evaluating a complex expression before adding it to configuration

**Q109.** [Scenario] You imported an existing S3 bucket using `terraform import aws_s3_bucket.data my-bucket-name`, but running `terraform plan` afterward shows Terraform wants to change several attributes. What is the most likely cause?
A) Import always corrupts the state
B) The resource block's arguments in configuration don't yet match the real bucket's actual settings, so plan shows the diff
C) S3 buckets cannot be imported
D) You must run terraform destroy after every import

**Q110.** [Multiple Choice] What is the purpose of the `-lock=false` flag on `terraform plan` or `apply`?
A) Permanently disables locking for the backend
B) Skips acquiring a state lock for that single operation (use with caution)
C) Locks the configuration files from editing
D) Encrypts the state file

**Q111.** [True/False] True or False: `terraform output -json` prints all output values in JSON format, which is useful for piping into other tools/scripts.
A) True
B) False

**Q112.** [Multiple Choice] Which command shows the current state in a human-readable format, including resource attributes, without needing to open the raw state file?
A) terraform state list
B) terraform show
C) terraform graph
D) terraform fmt

**Q166.** [Scenario] You want to rename `aws_instance.web` to `aws_instance.frontend` in your configuration, and you don't want Terraform to destroy and recreate the instance. After editing the .tf file, what CLI action keeps state and reality in sync?
A) terraform state mv aws_instance.web aws_instance.frontend
B) terraform refresh
C) terraform import aws_instance.frontend <id>
D) No action needed, Terraform detects the rename automatically

**Q167.** [Multiple Choice] Which command displays the full, human-readable contents of the current state (or a saved plan file), including all tracked resource attributes?
A) terraform state list
B) terraform show
C) terraform state show <address>
D) terraform graph

**Q168.** [Scenario] You need to troubleshoot why a provider call is failing during `terraform apply`, and want to see detailed HTTP request/response data from the provider plugin. What should you do?
A) Run `terraform apply -verbose`
B) Set the TF_LOG environment variable (e.g. TF_LOG=TRACE) before running the command
C) Use `terraform console` to inspect the request
D) There is no way to get this level of detail

**Q169.** [True/False] True or False: Setting `TF_LOG=JSON` outputs Terraform's logs in structured JSON format, useful for feeding into log aggregation tools.
A) True
B) False

**Q170.** [Multiple Choice] What does `TF_LOG_PATH` do when used alongside `TF_LOG`?
A) Sets which provider to log
B) Writes the log output to a specified file instead of just stderr
C) Sets the working directory for logs only
D) It has no effect without HCP Terraform

**Q171.** [Scenario] You imported a resource with `terraform import`, then ran `terraform plan` and saw no differences at all. What does this indicate?
A) Something went wrong; imports always show at least one diff
B) Your hand-written resource block's arguments happen to already match the real resource's current settings
C) Plan is broken and needs to be re-run with -refresh=false
D) Import silently fixed the configuration for you

**Q172.** [Multiple Choice] Which flag would you add to `terraform init` to reconfigure the backend from scratch, ignoring any saved backend configuration?
A) -upgrade
B) -reconfigure
C) -get=false
D) -lock=false

**Q173.** [True/False] True or False: `terraform console` can be used to test how a function behaves with sample values before you commit that expression into your actual configuration.
A) True
B) False

**Q174.** [Code/Config] $ terraform state list
aws_instance.web
aws_s3_bucket.data
module.vpc.aws_vpc.main

Which command would show you the full attribute detail for just the VPC resource inside the module?
A) terraform show module.vpc
B) terraform state show module.vpc.aws_vpc.main
C) terraform state list module.vpc
D) terraform refresh module.vpc.aws_vpc.main

**Q175.** [Multiple Choice] Why might `terraform apply -replace="aws_instance.web"` be preferred over manually running `terraform taint` in current Terraform versions?
A) -replace is deprecated in favor of taint
B) -replace is the modern, explicit way to force replacement without needing a separate state-mutating command beforehand
C) taint still works but requires a paid HCP Terraform license
D) There is no meaningful difference

**Q176.** [Scenario] A CI pipeline needs to run `terraform plan` without prompting for interactive input and without needing network access to re-download unchanged providers. Which two behaviors should the pipeline rely on?
A) Use `-input=false` and ensure the provider plugin cache / lock file is already populated
B) Use `-auto-approve` on plan (not a real flag) and skip init entirely
C) Delete the lock file before every run to force a fresh check
D) Run apply without plan to save time

**Q177.** [Multiple Choice] What is the key difference between `terraform state list` and `terraform state show <address>`?
A) state list shows all resource addresses; state show gives full attribute detail for one specific address
B) They are functionally identical
C) state show only works on data sources
D) state list requires a saved plan file

**Q178.** [True/False] True or False: You must run `terraform init` again after modifying the `required_providers` block to add a new provider.
A) True
B) False

**Q222.** [Scenario] A teammate says: "I used `terraform console` to quickly apply a fix to production without waiting for a full plan/apply cycle." What's wrong with this statement?
A) Nothing is wrong, console is designed for exactly this
B) console cannot apply any changes at all - it's a read-only expression evaluator against current state/config, so this claim describes something console cannot do
C) console can apply changes but only in HCP Terraform, not locally
D) console requires -auto-approve to apply changes

**Q223.** [Multiple Choice] Which of the following is a legitimate, documented use of `terraform console`?
A) Applying a saved plan file
B) Evaluating how an expression or function will behave against current variables/state before adding it to configuration
C) Destroying a specific tainted resource
D) Migrating state between backends

**Q224.** [True/False] True or False: `terraform destroy -target=aws_instance.web` will destroy only that instance and its dependents, not your entire infrastructure.
A) True
B) False

**Q225.** [Scenario] You've heard the claim: "terraform destroy has no way to target a single resource - it's all or nothing." Is this claim accurate?
A) Yes, this is accurate - destroy always removes every resource in state
B) No - `terraform destroy -target=<address>` scopes the destroy to a specific resource
C) Yes, unless you're using HCP Terraform
D) No, but only for resources with no dependents

**Q226.** [Multiple Choice] You need to move `aws_instance.web` in state to a new address `aws_instance.frontend` after a rename in configuration. Which single command directly accomplishes this without contacting the provider API to recreate anything?
A) terraform refresh
B) terraform state mv aws_instance.web aws_instance.frontend
C) terraform import aws_instance.frontend <id>
D) terraform apply -replace

**Q227.** [True/False] True or False: `terraform refresh` (or the refresh step within plan) can rename a resource address in state to match a renamed resource block in configuration.
A) True
B) False

**Q228.** [Scenario] Which pair of commands, if confused with each other, most commonly trips people up: one re-addresses a resource in state without touching infrastructure, the other only reconciles state values against real infrastructure?
A) terraform validate and terraform fmt
B) terraform state mv and terraform refresh
C) terraform init and terraform get
D) terraform output and terraform show

**Q229.** [Code/Config] $ terraform state mv module.old_name.aws_instance.web module.new_name.aws_instance.web
What does this accomplish?
A) Nothing changes, since module addresses can't be moved this way
B) It re-addresses the resource from inside one module's namespace to another, updating state without destroying/recreating the instance
C) It physically moves files between module directories on disk
D) It duplicates the resource under both addresses simultaneously

---

## Domain 5: Interact with Terraform Modules (~10%)

**Q35.** [Multiple Choice] What is a Terraform module?
A) A single resource block
B) A container for multiple resources used together, referenced as a reusable unit of configuration
C) A type of provider
D) A state file backup

**Q36.** [Multiple Choice] What is the "root module" in a Terraform configuration?
A) The first module ever created
B) The configuration files in the main working directory that Terraform runs against
C) A module stored in the Terraform Registry
D) A module with no resources

**Q37.** [Multiple Choice] How do you call a module from a local path in configuration?
A) `module "example" { source = "app.terraform.io/example" }`
B) `module "example" { source = "./modules/example" }`
C) `import "example" { path = "./modules/example" }`
D) `provider "example" { path = "./modules/example" }`

**Q38.** [Multiple Choice] What format is used to reference a module hosted on the public Terraform Registry?
A) `source = "github.com/user/repo"` only
B) `source = "<NAMESPACE>/<NAME>/<PROVIDER>"`
C) `source = "registry://module"`
D) `source = "local://module"`

**Q39.** [Multiple Choice] How do you pass a value into a module from the calling configuration?
A) Modules cannot accept inputs
B) By setting an argument inside the `module` block that matches a `variable` declared in the module
C) By editing the module's source code directly every time
D) Through the state file only

**Q40.** [Multiple Choice] How do you reference an output value from a child module in the calling (parent) configuration?
A) `output.module_name.value`
B) `module.<module_name>.<output_name>`
C) `child.<module_name>.<output_name>`
D) Outputs can't be referenced outside the module

**Q41.** [Multiple Choice] What does module versioning (e.g. `version = "~> 2.0"`) apply to?
A) Only local modules
B) Modules sourced from a registry (local path and some other sources don't support version constraints)
C) The Terraform CLI version
D) The provider version

**Q42.** [Multiple Choice] Why are modules considered a best practice for larger Terraform codebases?
A) They eliminate the need for state
B) They encapsulate and reuse configuration, reducing duplication and standardizing patterns
C) They remove the need for variables
D) They bypass the need for provider blocks

**Q113.** [Scenario] Your root module calls a child module twice using `for_each` over a set of environment names: `module "vpc" { for_each = toset(["dev","prod"]) ... }`. How do you reference the `vpc_id` output of the "prod" instance from the root module?
A) module.vpc.vpc_id
B) module.vpc["prod"].vpc_id
C) module.vpc.prod.vpc_id
D) vpc.prod.vpc_id

**Q114.** [True/False] True or False: A module sourced from a local relative path (e.g. `source = "../modules/vpc"`) is automatically re-downloaded and can use a `version` constraint just like a registry module.
A) True
B) False

**Q115.** [Multiple Choice] What happens if a required input variable of a child module is not supplied in the calling `module` block, and the variable has no default?
A) Terraform silently uses null
B) Terraform will error during plan/apply, since the variable is required
C) The module is skipped entirely
D) It falls back to an environment variable automatically

**Q116.** [Scenario] You want to reuse the same module twice in the same root configuration - once for a 'staging' VPC and once for a 'prod' VPC - each with different CIDR blocks. Which approach is correct?
A) You cannot call the same module more than once in a configuration
B) Declare two separate `module` blocks with different local names, each passing its own CIDR value
C) Use the same module block and pass a list of CIDRs, Terraform automatically creates two calls
D) Copy-paste the module's source code into two folders

**Q117.** [Multiple Choice] Which of these is a best practice when designing a reusable module?
A) Hard-code resource names and regions inside the module
B) Expose configurable behavior through input variables and expose useful values through outputs
C) Avoid using outputs so the module's internals stay hidden
D) Always require callers to also manage the module's own state file directly

**Q118.** [Code/Config] module "network" {
  source = "./modules/network"
  cidr   = "10.0.0.0/16"
}

resource "aws_instance" "app" {
  subnet_id = module.network.subnet_ids[0]
}
What must be true in `./modules/network` for this configuration to work?
A) The module must declare an output named `subnet_ids` that returns a list
B) The module must declare a variable named `subnet_ids`
C) Nothing extra is needed, Terraform infers it automatically
D) The module must contain a resource named `aws_instance.app`

**Q119.** [True/False] True or False: Modules can call other modules (nested modules), and there is no limit enforced by Terraform on nesting depth.
A) True
B) False

**Q120.** [Multiple Choice] What does running `terraform get` do in a configuration that uses modules?
A) Downloads/updates modules referenced in configuration (also done automatically by `init`)
B) Fetches the current state from the backend
C) Retrieves output values only
D) Installs provider plugins

**Q179.** [Multiple Choice] How do you correctly reference the output of a module called via `module "vpc" { source = "./modules/vpc" }` from the root module?
A) vpc.output_name
B) module.vpc.output_name
C) output.vpc.output_name
D) root.vpc.output_name

**Q180.** [Scenario] You call the same module twice for staging and prod, each with different CIDR blocks, using two separately named module blocks. Both blocks reference `module.network` outputs incorrectly by mistake in a shared resource. What's the correct reference pattern instead, if the blocks are named `module "staging_network"` and `module "prod_network"`?
A) module.network.staging.output / module.network.prod.output
B) module.staging_network.output_name / module.prod_network.output_name
C) module["staging_network"].output
D) There's no way to reference two separate module calls independently

**Q181.** [True/False] True or False: A module can declare its own `required_providers` block to specify which provider versions it's compatible with.
A) True
B) False

**Q182.** [Multiple Choice] When publishing a module to the public Terraform Registry, what is required for version constraints (`version = "~> 1.0"`) to work when others consume it?
A) Nothing special, any source works
B) The module's repository must use semantic version tags (e.g. v1.0.0) that the registry indexes
C) The module must be written only in JSON
D) Version constraints only work for local modules

**Q230.** [Scenario] You declare `module "servers" { for_each = toset(["web", "api"]) source = "./modules/server" }`. Which expression correctly retrieves the `public_ip` output for the "api" instance?
A) module.servers.api.public_ip
B) module.servers["api"].public_ip
C) module["servers"].api.public_ip
D) servers.api.public_ip

**Q231.** [Multiple Choice] For a module block using `count = 2` (not for_each), how would you reference the first instance's `vpc_id` output?
A) module.vpc.vpc_id
B) module.vpc[0].vpc_id
C) module.vpc.0.vpc_id
D) module.vpc.first.vpc_id

**Q232.** [True/False] True or False: If a module block does not use `count` or `for_each`, referencing its output is done without any index or key at all, e.g. `module.vpc.vpc_id`.
A) True
B) False

**Q233.** [Scenario] You have two separate module blocks: `module "staging" { source = "./net" }` and `module "prod" { source = "./net" }`. A resource needs both VPC IDs. Which reference pattern is correct?
A) module.net.staging.vpc_id and module.net.prod.vpc_id
B) module.staging.vpc_id and module.prod.vpc_id
C) module["staging"].vpc_id and module["prod"].vpc_id
D) There's no way to reference two separate calls to the same module source

**Q234.** [Multiple Choice] Which statement about referencing module outputs is FALSE?
A) The module's local block name (not its source) is what you use to address it
B) You must declare a matching `output` block inside the child module for the value to be visible to the caller
C) Any resource attribute inside a module is automatically visible to the parent without any output block
D) for_each and count based module calls require a key/index when referenced

**Q235.** [Code/Config] module "team" {
  for_each = { eng = "10.0.1.0/24", data = "10.0.2.0/24" }
  source   = "./modules/subnet"
  cidr     = each.value
}
Which expression retrieves the subnet_id output for the "data" team's subnet?
A) module.team.data.subnet_id
B) module.team["data"].subnet_id
C) module.subnet["data"].subnet_id
D) each.value.team.data.subnet_id

---

## Domain 6: Navigate Terraform Workflow (~15%)

**Q43.** [Multiple Choice] What is the correct standard Terraform workflow order?
A) Apply -> Plan -> Init
B) Init -> Plan -> Apply
C) Plan -> Init -> Apply
D) Apply -> Init -> Plan

**Q44.** [Multiple Choice] What does `terraform plan` do?
A) Applies changes immediately
B) Creates an execution plan showing what actions Terraform will take, without making changes
C) Destroys existing infrastructure
D) Downloads providers

**Q45.** [Multiple Choice] What is the purpose of saving a plan to a file with `terraform plan -out=tfplan`?
A) It has no practical purpose
B) It lets you apply that exact, reviewed plan later with `terraform apply tfplan`, avoiding drift between plan and apply
C) It backs up the state file
D) It formats the configuration

**Q46.** [Multiple Choice] In a team/CI setting, why is applying a saved plan file considered safer than running `terraform apply` directly?
A) It's not safer, they're identical
B) It guarantees the applied changes exactly match what was reviewed/approved, since the plan can't silently change between review and apply
C) It skips the need for a backend
D) It removes the need for state locking

**Q47.** [Multiple Choice] What does `terraform apply -auto-approve` do differently from a plain `terraform apply`?
A) It skips generating a plan
B) It skips the interactive approval prompt and applies the plan automatically
C) It only works in CI
D) It ignores the state file

**Q48.** [Multiple Choice] What happens during `terraform destroy`?
A) It only deletes local files
B) Terraform destroys all resources tracked in the state file for the current configuration/workspace
C) It deletes the provider plugins only
D) It resets variables to default

**Q49.** [Multiple Choice] How can you destroy only a specific resource instead of the whole configuration?
A) `terraform destroy -target=<resource_address>`
B) `terraform destroy` always destroys everything, no exceptions
C) `terraform apply -target` only
D) Manually edit the state file first

**Q50.** [Multiple Choice] What is the purpose of the refresh step that occurs as part of `terraform plan`?
A) It reformats configuration files
B) It reconciles the state file with real infrastructure to detect drift before computing the plan
C) It re-downloads providers
D) It regenerates the lock file

**Q51.** [Multiple Choice] What does Terraform do if it detects that real infrastructure has drifted from the state (e.g., someone manually changed a resource)?
A) It silently ignores the difference
B) It shows the drift in the plan output and proposes changes to reconcile config, state, and real infrastructure
C) It automatically deletes the resource
D) It crashes with an unrecoverable error

**Q52.** [Multiple Choice] Which workflow step would catch a syntax error in a `.tf` file before contacting any provider APIs?
A) `terraform apply`
B) `terraform validate` (also caught earlier by `terraform plan`/`init`)
C) `terraform destroy`
D) `terraform state list`

**Q53.** [Multiple Choice] What is the purpose of `terraform apply` after a plan is generated interactively (without `-out`)?
A) It re-runs `init`
B) It re-computes a fresh plan and prompts for approval before applying it
C) It automatically applies without any plan
D) It skips state updates

**Q54.** [Multiple Choice] Why does Terraform generally recommend running `plan` before every `apply` rather than skipping straight to apply?
A) It's a legacy requirement with no real benefit
B) It lets you review exactly what will change before it happens, reducing the risk of unintended modifications
C) It's required for provider authentication
D) It updates the CLI version

**Q121.** [Scenario] You run `terraform plan -out=tfplan`, review it, then a teammate merges an unrelated change into the same branch and someone else applies main before you apply your saved plan. What happens when you then run `terraform apply tfplan`?
A) Terraform applies the stale plan blindly, ignoring the new state
B) Terraform detects the state has changed since the plan was created and errors out rather than applying a stale plan
C) It automatically re-plans for you silently
D) It merges both changes automatically

**Q122.** [True/False] True or False: Running `terraform destroy` will prompt for confirmation by default, the same way `apply` does.
A) True
B) False

**Q123.** [Multiple Choice] During `terraform plan`, you see a resource marked with `-/+` in the diff output. What does this indicate?
A) The resource will be updated in place
B) The resource will be destroyed and then recreated (replacement)
C) The resource will only be destroyed, never recreated
D) No change will occur

**Q124.** [Scenario] You need to change an AWS instance's AMI, but the `ami` argument's documentation says changing it forces replacement. What would you expect to see in `terraform plan` output for that resource?
A) A simple in-place update (~)
B) A destroy-and-recreate action (-/+), since the attribute is defined as ForceNew
C) No change shown at all
D) An error preventing any plan from being generated

**Q125.** [Multiple Choice] What is the purpose of `terraform plan -destroy`?
A) It immediately destroys all resources
B) It previews what a `terraform destroy` would do, without executing it
C) It's not a valid flag combination
D) It only works with modules

**Q126.** [True/False] True or False: If `terraform apply` is interrupted (e.g. Ctrl+C) partway through applying multiple resources, the state file may reflect a partially-applied configuration, and running plan again is the recommended way to see what remains.
A) True
B) False

**Q183.** [Multiple Choice] Which of these correctly destroys only one specific resource while leaving the rest of the infrastructure untouched?
A) terraform destroy (always destroys everything with no exceptions)
B) terraform destroy -target=aws_instance.web
C) terraform apply -target only, destroy never supports targeting
D) terraform state rm aws_instance.web (this also destroys the real resource)

**Q184.** [Scenario] Before committing to a large `terraform destroy`, you want to preview exactly what would be destroyed without actually destroying anything. What should you run?
A) terraform destroy --dry-run (not a real flag)
B) terraform plan -destroy
C) terraform show -destroy
D) terraform validate -destroy

**Q185.** [True/False] True or False: The refresh step that runs as part of `terraform plan` reconciles the state file with real infrastructure, but it does not change your configuration files.
A) True
B) False

**Q186.** [Multiple Choice] What is 'refresh-only mode' (available via `terraform plan -refresh-only` or in HCP Terraform) primarily used for?
A) Applying configuration changes faster
B) Safely reviewing and optionally accepting drift between state and real infrastructure, without proposing any configuration-driven changes
C) Refreshing provider plugin versions
D) Clearing the state lock

**Q236.** [Multiple Choice] Which correctly destroys a single resource and any resources that depend on it, while leaving unrelated resources untouched?
A) terraform destroy (no way to scope it)
B) terraform destroy -target=<resource_address>
C) terraform state rm <resource_address> (this also destroys real infra)
D) terraform apply -destroy-only

**Q237.** [True/False] True or False: A workflow of `terraform plan -out=tfplan` followed later by `terraform apply tfplan` guarantees the exact reviewed plan gets applied, since Terraform checks the state hasn't changed in the meantime.
A) True
B) False

**Q238.** [Multiple Choice] What does a `-/+` symbol mean in `terraform plan` output for a given resource?
A) In-place update only
B) Destroy and recreate (replacement)
C) No change
D) Import pending

**Q239.** [Scenario] You want to preview exactly what a `terraform destroy` would remove, without actually removing anything, so you can review it in a PR before merging. What should you run?
A) terraform destroy --dry-run
B) terraform plan -destroy
C) terraform show -destroy
D) There is no way to preview a destroy

---

## Domain 7: Implement and Maintain State (~15%)

**Q55.** [Multiple Choice] What is the primary purpose of the Terraform state file?
A) To store provider credentials
B) To map real-world resources to your configuration and track metadata/dependencies
C) To store variable defaults only
D) To act as a backup of `.tf` files

**Q56.** [Multiple Choice] What is a "backend" in Terraform?
A) The provider plugin binary
B) The mechanism that determines where and how state is stored (local or remote)
C) A type of module
D) The CLI itself

**Q57.** [Multiple Choice] Why is remote state generally preferred over local state for team environments?
A) It's faster to write to disk
B) It enables shared access, locking, and avoids conflicts from multiple people applying simultaneously
C) It removes the need for `terraform init`
D) It eliminates the need for version control

**Q58.** [Multiple Choice] What problem does state locking solve?
A) It prevents unauthorized read access to state
B) It prevents concurrent operations from corrupting the state file by writing to it at the same time
C) It encrypts the state file
D) It compresses the state file

**Q59.** [Multiple Choice] Which backend types commonly support state locking? (choose the best answer)
A) None do
B) Backends like AWS S3 (with DynamoDB), Azure Storage, Google Cloud Storage, and HCP Terraform/Terraform Enterprise support locking
C) Only the local backend
D) Only HCP Terraform

**Q60.** [Multiple Choice] What command would you use to move a resource from one state address to another (e.g., after renaming it in configuration) without destroying/recreating it?
A) `terraform import`
B) `terraform state mv`
C) `terraform state rm`
D) `terraform refresh`

**Q61.** [Multiple Choice] What does `terraform state rm` do?
A) Deletes the real infrastructure resource
B) Removes a resource from Terraform's state without destroying the actual infrastructure
C) Deletes the entire state file
D) Removes a provider

**Q62.** [Multiple Choice] Why should you generally avoid manually editing the state file with a text editor?
A) State files aren't in JSON so they can't be edited
B) Manual edits can easily corrupt the state, causing mismatches with real infrastructure; `terraform state` subcommands are the supported way to modify it
C) The state file is read-only by the OS
D) It's not possible to open the file

**Q63.** [Multiple Choice] What does `terraform state list` output?
A) A list of variables
B) A list of resource addresses currently tracked in the state
C) A list of available providers
D) A list of output values

**Q64.** [Multiple Choice] What sensitive information can commonly end up in the Terraform state file?
A) Only resource names
B) Potentially sensitive attribute values (like passwords or keys) in plaintext, unless the backend/state encryption mitigates this
C) Nothing sensitive is ever stored in state
D) Only provider names

**Q65.** [Multiple Choice] What is the purpose of the `sensitive = true` argument on a variable or output?
A) It encrypts the value in the state file
B) It suppresses the value from CLI output (plan/apply/output), though it's still stored in state
C) It prevents the value from being stored in state entirely
D) It deletes the value after apply

**Q66.** [Multiple Choice] What happens if two team members run `terraform apply` at the same time against the same remote state with locking enabled?
A) Both applies succeed simultaneously
B) The second apply is blocked/fails until the first operation releases the lock
C) The state file is duplicated
D) Terraform automatically merges both changes

**Q127.** [Scenario] Two engineers both run `terraform apply` against the same S3+DynamoDB backend at nearly the same time. Engineer A's apply starts first and acquires the lock. What happens to Engineer B's apply?
A) It proceeds anyway and corrupts the state
B) It fails/waits, showing a lock error, until Engineer A's operation finishes and releases the lock
C) It silently overwrites Engineer A's changes
D) DynamoDB automatically merges both changes

**Q128.** [Multiple Choice] Why might a team choose an encrypted remote backend (e.g. S3 with SSE) for state storage over local state?
A) Local state files are always automatically encrypted
B) State can contain sensitive attribute values in plaintext, so protecting the storage location matters
C) Encryption is required by Terraform's core, not a backend choice
D) Remote state removes the risk of sensitive values entirely

**Q129.** [True/False] True or False: `terraform state show <resource_address>` displays the detailed attributes of a single resource as currently recorded in state.
A) True
B) False

**Q130.** [Code/Config] $ terraform state rm aws_db_instance.legacy
After running this command, what is true?
A) The RDS instance is deleted from AWS
B) The RDS instance still exists in AWS, but Terraform no longer tracks or manages it
C) The command fails because state rm cannot target database resources
D) The resource block is automatically deleted from the .tf file

**Q131.** [Scenario] You need to migrate state from a local backend to an S3 backend for an existing configuration. After adding the `backend "s3" {}` block, what command must you run to actually move the state?
A) terraform apply
B) terraform init (Terraform will detect the backend change and offer to migrate state)
C) terraform state mv
D) terraform import

**Q132.** [Multiple Choice] Which scenario is the strongest justification for using `-target` together with `terraform state rm`, rather than routine daily usage?
A) Recovering from a specific one-off state/config mismatch, then returning to normal full plans/applies
B) As your everyday default way of running Terraform for speed
C) To permanently avoid ever running a full plan again
D) It's required before every apply

**Q187.** [Scenario] Your team currently manages a resource with Terraform, but wants to stop managing it (without destroying the real infrastructure) as part of a deliberate refactor, and wants this documented declaratively in configuration rather than as a one-off CLI action. Which construct fits this in modern Terraform?
A) terraform state rm (CLI only, no configuration record)
B) A `removed` block in configuration, which declares intent to stop managing a resource without destroying it
C) Deleting the resource block with no other action
D) terraform destroy -target

**Q188.** [Multiple Choice] Why is it best practice to avoid putting raw secrets directly into Terraform variable defaults, even when the variable is marked `sensitive = true`?
A) sensitive = true already fully protects the value everywhere, so it doesn't matter
B) sensitive only masks CLI output; the value can still end up in state and version-controlled defaults, so secrets management tools like Vault are preferred for real secrets
C) Terraform configuration files cannot contain sensitive values at all
D) Defaults are always encrypted automatically

**Q189.** [Scenario] Your organization wants Terraform to fetch a database password at runtime from HashiCorp Vault instead of storing it in a .tfvars file. Which general approach does Terraform support for this?
A) Terraform cannot integrate with Vault at all
B) Using the Vault provider's data sources to read secrets dynamically during plan/apply
C) Vault integration requires HCP Terraform Enterprise exclusively
D) Only environment variables can supply secrets, never providers

**Q190.** [True/False] True or False: Even with `sensitive = true` set on a variable, its value is still stored in the Terraform state file, typically unencrypted unless the backend itself provides encryption.
A) True
B) False

**Q191.** [Multiple Choice] What is the primary difference between a `moved` block and a `removed` block in configuration?
A) moved re-addresses a resource/module to a new name without destroying it; removed declares that Terraform should stop managing a resource, optionally without destroying the real infrastructure
B) They are interchangeable and do the same thing
C) moved only works with modules, removed only works with resources
D) removed permanently deletes the .tf file containing the resource

**Q192.** [Code/Config] removed {
  from = aws_instance.legacy

  lifecycle {
    destroy = false
  }
}
What does `destroy = false` inside this `removed` block achieve?
A) Terraform stops managing aws_instance.legacy but leaves the real infrastructure running
B) Terraform destroys aws_instance.legacy immediately
C) This is invalid syntax inside a removed block
D) It prevents the removed block from ever taking effect

**Q240.** [Code/Config] resource "aws_s3_bucket" "data" {
  bucket = "my-existing-bucket"
}

import {
  to = aws_s3_bucket.data
  id = "my-existing-bucket"
}
What is the correct workflow for using this configuration?
A) Run terraform destroy first, then apply
B) Run terraform plan to preview the import, then terraform apply to execute it - the import block declares the intent declaratively instead of running a separate CLI import command
C) The import block alone is sufficient; no plan/apply is needed
D) You must delete the resource block, since import and resource blocks can't coexist

**Q241.** [True/False] True or False: The declarative `import` block (introduced in Terraform 1.5) can automatically generate the matching resource configuration for you, using `terraform plan -generate-config-out=<file>`.
A) True
B) False

**Q242.** [Multiple Choice] What is the key advantage of the declarative `import` block over the legacy `terraform import <address> <id>` CLI command?
A) It works with more resource types than the CLI command
B) It integrates the import into your normal, version-controlled configuration and plan/apply workflow, rather than being a one-off imperative CLI action
C) It doesn't require the resource ID to be known
D) It bypasses the need for provider credentials

**Q243.** [Code/Config] locals {
  buckets = { staging = "bucket1", prod = "bucket2" }
}

import {
  for_each = local.buckets
  to       = aws_s3_bucket.this[each.key]
  id       = each.value
}

resource "aws_s3_bucket" "this" {
  for_each = local.buckets
}
What does the `for_each` argument on this import block accomplish?
A) It's invalid - import blocks don't support for_each
B) It lets a single import block import multiple similar resources at once, mapping each key to a resource instance and its corresponding provider ID
C) It only works for count-based resources, not for_each
D) It imports the same resource repeatedly

**Q244.** [True/False] True or False: After an import block has been successfully applied, it becomes inert for future runs but can be safely left in configuration as a record, or removed.
A) True
B) False

**Q245.** [Multiple Choice] Which statement about the `import` block's `id` argument is correct?
A) It can be any arbitrary string chosen by the user
B) It must be the provider-specific identifier for the real resource, and its required format is documented per resource type by the provider
C) It's optional if a `moved` block is also present
D) It's automatically inferred from the resource block's arguments

**Q246.** [Scenario] You're migrating a large set of unmanaged AWS resources into Terraform and want this to be reviewable in a pull request rather than run ad hoc from someone's laptop. Which import approach fits this requirement best?
A) Running terraform import commands manually and committing the resulting state file
B) Writing declarative import blocks in version-controlled configuration, reviewed via a normal plan/apply-based PR workflow
C) There's no way to make imports reviewable via PR
D) Manually editing the state file to add the resources

**Q247.** [Multiple Choice] You cannot use both the `id` argument and which other argument in the same `import` block?
A) to
B) for_each
C) identity
D) provider

---

## Domain 8: Read, Generate, and Modify Configuration (~20%)

**Q67.** [Multiple Choice] What does the `count` meta-argument do on a resource block?
A) Sets the resource's numeric ID
B) Creates multiple instances of a resource based on an integer, indexed by `count.index`
C) Limits the resource to a maximum count
D) Sets a billing quota

**Q68.** [Multiple Choice] What does `for_each` allow that `count` does not, when creating multiple resource instances?
A) Nothing, they're functionally identical
B) Creating instances keyed by a map or set of strings, so instances are identified by key rather than numeric index (more stable when the collection changes)
C) `for_each` can only be used with modules, not resources
D) `for_each` is deprecated

**Q69.** [Multiple Choice] Given `variable "env" { type = string }`, what does the `type` constraint enforce?
A) Nothing, types are purely cosmetic
B) That the value assigned to the variable must be a string, or Terraform will error/attempt conversion
C) The variable's default value only
D) Only affects the CLI, not `plan`/`apply`

**Q70.** [Multiple Choice] What does the `lookup()` function do?
A) Retrieves a value from a map by key, with an optional default if the key is absent
B) Looks up a resource in the state
C) Validates a provider version
D) Searches the Terraform Registry

**Q71.** [Multiple Choice] What does a `dynamic` block allow you to do in Terraform configuration?
A) Dynamically change the provider at runtime
B) Programmatically generate repeated nested configuration blocks (like multiple `ingress` blocks) from a collection
C) Dynamically resize the state file
D) Enable auto-scaling on cloud resources

**Q72.** [Multiple Choice] What is the purpose of `depends_on`?
A) It's used to declare provider dependencies only
B) It explicitly declares a dependency between resources/modules when Terraform can't infer it automatically from references
C) It sets the order of variables
D) It locks resource versions

**Q73.** [Multiple Choice] In most cases, how does Terraform determine the order to create/update/destroy resources?
A) Alphabetical order of resource names
B) Implicitly, by building a dependency graph from references between resources in configuration
C) Random order
D) The order resources appear in the file, always

**Q74.** [Multiple Choice] What does the `terraform.workspace` expression return?
A) The path to the working directory
B) The name of the currently selected workspace
C) The Terraform CLI version
D) The backend type

**Q75.** [Multiple Choice] What is a common use case for Terraform workspaces?
A) Storing secrets
B) Managing multiple distinct states (e.g., dev/staging) from the same configuration, each with isolated state
C) Formatting code differently per environment
D) Replacing modules entirely

**Q76.** [Multiple Choice] What does the `terraform.tfvars.json` file allow compared to `terraform.tfvars`?
A) Nothing different, they're identical in every way
B) The same variable-definition purpose, but expressed in JSON syntax instead of HCL
C) It's used only for outputs
D) It stores state instead of variables

**Q77.** [Multiple Choice] What does the `try()` function do?
A) Runs a resource in "dry run" mode
B) Evaluates a list of expressions and returns the first one that doesn't produce an error
C) Retries a failed apply automatically
D) Validates provider credentials

**Q78.** [Multiple Choice] What is the difference between `variable` default values and using `coalesce()`?
A) They are the same thing
B) A default applies only when no value is supplied for that variable; `coalesce()` picks the first non-null value from a list of expressions at evaluation time
C) `coalesce()` only works on resources
D) Defaults can't be overridden, `coalesce()` can

**Q79.** [Multiple Choice] What does the `templatefile()` function do?
A) Creates a new `.tf` file
B) Renders a template file with the given variables, returning the result as a string
C) Templates a provider block
D) Copies a file to the module directory

**Q80.** [Multiple Choice] What is a "precondition" or "postcondition" block (custom conditions) used for in Terraform?
A) Formatting output
B) Validating assumptions about resource/variable values, causing a plan/apply error with a custom message if violated
C) Setting default variable values
D) Locking the state file

**Q81.** [Multiple Choice] In an expression like `var.instance_count > 0 ? "yes" : "no"`, what Terraform language feature is being used?
A) A `for` expression
B) A conditional (ternary) expression
C) A `dynamic` block
D) A `lifecycle` block

**Q82.** [Multiple Choice] What does a `for` expression like `[for s in var.list : upper(s)]` produce?
A) A single string
B) A new list with each element transformed by `upper()`
C) A map
D) A boolean

**Q83.** [Multiple Choice] What is the purpose of the `lifecycle` block argument `prevent_destroy = true`?
A) It prevents any changes to the resource whatsoever
B) It causes Terraform to reject any plan that would destroy that resource
C) It disables state tracking for the resource
D) It backs up the resource automatically

**Q84.** [Multiple Choice] What does `create_before_destroy = true` inside a `lifecycle` block change about resource replacement?
A) Nothing, it's the default behavior
B) The new resource is created before the old one is destroyed, instead of the default destroy-then-create order
C) It prevents replacement entirely
D) It only applies to modules

**Q133.** [Code/Config] variable "env_settings" {
  type = map(object({
    instance_count = number
    instance_type  = string
  }))
}
Which value correctly matches this type constraint for `env_settings`?
A) { dev = { instance_count = 1, instance_type = "t3.micro" } }
B) [ { instance_count = 1, instance_type = "t3.micro" } ]
C) { dev = "t3.micro" }
D) "dev,1,t3.micro"

**Q134.** [Scenario] You want to create one `aws_iam_user` resource per name in a variable `var.usernames` (a list of strings), and you want each instance to be addressable by the username itself (not a numeric index) so that adding a name to the middle of the list doesn't cause unrelated users to be recreated. What should you use?
A) count = length(var.usernames)
B) for_each = toset(var.usernames)
C) A single resource block with a loop inside it
D) Multiple hard-coded resource blocks

**Q135.** [True/False] True or False: The `templatefile()` function can only be used to render `.tpl` files, not any other file extension.
A) True
B) False

**Q136.** [Multiple Choice] What does the expression `[for k, v in var.settings : "${k}=${v}"]` produce, given `var.settings` is a map?
A) A map with the same keys
B) A list of strings, each formatted as "key=value"
C) A single concatenated string
D) A syntax error, since maps can't be used in for expressions

**Q137.** [Code/Config] resource "aws_security_group_rule" "ingress" {
  count             = length(var.allowed_ports)
  type              = "ingress"
  from_port         = var.allowed_ports[count.index]
  to_port           = var.allowed_ports[count.index]
  protocol          = "tcp"
  security_group_id = aws_security_group.main.id
}
If `var.allowed_ports` changes from `[80, 443]` to `[443, 80]` (order reversed), what is the likely consequence with `count`-based indexing?
A) Nothing changes, order doesn't matter to count
B) Terraform may show both rules as needing replacement/update, since the index-to-value mapping shifted even though the same values still exist
C) Terraform automatically reorders them without any plan diff
D) This causes a permanent syntax error

**Q138.** [Multiple Choice] What is the purpose of a `moved` block in Terraform configuration?
A) It records that a resource/module has been renamed or moved in configuration, so Terraform updates state addresses instead of destroying and recreating
B) It moves files on disk
C) It changes which backend stores state
D) It's used to move variables between files, purely organizational with no state effect

**Q139.** [True/False] True or False: A `precondition` block inside a `lifecycle` block is checked before the resource's changes are applied, while a `postcondition` is checked after.
A) True
B) False

**Q140.** [Scenario] You have `variable "tags" { type = map(string), default = {} }` and want to merge it with a fixed set of mandatory tags before applying them to every resource. Which function is designed for this?
A) concat()
B) merge()
C) zipmap()
D) flatten()

**Q141.** [Multiple Choice] Which of these expressions correctly uses a conditional to set an instance type based on an environment variable, defaulting to a smaller type for anything that isn't 'prod'?
A) var.env = "prod" ? "m5.large" : "t3.micro"
B) var.env == "prod" ? "m5.large" : "t3.micro"
C) if var.env == "prod" then "m5.large" else "t3.micro"
D) var.env.equals("prod") ? "m5.large" : "t3.micro"

**Q142.** [Code/Config] locals {
  is_prod = var.environment == "prod"
  replica_count = local.is_prod ? 3 : 1
}

resource "aws_instance" "app" {
  count = local.replica_count
  # ...
}
If `var.environment` is set to "staging", how many `aws_instance.app` resources will Terraform create?
A) 3
B) 1
C) 0
D) This is invalid syntax

**Q143.** [True/False] True or False: The `sensitive = true` argument can be applied to an output block to prevent its value from being shown in `terraform plan`/`apply` CLI output.
A) True
B) False

**Q144.** [Multiple Choice] What does the `flatten()` function do to a nested list like `[[1, 2], [3], [4, 5]]`?
A) Removes duplicate values
B) Produces a single flat list: [1, 2, 3, 4, 5]
C) Sorts the list numerically
D) Converts the list into a map

**Q145.** [Scenario] You want a resource block to only be created when `var.enable_feature` is true, and skipped entirely otherwise. Which is the idiomatic way to achieve this?
A) Wrap the whole resource block in an `if` statement
B) Use `count = var.enable_feature ? 1 : 0` on the resource
C) Delete the resource block manually depending on environment
D) Use a `dynamic` block around the entire resource

**Q193.** [Multiple Choice] What does `coalesce(var.custom_name, var.default_name, "fallback")` return if `var.custom_name` is null and `var.default_name` is "prod-app"?
A) null
B) "prod-app"
C) "fallback"
D) An error, since one argument is null

**Q194.** [True/False] True or False: `try(a, b, c)` will return `b` if evaluating `a` produces an error, without erroring the whole plan.
A) True
B) False

**Q195.** [Code/Config] variable "regions" {
  type = map(object({
    cidr = string
    az_count = number
  }))
}
Which value is valid for `regions`?
A) { "us-east-1" = { cidr = "10.0.0.0/16", az_count = 3 } }
B) ["us-east-1", "10.0.0.0/16", 3]
C) { cidr = "10.0.0.0/16", az_count = 3 }
D) "us-east-1:10.0.0.0/16:3"

**Q196.** [Multiple Choice] What does `templatefile("${path.module}/user_data.sh", { hostname = var.hostname })` do?
A) Copies user_data.sh into the module directory unchanged
B) Renders user_data.sh as a template, substituting ${hostname} with var.hostname's value, and returns the result as a string
C) Only works if the file is named with a .tpl extension
D) Executes user_data.sh as a shell script during plan

**Q197.** [Scenario] You renamed a resource from `aws_instance.server` to `aws_instance.app_server` in your configuration. Instead of running `terraform state mv` manually, you add this block instead:

moved {
  from = aws_instance.server
  to   = aws_instance.app_server
}

What will `terraform plan` show?
A) A destroy and recreate of the instance
B) No destructive change - Terraform recognizes the address change and updates state accordingly during apply
C) An error because moved blocks aren't supported outside HCP Terraform
D) The moved block is ignored unless -refactor flag is passed

**Q198.** [Multiple Choice] Which idiom correctly creates a resource only when `var.create_bucket` is true, using `for_each` instead of `count`?
A) for_each = var.create_bucket ? toset(["this"]) : toset([])
B) for_each = var.create_bucket
C) count = var.create_bucket
D) for_each does not support conditional creation

**Q199.** [True/False] True or False: `flatten([[1,2],[],[3]])` returns `[1, 2, 3]`, with empty inner lists simply contributing nothing.
A) True
B) False

**Q200.** [Multiple Choice] What is the purpose of a `precondition` block placed inside a data source's `lifecycle` block?
A) To validate an assumption about the data source's inputs or the environment before Terraform reads it, failing with a custom message if violated
B) To format the data source's output
C) To retry the data source read automatically on failure
D) To cache the data source's result between runs

**Q201.** [Code/Config] resource "aws_instance" "app" {
  # ...
  lifecycle {
    postcondition {
      condition     = self.instance_state == "running"
      error_message = "Instance did not reach running state."
    }
  }
}
When is this postcondition evaluated?
A) Before the resource is created, as a pre-check
B) After the resource is created/updated, validating the resulting state
C) Only during terraform destroy
D) Only when running terraform validate

**Q248.** [Code/Config] ephemeral "random_password" "db" {
  length = 16
}

resource "aws_db_instance" "example" {
  instance_class = "db.t3.micro"
  engine         = "postgres"
  username       = "admin"
  password_wo         = ephemeral.random_password.db.result
  password_wo_version = 1
}
What is true about the password value used here?
A) It is stored in plaintext in the state file, same as any other attribute
B) It is never persisted in the plan or state file - Terraform passes it to the provider during the operation and then discards it
C) It is stored in state but encrypted automatically
D) This syntax is invalid; ephemeral resources cannot feed into write-only arguments

**Q249.** [Multiple Choice] What is the purpose of the `_wo_version` argument (e.g. `password_wo_version`) that typically accompanies a write-only argument?
A) It sets which Terraform version is required to use write-only arguments
B) Since Terraform can't detect changes to a write-only value (it's never stored), incrementing the version number is how you signal to Terraform that the value should be re-sent/updated
C) It encrypts the write-only value using that version number as a key
D) It has no functional purpose, it's purely cosmetic

**Q250.** [True/False] True or False: Write-only arguments can accept both ephemeral values (like an ephemeral resource's output) and ordinary non-ephemeral values, such as a plain string.
A) True
B) False

**Q251.** [Multiple Choice] Which statement about `ephemeral` resource blocks is correct?
A) They behave exactly like data sources and are stored in state the same way
B) They represent temporary objects (like a generated password or a short-lived connection) whose data is never written to the plan or state file, and which Terraform explicitly opens and closes during each run
C) They can only be used for reading secrets from Vault, no other provider
D) They replace the need for the `sensitive` argument entirely

**Q252.** [Scenario] Before Terraform 1.10, a common problem was that fetching a secret via a `data` source resulted in that secret being written to both the plan and the state file in plaintext. Which 1.10+ feature was introduced specifically to solve this?
A) The `sensitive` argument on data sources
B) Ephemeral resources and ephemeral input variables/outputs
C) The `moved` block
D) Workspace-scoped variable sets

**Q253.** [Code/Config] variable "envs" {
  type = map(object({
    size  = string
    count = number
  }))
}
Which of these values is valid for `envs`?
A) { dev = { size = "small", count = 2 } }
B) [{ size = "small", count = 2 }]
C) { size = "small", count = 2 }
D) "dev:small:2"

**Q254.** [Multiple Choice] Given `variable "config" { type = map(object({ enabled = bool, replicas = number })) }`, which is the correct way to reference the `replicas` value for the "prod" key?
A) var.config.prod.replicas
B) var.config["prod"]["replicas"]
C) Both A and B are valid, equivalent ways to access it
D) var.config.replicas.prod

**Q255.** [Scenario] You want `aws_instance.bastion` to exist only when `var.enable_bastion` is true, using the idiomatic Terraform pattern rather than a `dynamic` block or an `if` statement (which HCL doesn't have for whole blocks).
A) Wrap the resource in a dynamic block keyed on the boolean
B) Set `count = var.enable_bastion ? 1 : 0` on the resource
C) Use an `if var.enable_bastion { ... }` wrapper
D) Manually comment the resource in/out per environment

**Q256.** [True/False] True or False: A `dynamic` block is the correct tool for making an entire resource conditionally exist based on a boolean variable.
A) True
B) False

**Q257.** [Multiple Choice] What does `merge({ team = "eng" }, { env = "prod" }, { team = "platform" })` return?
A) { team = "eng", env = "prod" }
B) { team = "platform", env = "prod" }
C) An error, since 'team' is defined twice
D) { team = ["eng", "platform"], env = "prod" }

**Q258.** [Code/Config] resource "aws_instance" "app" {
  # ...
  lifecycle {
    precondition {
      condition     = data.aws_ami.selected.architecture == "x86_64"
      error_message = "Selected AMI must be x86_64."
    }
  }
}
When does this precondition get checked?
A) After the instance is created, verifying the result
B) Before Terraform proceeds with creating/updating this resource, failing early with a clear message if the AMI doesn't match
C) Only during terraform destroy
D) Only if `terraform validate` is run separately

**Q259.** [Multiple Choice] Which function would you use to safely combine several possibly-null values, returning the first one that isn't null?
A) merge()
B) coalesce()
C) flatten()
D) zipmap()

**Q260.** [True/False] True or False: `try(a, b)` and `coalesce(a, b)` behave identically in all cases.
A) True
B) False

**Q261.** [Multiple Choice] An ephemeral input variable is declared as `variable "session_token" { type = string, ephemeral = true }`. Which statement about using this variable is correct?
A) It can be freely assigned directly to a root module output with no restriction
B) It can be referenced in other ephemeral contexts (like a write-only argument or another ephemeral resource), but cannot be assigned to a non-ephemeral root module output, since that would persist it to state
C) It behaves exactly like a normal string variable with no restrictions
D) It must always have a default value

**Q262.** [Scenario] You have `variable "db_password" { type = string, ephemeral = true }`. What does marking this variable `ephemeral = true` change, compared to just `sensitive = true`?
A) Nothing, they are exact synonyms
B) An ephemeral variable's value is never persisted to plan or state at all, and can only be used in other ephemeral contexts (like write-only arguments) - sensitive only hides it from CLI output while still storing it
C) ephemeral = true is only valid on outputs, never variables
D) ephemeral variables cannot have a default value

---

## Domain 9: HCP Terraform (Terraform Cloud) Capabilities (~10%)

**Q85.** [Multiple Choice] What is HCP Terraform (formerly Terraform Cloud) primarily used for?
A) Only local state storage
B) A managed service providing remote state, remote runs, VCS integration, policy enforcement, and collaboration features for teams
C) Replacing the Terraform CLI entirely
D) Only for billing management

**Q86.** [Multiple Choice] What is a "workspace" in HCP Terraform (as distinct from CLI workspaces)?
A) The same concept with the same scope as CLI `terraform workspace`
B) A more fully-featured unit that bundles configuration, variables, state, and run history, typically mapped to one deployable configuration
C) A billing plan tier
D) A provider plugin cache

**Q87.** [Multiple Choice] What does Sentinel (or HCP Terraform's policy-as-code features) allow an organization to do?
A) Format Terraform code automatically
B) Enforce policy checks (e.g., cost, security, compliance rules) on runs before they're applied
C) Replace the state backend
D) Manage DNS records

**Q88.** [Multiple Choice] How does HCP Terraform's remote execution mode differ from running Terraform locally?
A) There is no difference
B) Runs (plan/apply) execute on HCP Terraform's infrastructure rather than your local machine, with state and logs centrally managed
C) Remote execution disables state locking
D) It only supports `plan`, never `apply`

**Q149.** [Multiple Choice] In HCP Terraform, what is the purpose of connecting a workspace to a VCS repository (e.g. GitHub)?
A) It's purely cosmetic and has no functional effect
B) It enables automatic run triggers on commits/PRs, keeping infrastructure changes tied to code review
C) It replaces the need for a state backend
D) It disables remote execution

**Q150.** [True/False] True or False: HCP Terraform workspaces can define workspace-specific variables that aren't shared with other workspaces, even in the same organization.
A) True
B) False

**Q151.** [Multiple Choice] What is a 'variable set' in HCP Terraform used for?
A) Grouping variables so they can be reused/shared across multiple workspaces without re-entering them each time
B) Encrypting the state file
C) Defining Sentinel policies
D) Setting the Terraform CLI version only

**Q152.** [Scenario] An organization wants to enforce that no one can apply a plan that would create infrastructure outside an approved AWS region, before it ever reaches production. What HCP Terraform feature is designed for this kind of automated guardrail?
A) Remote state storage alone
B) Sentinel or OPA policy checks integrated into the run pipeline
C) VCS integration alone
D) Workspace tagging

**Q202.** [Multiple Choice] What is the purpose of HCP Terraform's private registry?
A) It hosts and versions internal/private modules and providers for an organization, similar to the public registry but access-controlled
B) It's only used for billing
C) It stores state files exclusively
D) It replaces the need for workspaces

**Q203.** [Multiple Choice] What is a 'Project' in HCP Terraform used for?
A) A billing construct only
B) A way to group related workspaces together for organization and shared access control
C) A synonym for a workspace
D) A CLI-only concept with no UI representation

**Q204.** [Scenario] Team A's workspace provisions a shared VPC. Team B's workspace needs to automatically re-run whenever Team A's VPC workspace successfully applies changes. What HCP Terraform feature is designed for this?
A) Variable sets
B) Run triggers
C) Policy sets
D) Sentinel

**Q205.** [Multiple Choice] What problem do 'dynamic provider credentials' in HCP Terraform solve?
A) They eliminate the need for providers entirely
B) They let HCP Terraform authenticate to cloud providers (AWS/Azure/GCP) using short-lived, automatically-issued credentials instead of long-lived static secrets stored as workspace variables
C) They only work with the local backend
D) They replace Sentinel policies

**Q206.** [True/False] True or False: HCP Terraform's policy enforcement supports both Sentinel (HashiCorp's own policy language) and Open Policy Agent (OPA) as policy engines.
A) True
B) False

**Q207.** [Multiple Choice] What does the HCP Terraform 'Explorer' feature provide?
A) A way to browse and query data about resources, workspaces, and their configurations across the organization
B) A code editor built into HCP Terraform
C) A replacement for terraform console
D) A local development sandbox

**Q208.** [Scenario] An organization wants every workspace under a specific project to automatically inherit the same cloud credentials without an admin re-entering them per workspace. What HCP Terraform feature accomplishes this?
A) Manually copy-pasting variables into each workspace
B) Variable sets, scoped to the project or applied globally, and inherited by workspaces automatically
C) Run triggers
D) Sentinel policies

**Q209.** [Multiple Choice] What does HCP Terraform's 'Health' feature (drift detection) help teams identify?
A) CLI version mismatches only
B) Workspaces where real infrastructure has drifted from the last known Terraform state, without requiring a manual plan check
C) Billing anomalies
D) Provider plugin bugs

**Q210.** [True/False] True or False: HCP Terraform Teams let an organization control which users can access or run specific workspaces, similar to role-based access control.
A) True
B) False

**Q211.** [Multiple Choice] What is a 'Change Request' in HCP Terraform primarily used for?
A) Requesting a refund for compute usage
B) Proposing and reviewing planned infrastructure changes collaboratively before they're applied, similar in spirit to a pull request for infrastructure
C) Changing the Terraform CLI version only
D) Requesting new provider plugins from HashiCorp

**Q263.** [Multiple Choice] What is the main distinction between an HCP Terraform 'Project' and a 'workspace'?
A) They are the same thing, just different names in the UI vs API
B) A project groups multiple related workspaces for organization and access control; a workspace is the individual unit holding one configuration's state, variables, and run history
C) Projects only exist in the free tier
D) Workspaces contain projects, not the other way around

**Q264.** [Scenario] Team A's networking workspace applies successfully, and you want Team B's application workspace to automatically queue a new run right after, since it depends on the network layer. What feature accomplishes this without manual coordination?
A) Sentinel policy
B) Run triggers
C) A shared variable set
D) VCS webhook on Team B's repo only

**Q265.** [True/False] True or False: Dynamic provider credentials in HCP Terraform rely on short-lived, automatically issued credentials (via OIDC federation) rather than long-lived static keys stored as workspace variables.
A) True
B) False

**Q266.** [Multiple Choice] Which HCP Terraform feature is designed specifically to enforce automated governance rules (e.g. 'no resources outside approved regions') before a plan can be applied?
A) Workspace tagging
B) Sentinel or OPA policy checks
C) The private registry
D) Explorer

---

# ANSWER KEY & RATIONALE

**Domain 1**
1. B - repeatability/versioning/audit trail is the core IaC value prop.
2. C - IaC doesn't auto-optimize cost with zero config; that needs deliberate design.
3. A - idempotency = same input -> same result, regardless of how many times applied.
4. B - declarative = describe the "what," not the "how."
146. B - IaC makes changes repeatable and reviewable, but it doesn't inherently guarantee zero downtime - that depends on how changes are designed and sequenced.
147. B - Declarative tools like Terraform compare desired state to current state and derive the needed actions, rather than requiring you to script each step.
212. A - Version control gives infrastructure changes the same review, history, and rollback capabilities long established for application code.
267. B - The core operational value of IaC is bringing code-review-like rigor (diffs, history, rollback) to infrastructure changes, not eliminating the need for care.
268. A - Idempotency means repeated applies of the same configuration against the same starting state converge to (and stay at) the same result, without unnecessary additional changes.

**Domain 2**
5. A - Terraform provisions infra; Ansible/Chef configure software on hosts.
6. B - one workflow/language, many providers.
7. B - Terraform commonly replaces rather than patches resources.
8. B - cloud-agnostic workflow is the differentiator vs. CloudFormation.
148. B - Multi-cloud requirements are the classic case where Terraform's cloud-agnostic provider model pays off over a single-cloud-native tool.
213. B - Terraform's declarative model diffs desired vs actual state and computes minimal necessary changes; naive imperative scripts don't inherently do this unless explicitly coded to check current state first.
269. B - This is precisely where declarative tooling shines - it inherently diffs against current state before acting, rather than blindly re-running a fixed sequence of steps.
270. B - Plan's preview-before-apply capability is a defining feature of Terraform's declarative workflow, distinguishing it from tools that execute changes without a review step.

**Domain 3**
9. B - terraform block + providers + resources/data sources form the core.
10. B - providers are plugins that talk to an API.
11. B - `required_providers` inside `terraform {}`.
12. C - `~>` pessimistic constraint allows patch upgrades only, for `~> 4.16` (implicitly `4.16.x`).
13. B - no constraint = latest available at init time.
14. B - `<TYPE>.<NAME>.<ATTRIBUTE>`.
15. B - data sources are read-only lookups.
16. B - `output` blocks expose values.
17. B - variables are external inputs; locals are internal computed names.
18. B - `terraform.tfvars` auto-loads.
19. B - CLI flags > auto.tfvars > terraform.tfvars > env vars > defaults.
20. A - HashiCorp Configuration Language.
89. B - Locals are private to the module they're defined in. To expose a computed value to a caller, you must expose it via an `output` block, not by referencing the local directly.
90. C - CLI -var/-var-file flags have the highest precedence, overriding tfvars files and defaults.
91. B - Combined constraints are AND-ed together: >= 4.0 sets the floor, < 5.0 sets the ceiling, so any 4.x version qualifies.
92. B - Complex type constraints use the constructor syntax, e.g. list(string), map(number), object({...}).
93. B - nullable = false enforces that the variable can never be assigned a null value, whether or not a default exists.
94. A - Terraform builds the dependency graph from these references and resolves the actual value at apply time; you don't need the resource to already exist to reference it in config.
95. B - If no type constraint is given, Terraform defaults to accepting any type.
96. A - `provider "aws" { alias = "east" }` lets you define a second named provider configuration, referenced in a resource with `provider = aws.east`.
97. B - The address is Terraform's internal reference; id is a provider-specific attribute (e.g. an AWS instance ID) exposed on the resource.
98. B - Outputs are computed after the referenced resource is created/updated, so the ARN is known and printed once apply completes.
99. B - count.index is zero-based, so count = 3 produces indices 0, 1, and 2.
100. A - TF_VAR_<name> environment variables map directly to input variables of the same name, though they rank below CLI flags and tfvars files in precedence.
153. C - Locals are private to the module that defines them. The only way for a caller to see a computed value is if the child module explicitly exposes it via an output block.
154. D - Valid variable arguments include type, default, description, sensitive, nullable, and validation blocks. `readonly` is not a real argument.
155. B - Variable validation blocks run early and block the entire plan/apply with the custom error_message if the condition fails.
156. A - Omitting the type constraint entirely defaults to accepting any type, same as explicitly writing type = any.
157. B - A second provider configuration needs the `alias` argument, and consuming resources set `provider = aws.<alias>` to use it instead of the default.
158. B - TF_VAR_<name> is a standard way to supply variable values (including sensitive ones), and sensitive = true independently controls whether the value is masked in CLI output.
159. B - Indexing is 0-based, so count = 5 produces indices 0 through 4 - the last instance's index is 4.
160. B - The != operator excludes a specific version while allowing all others - useful for excluding a known-broken release.
161. A - Data sources are strictly read-only lookups; only resource blocks cause Terraform to manage (create/update/destroy) the object's lifecycle.
162. B - sensitive = true on a variable propagates that masking to any place the value surfaces in CLI output, similar to sensitive outputs.
163. B - nullable = false means null is never an acceptable value for that variable, regardless of whether a default is defined - an explicit null still errors.
164. A - Locals are a convenience for internal computation/reuse; outputs are the explicit, intentional interface a module exposes outward.
165. A - The lock file pins exact provider versions/hashes for reproducibility across team members and CI, and HashiCorp recommends committing it.
214. B - A variable declared with no type constraint at all defaults to accepting any type - this is not a syntax error, and applies equally to root and child module variables.
215. B - sensitive = true only suppresses the value from ordinary CLI output (plan/apply/output). It does nothing to how the value is stored in state - it remains in plaintext there unless the backend itself provides encryption.
216. B - sensitive is purely a CLI-output control. State file contents are unaffected by it - the value is there in plaintext just like any other tracked value.
217. B - Once a sensitive value flows into an output, Terraform requires that output to also be marked sensitive, otherwise it flags the leak - propagation of sensitivity through expressions is enforced.
218. A - `replace_triggered_by` inside lifecycle lets you force replacement whenever a referenced value changes, independent of the provider's own schema-level ForceNew behavior.
219. A - nullable = false forbids an explicit null value regardless of whether a default exists - the default only covers the case where no value is supplied at all, not an explicit null.
220. A - Constraints are AND-combined, so you can set a floor with >= and separately exclude one problematic version with !=.
221. B - This is precisely why nullable exists as a separate control from default - defaults handle absence, nullable handles explicit null, and they solve different problems.

**Domain 4**
21. B - `fmt` rewrites style, doesn't touch state.
22. A - `validate` checks syntax/internal consistency, no API calls.
23. B - `terraform state list`.
24. B - taint marks for recreation on next apply.
25. B - `terraform apply -replace=`.
26. B - console is an interactive expression evaluator.
27. A - `graph` visualizes the dependency graph.
28. B - `-target` restricts scope to a resource + its dependencies.
29. B - repeated use risks state/config drift; it's meant as an exception, not routine practice.
30. B - `output` prints root module output values.
31. B - `init` sets up the working directory.
32. B - `-upgrade` updates providers/modules within constraints and updates the lock file.
33. B - import attaches existing infra to state only.
34. B - you must hand-write matching config after import.
101. B - `plan` (which includes a refresh) will detect the drift - the resource missing from real infrastructure - and show a proposal to recreate it, without making any changes yet.
102. B - `terraform state mv` re-addresses an existing state entry to a new resource address without touching real infrastructure.
103. A - The -recursive flag extends formatting to subdirectories rather than just the current one.
104. A - -get=false skips downloading modules, useful when they're already vendored/cached locally.
105. B - `terraform providers` gives a summary of which providers are required, including transitively through modules.
106. B - -replace targets a specific resource for forced replacement (destroy + recreate) while leaving the rest of the plan driven by normal diff logic.
107. B - validate only checks syntax and internal consistency (types, references) - it does not contact any remote API.
108. C - console is a read-only REPL for evaluating expressions against current state/config; it cannot apply changes.
109. B - Import only populates state - you must hand-write a resource block whose arguments match reality, or plan will show a diff trying to reconcile config with the imported state.
110. B - -lock=false bypasses the lock check for just that command invocation; it's risky since it can allow concurrent writes.
111. A - The -json flag is commonly used to feed Terraform outputs into external scripts or CI pipelines.
112. B - `terraform show` renders the state (or a saved plan file) in a readable format.
166. A - `state mv` re-addresses the existing state entry to match the renamed resource block, avoiding a destroy/recreate. (A `moved` block in configuration is the newer declarative alternative.)
167. B - `terraform show` renders the entire state (or a plan file, if given one) in readable form; `state show` (with an address) is scoped to a single resource, and `state list` only prints addresses, not attributes.
168. B - Terraform's verbose logging is controlled via the TF_LOG environment variable (levels include TRACE, DEBUG, INFO, WARN, ERROR), not a CLI flag.
169. A - TF_LOG=JSON produces structured JSON log output, in addition to the standard level-based logging (TRACE/DEBUG/INFO/WARN/ERROR).
170. B - TF_LOG_PATH redirects the verbose log output to a file, useful for capturing logs from CI runs or long apply operations.
171. B - A clean plan after import simply means your resource block's arguments already match reality - which is the goal, since import never edits your .tf files for you.
172. B - -reconfigure disregards any existing backend configuration and reconfigures it fresh, useful when backend settings have changed significantly.
173. A - console is commonly used exactly this way - a safe sandbox to try expressions/functions against current state and variables.
174. B - `terraform state show <address>` gives detailed attributes for one specific resource address, including ones nested inside modules.
175. B - `terraform apply -replace=` was introduced as the direct replacement for the older `terraform taint` workflow, doing the forced replacement in a single explicit step.
176. A - -input=false disables interactive prompts (good for CI), and a populated provider cache/lock file avoids unnecessary re-downloads.
177. A - list gives you the inventory of addresses; show drills into one address's full attribute detail.
178. A - Adding/changing required_providers changes what needs to be installed, so init must be re-run to download the new provider.
222. B - This is worth memorizing precisely because it's been a recurring point of confusion: console never applies, creates, or modifies infrastructure under any circumstance.
223. B - console's sole purpose is evaluating expressions/functions interactively - a sandbox for checking behavior, never for making changes.
224. A - -target works with destroy exactly as it does with apply/plan - it scopes the operation to the named resource and anything depending on it, not everything in state.
225. B - This claim is false - -target is fully supported with destroy, letting you scope removal to one resource (plus dependents) rather than the whole configuration.
226. B - state mv directly re-addresses the state entry with no provider API calls to create/destroy - refresh only reconciles state with reality, it does not rename addresses.
227. B - refresh only updates attribute values to match real infrastructure - it has no concept of address renaming. Renaming requires state mv or a moved block.
228. B - state mv (re-address, no API calls) and refresh (reconcile values, no re-addressing) are frequently confused despite doing fundamentally different things.
229. B - state mv works across module namespaces too - it's a pure state re-addressing operation, useful when refactoring which module a resource lives under.

**Domain 5**
35. B - module = reusable container of resources.
36. B - root module = the main working directory's config.
37. B - local path source uses `./` or `../` prefix.
38. B - `<NAMESPACE>/<NAME>/<PROVIDER>` registry format.
39. B - inputs are passed as arguments matching the module's declared variables.
40. B - `module.<name>.<output>`.
41. B - version constraints apply to registry-sourced modules (not local paths).
42. B - reuse/standardization/reduced duplication.
113. B - When a module block uses for_each, its instances are addressed with the key in brackets, same pattern as resources.
114. B - Local path sources are read directly from disk on every run; version constraints only apply to sources that support versioning, like the public/private registry.
115. B - A variable without a default is required; omitting it from the module block causes an error.
116. B - Each module block is independently named and configured; calling the same source twice under different names/inputs is a standard pattern.
117. B - Reusable modules should be parameterized via variables and expose necessary values via outputs, keeping internals otherwise encapsulated.
118. A - To reference module.network.subnet_ids, the child module must expose an output block called subnet_ids returning that value.
119. A - Terraform supports module composition/nesting with no hard enforced depth limit, though excessive nesting hurts readability.
120. A - `terraform get` downloads/updates modules; `terraform init` calls this internally as part of its setup.
179. B - The standard reference pattern is module.<local_name>.<output_name>.
180. B - Each module block's local name (staging_network, prod_network) becomes the addressing key - not a shared 'network' name unless that's literally the block's label.
181. A - Child modules can specify their own provider version constraints, which combine with the root module's constraints during init.
182. B - Registry modules rely on semantic version tags in the source repository; the registry indexes these to serve specific versions.
230. B - for_each-based module instances are addressed the same way for_each resources are: module.<name>[<key>].<output>.
231. B - count-based module instances use bracketed numeric indices, just like count-based resources: module.<name>[<index>].<output>.
232. A - A plain (non-multi-instance) module block is referenced directly with no bracket/index needed.
233. B - Addressing always uses the module block's own local label (staging, prod) - not the source path - as the key in module.<label>.<output>.
234. C - This is the false statement - nothing inside a module is visible to the caller unless explicitly exposed via an output block. The other three statements are true.
235. B - With for_each using a map, the key ("data") is what addresses the specific instance: module.<name>["<key>"].<output>.

**Domain 6**
43. B - init -> plan -> apply.
44. B - plan previews, doesn't change anything.
45. B - saved plan guarantees exactly what was reviewed gets applied.
46. B - prevents drift between review and execution, important in CI/CD.
47. B - skips the manual "yes" prompt.
48. B - destroy removes everything tracked in state for that config/workspace.
49. A - `-target` works with destroy too, for scoped deletion.
50. B - refresh reconciles state with real infra before planning.
51. B - drift is surfaced in the plan, with proposed reconciling changes.
52. B - validate (and plan, which calls it) catches syntax errors early.
53. B - apply re-plans and prompts unless given a saved plan file.
54. B - reviewing before applying reduces risk of unintended changes.
121. B - Terraform checks that the state hasn't changed since a saved plan was generated; if it has, it refuses to apply the now-stale plan.
122. A - destroy also requires typing 'yes' to confirm by default, unless -auto-approve is passed.
123. B - -/+ denotes a destroy-then-create replacement, as opposed to ~ (in-place update) or + / - alone.
124. B - Attributes marked as forcing replacement in the provider schema trigger a destroy/recreate rather than an in-place update.
125. B - -destroy on plan generates a plan showing what would be destroyed, without actually destroying anything - a dry run of destroy.
126. A - Terraform updates state incrementally as resources are created/changed, so an interruption can leave a partial apply; re-running plan shows the remaining delta.
183. B - -target works with destroy too, scoping the destroy operation to just that resource and its dependents.
184. B - plan -destroy generates a preview of what a real destroy would do, without executing it - a genuine dry run.
185. A - Refresh only updates Terraform's understanding of state vs. reality; it never touches your .tf configuration files.
186. B - Refresh-only mode surfaces drift for review/acceptance into state, without generating a plan to reconcile it back to match configuration.
236. B - -target with destroy scopes the removal to the named resource plus its dependents - this is a valid, documented pattern despite being an exception rather than routine use.
237. A - Terraform validates that state hasn't changed since the plan was generated - if it has, apply refuses to use the now-stale plan rather than applying it blindly.
238. B - -/+ specifically denotes a destroy-then-create replacement, distinct from ~ (update in place).
239. B - plan -destroy is the genuine dry-run equivalent of destroy - it computes and shows the plan without executing it.

**Domain 7**
55. B - state maps config to real resources + tracks metadata/dependencies.
56. B - backend = where/how state is stored.
57. B - shared access + locking avoids team conflicts.
58. B - locking prevents concurrent writes corrupting state.
59. B - S3+DynamoDB, Azure Storage, GCS, HCP Terraform all support locking.
60. B - `terraform state mv` re-addresses without destroy/recreate.
61. B - `state rm` detaches from state only, doesn't touch real infra.
62. B - manual edits risk corrupting state; use `terraform state` commands.
63. B - lists resource addresses in state.
64. B - sensitive attribute values can appear in plaintext in state.
65. B - `sensitive = true` hides values from CLI output, but they're still in state (unencrypted by default).
66. B - the second operation is blocked until the lock releases.
127. B - State locking (via the DynamoDB table, in this backend) prevents concurrent writes; the second operation is blocked until the lock is released.
128. B - State can hold sensitive plaintext values; encrypting the backend storage is a mitigation, since Terraform itself doesn't encrypt state by default.
129. A - state show prints all tracked attributes for one specific resource address from the state file.
130. B - state rm only detaches the resource from Terraform's state; it never touches the real infrastructure, and it doesn't edit .tf files either.
131. B - Changing the backend block requires re-running init, which detects the backend change and prompts to copy existing state to the new backend.
132. A - Both -target and manual state surgery are meant as exceptions for fixing specific problems, not as a routine workflow - repeated use risks drift between state and config.
187. B - The `removed` block lets you declare in configuration that Terraform should stop managing a resource (optionally without destroying it), leaving a clear audit trail versus an ad-hoc state rm.
188. B - sensitive = true is a CLI-output mask, not encryption - defaults committed to version control are still plaintext in your repo, and values still land in state. Real secrets should come from a secrets manager like Vault, not hardcoded defaults.
189. B - The Vault provider exposes data sources (e.g. for reading KV secrets) that let Terraform pull secrets dynamically at runtime rather than storing them in plaintext files.
190. A - sensitive only affects CLI/log display; state file contents aren't automatically encrypted by Terraform itself - backend-level encryption (e.g. S3 SSE) is what actually protects state at rest.
191. A - moved handles renames/refactors while keeping the resource managed; removed is for deliberately dropping management of a resource, with an option to also destroy it or leave it alone.
192. A - destroy = false tells Terraform to drop the resource from state/management without touching the actual infrastructure - the real instance keeps running, just outside Terraform's control.
240. B - The import block (Terraform 1.5+) lets you declare an import as part of normal configuration - terraform plan previews it and terraform apply executes it, unlike the older CLI-only terraform import workflow.
241. A - When paired with -generate-config-out, Terraform can write a best-effort starting resource configuration based on the imported object's actual attributes, which you then review and refine.
242. B - The core benefit is workflow integration: import intent lives in code, gets reviewed via plan, and executes via apply - versus the CLI command which is an untracked, one-off imperative step.
243. B - for_each on an import block (Terraform 1.7+) lets you bulk-import a whole collection of similar resources without writing a separate import block for each one.
244. A - Once the resource is imported and matches state, the import block no longer does anything on subsequent runs - it's safe to leave as documentation of the import's origin, or delete it.
245. B - The id must match exactly what the provider expects to identify that specific resource type (e.g. an instance ID, ARN, or bucket name) - format varies by provider and resource type.
246. B - Declarative import blocks fit naturally into a PR-based review workflow since they're just configuration - the plan output shows exactly what will be imported before anyone applies it.
247. C - id and identity are mutually exclusive ways of specifying which real-world object to import - identity is an alternative, provider-defined way to uniquely identify a resource instead of a single ID string.

**Domain 8**
67. B - `count` creates N instances, indexed via `count.index`.
68. B - `for_each` keys instances by map/set value, more stable under collection changes.
69. B - type constraints are enforced (Terraform errors or attempts conversion).
70. A - `lookup(map, key, default)`.
71. B - `dynamic` blocks generate repeated nested blocks from a collection.
72. B - `depends_on` makes an implicit dependency explicit when references alone don't capture it.
73. B - dependency graph built from references in config.
74. B - returns the current workspace name.
75. B - isolating state per environment from shared config.
76. B - same purpose, JSON syntax instead of HCL.
77. B - `try()` returns the first expression that doesn't error.
78. B - default = fallback when unset; `coalesce()` = first non-null among given expressions.
79. B - renders a template file into a string.
80. B - custom conditions validate assumptions, erroring with a custom message if violated.
81. B - ternary conditional expression.
82. B - `for` expression transforms into a new list.
83. B - `prevent_destroy` blocks any plan that would destroy the resource.
84. B - create_before_destroy flips the default destroy-then-create order.
133. A - The type is a map keyed by strings (env names), whose values are objects with instance_count (number) and instance_type (string) - option A matches that shape.
134. B - for_each with a set keys each instance by its value (the username), so inserting/removing an item doesn't shift other instances' indices/identities like count would.
135. B - templatefile() works with any file extension; .tpl is just a common convention, not a requirement.
136. B - This for expression iterates key/value pairs and builds a list of formatted strings, one per map entry.
137. B - With count, identity is tied to index position, not value - reordering the list changes what's 'at' each index, causing unnecessary diffs. This is exactly the kind of case for_each avoids.
138. A - moved blocks let Terraform automatically handle a refactor (renamed resource/module) by updating the state address, avoiding an unwanted destroy/recreate.
139. A - Preconditions validate assumptions before the associated action; postconditions validate the resulting state afterward.
140. B - merge() combines multiple maps into one, with later arguments' keys overriding earlier ones on conflict - the standard pattern for combining default + mandatory tags.
141. B - HCL's ternary conditional uses `condition ? true_val : false_val`, and equality comparison uses ==, not =.
142. B - is_prod evaluates to false since environment isn't 'prod', so replica_count resolves to 1, and count = 1 creates a single instance.
143. A - Marking an output sensitive suppresses it from ordinary CLI output (it still exists in state and can be retrieved deliberately via `terraform output`).
144. B - flatten() collapses nested lists into a single-level list, commonly used when combining outputs of multiple for expressions or modules.
145. B - HCL has no `if` statement for whole blocks; the standard idiom for conditional resource creation is count = condition ? 1 : 0 (or for_each with an empty vs. populated set/map).
193. B - coalesce() returns the first non-null argument in order - it skips the null custom_name and returns the next one, prod-app.
194. A - try() evaluates its arguments in order and returns the first one that doesn't produce an error - if a errors, it moves on to b.
195. A - The type requires a map keyed by strings whose values are objects with cidr (string) and az_count (number) - only option A matches that shape.
196. B - templatefile() renders any given file as a template with the supplied variables and returns the rendered content as a string - it works with any file extension.
197. B - moved blocks let Terraform handle renames declaratively - plan shows the state address update rather than a destroy/recreate, and it's just standard open-source Terraform functionality.
198. A - for_each requires a map or set; a common idiom for conditional creation is toggling between an empty set and a single-element set based on the condition.
199. A - flatten() collapses nested lists into a single level; empty inner lists just add no elements to the result.
200. A - Preconditions let you assert something must be true before an action proceeds (on resources or data sources), giving clearer custom errors than a generic provider failure.
201. B - Postconditions validate the resulting state of a resource after the apply action affecting it completes, catching bad outcomes early with a clear custom message.
248. B - This is exactly what ephemeral resources + write-only arguments (Terraform 1.10/1.11+) are for: the value flows from the ephemeral resource into the write-only argument and is used by the provider, but Terraform never writes it to plan or state.
249. B - Because write-only values aren't tracked in state, Terraform has no way to detect a change on its own - bumping the paired version argument is the signal that tells Terraform to push the new value to the provider.
250. A - Unlike ephemeral resources/variables, write-only arguments aren't restricted to ephemeral-only inputs - they accept any value, ephemeral or not, while still never persisting it to state or plan.
251. B - Ephemeral resources are a distinct third resource mode (alongside managed resources and data sources) specifically designed to avoid persisting anything about them into Terraform's artifacts.
252. B - Ephemeral values (ephemeral resources, ephemeral variables/outputs) were introduced in Terraform 1.10 specifically to let secrets be used during a run without ever landing in plan or state artifacts.
253. A - This type requires a map keyed by strings (environment names), with each value being an object matching {size: string, count: number} - only option A has that exact shape.
254. C - HCL supports both dot notation and bracket notation for accessing map/object values - they're interchangeable for this purpose.
255. B - This is the standard, idiomatic pattern for conditional resource creation - dynamic blocks are for repeating nested blocks within a resource, not for conditionally creating the resource itself.
256. B - dynamic blocks generate repeated nested configuration blocks (like multiple ingress rules) within a resource - they don't control whether the resource itself exists. That's count or for_each's job.
257. B - merge() combines maps left to right, with later arguments' keys overriding earlier ones on conflict - the final 'team' value wins.
258. B - Preconditions validate assumptions before the associated action proceeds, catching a bad AMI choice with a clear message rather than a confusing provider-level error later.
259. B - coalesce() is specifically for this: it evaluates arguments in order and returns the first non-null one.
260. B - They solve different problems: try() catches errors during expression evaluation and moves to the next expression; coalesce() specifically skips null values, not errors - a value can be non-null but still cause an error elsewhere, or vice versa.
261. B - Ephemeral values can only flow into other ephemeral-compatible places. Assigning one to an ordinary root module output would defeat the purpose, since outputs are stored in state - Terraform disallows this.
262. B - This is the key distinction driving the whole 1.10+ ephemeral feature set: sensitive hides from display but still stores the value; ephemeral means the value genuinely never touches plan/state artifacts, at the cost of being usable only in ephemeral-compatible contexts.

**Domain 9**
85. B - HCP Terraform = managed remote state/runs/VCS/policy/collaboration.
86. B - HCP Terraform workspaces bundle config, vars, state, run history.
87. B - Sentinel/policy-as-code enforces rules before runs apply.
88. B - remote execution runs plan/apply on HCP Terraform's infra, not locally.
149. B - VCS-connected workspaces can trigger plans/applies automatically on commits or PRs, integrating infra changes into the normal code review flow.
150. A - Each HCP Terraform workspace has its own variable set, distinct from other workspaces, unless deliberately shared via variable sets.
151. A - Variable sets let you define common variables (e.g. cloud credentials) once and attach them to multiple workspaces, avoiding duplication.
152. B - Policy-as-code (Sentinel/OPA) is specifically designed to enforce rules like allowed regions automatically as part of the run, before an apply can proceed.
202. A - The private registry lets organizations publish and consume their own modules/providers with the same versioning UX as the public registry, but scoped to their org.
203. B - Projects let teams organize multiple related workspaces (e.g. all workspaces for one application) and manage access at that grouped level.
204. B - Run triggers let one workspace automatically queue a run in another workspace when the source workspace completes a successful apply - useful for dependent infrastructure layers.
205. B - Dynamic credentials use OIDC-based identity federation so HCP Terraform runs can authenticate to cloud providers without storing long-lived access keys as variables.
206. A - HCP Terraform supports both Sentinel and OPA as pluggable policy-as-code engines for enforcing governance rules on runs.
207. A - Explorer provides organization-wide visibility into workspaces, resources, and their metadata, useful for governance and auditing at scale.
208. B - Variable sets let you define variables once (like shared cloud credentials) and apply them across multiple workspaces or projects, avoiding manual duplication.
209. B - Health/drift detection proactively flags workspaces where infrastructure has drifted from state, without waiting for someone to manually run a plan to notice.
210. A - Teams in HCP Terraform are groups of users with configurable permissions on workspaces/projects, forming the basis of its access control model.
211. B - Change Requests support a review workflow around proposed infrastructure changes, bringing PR-like collaboration to the plan/apply process.
263. B - Projects sit a level above workspaces, grouping several related workspaces (e.g. all workspaces for one application) for shared organization and access management.
264. B - Run triggers exist specifically to chain dependent workspace runs - queuing a downstream workspace's run automatically when an upstream workspace successfully applies.
265. A - Dynamic credentials use OIDC-based identity federation, letting HCP Terraform authenticate to cloud providers without ever storing a long-lived static access key as a workspace variable.
266. B - Policy-as-code via Sentinel or OPA is the mechanism for enforcing automated guardrails on runs before they're allowed to apply.
