# Terraform Associate 004 - Mock Question Bank
**Batch 1 + Batch 2 combined (Q1-152)** - Weighted to the official 004 exam blueprint, with extra weight on Domains 3/4/5/8 based on your last practice result. Answer key with rationale at the end.

Question types used: Multiple Choice, Scenario-based, Code/Config snippet, True/False

---

## Domain 1: Understand Infrastructure as Code (IaC) Concepts (~5%)

**Q1.** [Multiple Choice] What is the main advantage of IaC over manually provisioning infrastructure through a cloud console?
A) It removes the need for a cloud provider account
B) It makes infrastructure changes repeatable, versionable, and auditable
C) It guarantees zero downtime deployments
D) It eliminates the need for a state file

**Q2.** [Multiple Choice] Which of the following is NOT typically a benefit of using IaC?
A) Consistency across environments
B) Faster provisioning through automation
C) Automatic cost optimization with no configuration
D) Version-controlled infrastructure history

**Q3.** [Multiple Choice] In IaC terminology, what does "idempotency" mean?
A) Applying the same configuration multiple times produces the same end state
B) Configuration can only be applied once
C) Resources are destroyed after every apply
D) State files are encrypted by default

**Q4.** [Multiple Choice] Which statement best describes a declarative approach to IaC (as opposed to imperative)?
A) You write step-by-step commands to reach the desired state
B) You describe the desired end state and let the tool figure out how to get there
C) You must manually track the order of resource creation
D) It only works with shell scripts

**Q146.** [True/False] True or False: IaC guarantees that infrastructure changes will never cause downtime.
A) True
B) False

**Q147.** [Multiple Choice] Which of the following is a direct consequence of infrastructure being defined declaratively rather than imperatively?
A) You must always specify the exact order of operations yourself
B) The tool can compute a diff between desired and current state and figure out the necessary steps
C) Declarative tools cannot manage cloud resources
D) There is no practical difference in tooling behavior

---

## Domain 2: Understand Terraform's Purpose (vs other IaC) (~5%)

**Q5.** [Multiple Choice] How does Terraform differ from configuration management tools like Ansible or Chef?
A) Terraform is primarily used for provisioning infrastructure, while CM tools focus on configuring software on existing servers
B) Terraform cannot manage cloud resources
C) Ansible requires a state file, Terraform does not
D) There is no meaningful difference

**Q6.** [Multiple Choice] Which of the following is a key advantage of Terraform's multi-cloud support?
A) It automatically migrates resources between providers
B) A single workflow and language can manage resources across multiple providers
C) It removes the need for provider-specific credentials
D) It only supports AWS and Azure

**Q7.** [Multiple Choice] What is a key difference between mutable and immutable infrastructure paradigms, and where does Terraform typically fit?
A) Terraform only supports mutable infrastructure
B) Terraform can support both, but is often used to replace resources rather than patch them in place, favoring immutability
C) Immutable infrastructure cannot be described in code
D) Mutable infrastructure requires no state tracking

**Q8.** [Multiple Choice] Why might a team choose Terraform over a cloud-specific tool like AWS CloudFormation?
A) CloudFormation is faster in all cases
B) Terraform provides a cloud-agnostic workflow usable across multiple providers and services
C) CloudFormation cannot create VPCs
D) Terraform does not support AWS

**Q148.** [Scenario] A team is deciding between Terraform and a cloud-provider-specific IaC tool for a project that must eventually span AWS and GCP. Which factor most strongly favors Terraform?
A) Cloud-specific tools are always faster to write
B) Terraform's provider model lets the same workflow and language extend across multiple clouds
C) Cloud-specific tools support more resource types in general
D) There is no meaningful difference for multi-cloud projects

---

## Domain 3: Understand Terraform Basics (~15%)

**Q9.** [Multiple Choice] What are the three main sections typically found in a Terraform configuration file?
A) Providers, resources, and modules only
B) Terraform settings block, providers, and resources/data sources (plus optional variables/outputs)
C) Only resources
D) Backend, provider, and outputs only

**Q10.** [Multiple Choice] What is the purpose of a Terraform provider?
A) It stores the state file
B) It is a plugin that lets Terraform interact with an API (cloud platform, SaaS, etc.)
C) It compiles the Terraform binary
D) It only manages variables

**Q11.** [Multiple Choice] Where are providers typically declared for version constraints in modern Terraform?
A) In the `provider` block only
B) In the `required_providers` block inside `terraform {}`
C) In `variables.tf`
D) In the state file

**Q12.** [Multiple Choice] What does the following version constraint mean? `version = "~> 4.16"`
A) Any version greater than 4.16
B) Only version 4.16 exactly
C) Any version >= 4.16.0 and < 4.17.0 (allows patch-level updates only)
D) Any version below 4.16

**Q13.** [Multiple Choice] What happens if you don't specify a version constraint for a provider?
A) Terraform will refuse to run
B) Terraform will download the latest version available at init time
C) Terraform uses version 1.0.0 by default
D) It causes a syntax error

**Q14.** [Multiple Choice] What is the correct syntax to reference an attribute from a resource named `aws_instance.web`?
A) `aws_instance[web]`
B) `aws_instance.web.id`
C) `resource.aws_instance.web`
D) `web.aws_instance.id`

**Q15.** [Multiple Choice] What is a Terraform "data source" used for?
A) To create new infrastructure
B) To fetch read-only information about existing infrastructure or external data, for use elsewhere in configuration
C) To store the state file remotely
D) To define input variables

**Q16.** [Multiple Choice] Which block type would you use to expose a value from a root module for use by other configurations or the CLI?
A) `variable`
B) `output`
C) `local`
D) `data`

**Q17.** [Multiple Choice] What is the difference between an input variable and a local value in Terraform?
A) There is no difference
B) Input variables are parameters supplied to a module; locals are computed/named values reused within a module and not meant to be set externally
C) Local values can be set on the CLI with `-var`
D) Input variables cannot have default values

**Q18.** [Multiple Choice] Which file, if present, does Terraform automatically load to set variable values without needing `-var-file`?
A) `main.tf`
B) `terraform.tfvars`
C) `outputs.tf`
D) `providers.tf`

**Q19.** [Multiple Choice] What is the correct order of precedence (highest to lowest) for variable value sources in Terraform?
A) Environment variables > tfvars files > CLI `-var` flags > defaults
B) CLI `-var`/`-var-file` flags > `*.auto.tfvars` > `terraform.tfvars` > environment variables (`TF_VAR_`) > defaults
C) Defaults always win
D) `terraform.tfvars` always overrides CLI flags

**Q20.** [Multiple Choice] What does HCL stand for?
A) HashiCorp Configuration Language
B) High-level Cloud Language
C) Hosted Configuration Layer
D) Hybrid Cloud Language

**Q89.** [True/False] True or False: A `local` value defined inside a module can be referenced directly from the module that calls it, the same way an output can.
A) True
B) False

**Q90.** [Scenario] You declare `variable "region" { type = string, default = "us-east-1" }`. On the CLI you run `terraform apply -var="region=us-west-2"` while a `terraform.tfvars` file in the same directory also sets `region = "eu-west-1"`. Which value does Terraform use for `region`?
A) us-east-1 (the default)
B) eu-west-1 (from terraform.tfvars)
C) us-west-2 (from the -var flag)
D) Terraform throws a conflict error

**Q91.** [Code/Config] Given this block:
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 4.0, < 5.0"
    }
  }
}
Which installed AWS provider versions satisfy this constraint?
A) Only exactly version 4.0
B) Any version from 4.0.0 up to (but not including) 5.0.0
C) Any version 5.0 or higher
D) Any version at all, the constraint is ignored

**Q92.** [Multiple Choice] Which of the following correctly declares an input variable with a type constraint of a list of strings?
A) variable "names" { type = list }
B) variable "names" { type = list(string) }
C) variable "names" { type = "list-string" }
D) variable "names" { list = string }

**Q93.** [Multiple Choice] What is the effect of declaring `variable "x" { type = string, nullable = false }` without a default?
A) Nothing changes, nullable has no effect without a default
B) Terraform requires a non-null value to be supplied; passing null will cause an error
C) Terraform silently converts null to an empty string
D) nullable is not a valid argument for variables

**Q94.** [True/False] True or False: You can reference a resource's attribute in an expression before that resource has actually been created on the provider's platform, as long as the reference is valid within the configuration.
A) True
B) False

**Q95.** [Scenario] A teammate declares `variable "instance_type" {}` with no `type` argument at all. What type does Terraform assume?
A) string
B) any
C) It's a syntax error - type is mandatory
D) null

**Q96.** [Multiple Choice] Which statement about provider configuration aliases is correct?
A) Aliases let you configure multiple instances of the same provider (e.g. two AWS regions) in one configuration
B) Aliases are used to rename a resource type
C) Aliases only work with the local backend
D) Each provider can only ever have one configuration, aliases are not supported

**Q97.** [Multiple Choice] Which best describes the difference between a resource's `id` and its resource address (e.g. `aws_instance.web`)?
A) They are always identical strings
B) `id` is a provider-assigned attribute of the real infrastructure object; the resource address is how Terraform refers to it in configuration/state
C) The resource address is only used inside modules
D) `id` is only available after `terraform destroy`

**Q98.** [Code/Config] resource "aws_s3_bucket" "data" {
  bucket = "my-app-data"
}

output "bucket_arn" {
  value = aws_s3_bucket.data.arn
}
What will happen if you run `terraform apply` with this configuration?
A) It will fail because `arn` isn't a valid attribute
B) It creates the bucket, then outputs the ARN once known after creation
C) It only prints the ARN without creating anything
D) Outputs cannot reference resource attributes

**Q99.** [Multiple Choice] In Terraform 0.13+, what does the `count.index` value represent inside a resource using `count = 3`?
A) A random UUID for the instance
B) The 0-based position of the current instance (0, 1, 2)
C) The 1-based position of the current instance (1, 2, 3)
D) The total number of instances (3)

**Q100.** [True/False] True or False: Environment variables prefixed with TF_VAR_ can be used to set Terraform input variable values.
A) True
B) False

---

## Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)

**Q21.** [Multiple Choice] What does `terraform fmt` do?
A) Formats the state file
B) Rewrites configuration files to a canonical style and formatting
C) Validates provider credentials
D) Deletes unused resources

**Q22.** [Multiple Choice] What is the purpose of `terraform validate`?
A) It checks configuration syntax and internal consistency without accessing remote services
B) It applies the configuration
C) It formats code
D) It checks cloud provider billing

**Q23.** [Multiple Choice] Which command would you use to see a list of resources currently tracked in the state?
A) `terraform show`
B) `terraform state list`
C) `terraform plan`
D) `terraform get`

**Q24.** [Multiple Choice] What does `terraform taint` (or its modern replacement) do?
A) Deletes a resource from the state permanently with no replacement
B) Marks a resource for recreation on the next apply
C) Locks the state file
D) Formats the configuration

**Q25.** [Multiple Choice] In modern Terraform (0.15.2+), what is the recommended replacement for `terraform taint`?
A) `terraform destroy -target`
B) `terraform apply -replace="resource.address"`
C) `terraform refresh`
D) `terraform state rm`

**Q26.** [Multiple Choice] What does `terraform console` allow you to do?
A) Deploy resources interactively
B) Evaluate expressions and inspect values in an interactive REPL against the current state
C) Edit the state file directly
D) SSH into a provisioned instance

**Q27.** [Multiple Choice] What is the function of `terraform graph`?
A) Generates a visual representation of the dependency graph of resources
B) Shows billing graphs
C) Formats HCL as a diagram
D) Displays CPU usage of resources

**Q28.** [Multiple Choice] What does the `-target` flag do when used with `terraform apply`?
A) Applies changes to a specific remote backend
B) Restricts the apply/plan operation to a specific resource and its dependencies
C) Targets a specific workspace only
D) Selects a specific provider version

**Q29.** [Multiple Choice] Why is `-target` generally discouraged for routine use?
A) It's deprecated and no longer works
B) It can produce a state that's inconsistent with the full configuration if used repeatedly instead of as a targeted exception
C) It always destroys resources
D) It requires root permissions

**Q30.** [Multiple Choice] What does `terraform output` do by default?
A) Applies pending changes
B) Displays the values of output variables defined in the root module
C) Lists all providers
D) Deletes all outputs

**Q31.** [Multiple Choice] Which command initializes a working directory containing Terraform configuration files, downloading providers and modules?
A) `terraform plan`
B) `terraform init`
C) `terraform get`
D) `terraform validate`

**Q32.** [Multiple Choice] What is the purpose of the `-upgrade` flag with `terraform init`?
A) Upgrades the Terraform CLI binary itself
B) Upgrades provider and module versions to the latest allowed by constraints, updating the lock file
C) Upgrades the state file format
D) Upgrades the OS

**Q33.** [Multiple Choice] What does `terraform import` do?
A) Creates new resources matching configuration
B) Brings an existing, manually-created resource under Terraform management by adding it to the state
C) Imports variable definitions from another file
D) Downloads provider plugins

**Q34.** [Multiple Choice] After running `terraform import`, what additional manual step is required?
A) Nothing further is needed
B) You must write a matching resource configuration block yourself, since import only updates state, not configuration
C) You must run `terraform destroy` immediately
D) You must delete the state file

**Q101.** [Scenario] You accidentally deleted a resource manually through the cloud console, but it's still present in your Terraform state. What is the safest next command to run to see how Terraform reacts, without changing anything yet?
A) terraform apply -auto-approve
B) terraform plan (Terraform will detect it's missing and propose recreating it)
C) terraform state rm
D) terraform destroy

**Q102.** [Multiple Choice] Which command would you use to rename a resource in your state to match a renamed resource block in configuration, without destroying and recreating the underlying infrastructure?
A) terraform import
B) terraform state mv
C) terraform refresh
D) terraform state rm

**Q103.** [True/False] True or False: `terraform fmt -recursive` formats .tf files in the current directory and all subdirectories.
A) True
B) False

**Q104.** [Scenario] During a CI pipeline run, `terraform init` fails because it can't reach the module registry due to a network policy. Which flag lets you skip re-downloading modules if they're already present locally from a previous run?
A) terraform init -get=false
B) terraform init -backend=false
C) terraform init -upgrade
D) terraform init -reconfigure

**Q105.** [Multiple Choice] What does `terraform providers` (as opposed to `terraform provider`) do?
A) Installs new providers
B) Prints a tree of provider requirements used by the configuration and its modules
C) Deletes unused providers
D) Upgrades all providers to latest

**Q106.** [Code/Config] $ terraform apply -replace="aws_instance.web"
What will this command do?
A) Delete aws_instance.web and never recreate it
B) Force aws_instance.web to be destroyed and recreated on this apply, leaving other resources untouched
C) Replace the entire state file
D) Only works in plan mode, never applies

**Q107.** [True/False] True or False: `terraform validate` requires network access to the provider's API to succeed.
A) True
B) False

**Q108.** [Multiple Choice] Which of these is NOT a valid reason to use `terraform console`?
A) Testing how a function like `cidrsubnet()` behaves with sample inputs
B) Checking the current value of a resource attribute in state
C) Applying infrastructure changes interactively
D) Evaluating a complex expression before adding it to configuration

**Q109.** [Scenario] You imported an existing S3 bucket using `terraform import aws_s3_bucket.data my-bucket-name`, but running `terraform plan` afterward shows Terraform wants to change several attributes. What is the most likely cause?
A) Import always corrupts the state
B) The resource block's arguments in configuration don't yet match the real bucket's actual settings, so plan shows the diff
C) S3 buckets cannot be imported
D) You must run terraform destroy after every import

**Q110.** [Multiple Choice] What is the purpose of the `-lock=false` flag on `terraform plan` or `apply`?
A) Permanently disables locking for the backend
B) Skips acquiring a state lock for that single operation (use with caution)
C) Locks the configuration files from editing
D) Encrypts the state file

**Q111.** [True/False] True or False: `terraform output -json` prints all output values in JSON format, which is useful for piping into other tools/scripts.
A) True
B) False

**Q112.** [Multiple Choice] Which command shows the current state in a human-readable format, including resource attributes, without needing to open the raw state file?
A) terraform state list
B) terraform show
C) terraform graph
D) terraform fmt

---

## Domain 5: Interact with Terraform Modules (~10%)

**Q35.** [Multiple Choice] What is a Terraform module?
A) A single resource block
B) A container for multiple resources used together, referenced as a reusable unit of configuration
C) A type of provider
D) A state file backup

**Q36.** [Multiple Choice] What is the "root module" in a Terraform configuration?
A) The first module ever created
B) The configuration files in the main working directory that Terraform runs against
C) A module stored in the Terraform Registry
D) A module with no resources

**Q37.** [Multiple Choice] How do you call a module from a local path in configuration?
A) `module "example" { source = "app.terraform.io/example" }`
B) `module "example" { source = "./modules/example" }`
C) `import "example" { path = "./modules/example" }`
D) `provider "example" { path = "./modules/example" }`

**Q38.** [Multiple Choice] What format is used to reference a module hosted on the public Terraform Registry?
A) `source = "github.com/user/repo"` only
B) `source = "<NAMESPACE>/<NAME>/<PROVIDER>"`
C) `source = "registry://module"`
D) `source = "local://module"`

**Q39.** [Multiple Choice] How do you pass a value into a module from the calling configuration?
A) Modules cannot accept inputs
B) By setting an argument inside the `module` block that matches a `variable` declared in the module
C) By editing the module's source code directly every time
D) Through the state file only

**Q40.** [Multiple Choice] How do you reference an output value from a child module in the calling (parent) configuration?
A) `output.module_name.value`
B) `module.<module_name>.<output_name>`
C) `child.<module_name>.<output_name>`
D) Outputs can't be referenced outside the module

**Q41.** [Multiple Choice] What does module versioning (e.g. `version = "~> 2.0"`) apply to?
A) Only local modules
B) Modules sourced from a registry (local path and some other sources don't support version constraints)
C) The Terraform CLI version
D) The provider version

**Q42.** [Multiple Choice] Why are modules considered a best practice for larger Terraform codebases?
A) They eliminate the need for state
B) They encapsulate and reuse configuration, reducing duplication and standardizing patterns
C) They remove the need for variables
D) They bypass the need for provider blocks

**Q113.** [Scenario] Your root module calls a child module twice using `for_each` over a set of environment names: `module "vpc" { for_each = toset(["dev","prod"]) ... }`. How do you reference the `vpc_id` output of the "prod" instance from the root module?
A) module.vpc.vpc_id
B) module.vpc["prod"].vpc_id
C) module.vpc.prod.vpc_id
D) vpc.prod.vpc_id

**Q114.** [True/False] True or False: A module sourced from a local relative path (e.g. `source = "../modules/vpc"`) is automatically re-downloaded and can use a `version` constraint just like a registry module.
A) True
B) False

**Q115.** [Multiple Choice] What happens if a required input variable of a child module is not supplied in the calling `module` block, and the variable has no default?
A) Terraform silently uses null
B) Terraform will error during plan/apply, since the variable is required
C) The module is skipped entirely
D) It falls back to an environment variable automatically

**Q116.** [Scenario] You want to reuse the same module twice in the same root configuration - once for a 'staging' VPC and once for a 'prod' VPC - each with different CIDR blocks. Which approach is correct?
A) You cannot call the same module more than once in a configuration
B) Declare two separate `module` blocks with different local names, each passing its own CIDR value
C) Use the same module block and pass a list of CIDRs, Terraform automatically creates two calls
D) Copy-paste the module's source code into two folders

**Q117.** [Multiple Choice] Which of these is a best practice when designing a reusable module?
A) Hard-code resource names and regions inside the module
B) Expose configurable behavior through input variables and expose useful values through outputs
C) Avoid using outputs so the module's internals stay hidden
D) Always require callers to also manage the module's own state file directly

**Q118.** [Code/Config] module "network" {
  source = "./modules/network"
  cidr   = "10.0.0.0/16"
}

resource "aws_instance" "app" {
  subnet_id = module.network.subnet_ids[0]
}
What must be true in `./modules/network` for this configuration to work?
A) The module must declare an output named `subnet_ids` that returns a list
B) The module must declare a variable named `subnet_ids`
C) Nothing extra is needed, Terraform infers it automatically
D) The module must contain a resource named `aws_instance.app`

**Q119.** [True/False] True or False: Modules can call other modules (nested modules), and there is no limit enforced by Terraform on nesting depth.
A) True
B) False

**Q120.** [Multiple Choice] What does running `terraform get` do in a configuration that uses modules?
A) Downloads/updates modules referenced in configuration (also done automatically by `init`)
B) Fetches the current state from the backend
C) Retrieves output values only
D) Installs provider plugins

---

## Domain 6: Navigate Terraform Workflow (~15%)

**Q43.** [Multiple Choice] What is the correct standard Terraform workflow order?
A) Apply -> Plan -> Init
B) Init -> Plan -> Apply
C) Plan -> Init -> Apply
D) Apply -> Init -> Plan

**Q44.** [Multiple Choice] What does `terraform plan` do?
A) Applies changes immediately
B) Creates an execution plan showing what actions Terraform will take, without making changes
C) Destroys existing infrastructure
D) Downloads providers

**Q45.** [Multiple Choice] What is the purpose of saving a plan to a file with `terraform plan -out=tfplan`?
A) It has no practical purpose
B) It lets you apply that exact, reviewed plan later with `terraform apply tfplan`, avoiding drift between plan and apply
C) It backs up the state file
D) It formats the configuration

**Q46.** [Multiple Choice] In a team/CI setting, why is applying a saved plan file considered safer than running `terraform apply` directly?
A) It's not safer, they're identical
B) It guarantees the applied changes exactly match what was reviewed/approved, since the plan can't silently change between review and apply
C) It skips the need for a backend
D) It removes the need for state locking

**Q47.** [Multiple Choice] What does `terraform apply -auto-approve` do differently from a plain `terraform apply`?
A) It skips generating a plan
B) It skips the interactive approval prompt and applies the plan automatically
C) It only works in CI
D) It ignores the state file

**Q48.** [Multiple Choice] What happens during `terraform destroy`?
A) It only deletes local files
B) Terraform destroys all resources tracked in the state file for the current configuration/workspace
C) It deletes the provider plugins only
D) It resets variables to default

**Q49.** [Multiple Choice] How can you destroy only a specific resource instead of the whole configuration?
A) `terraform destroy -target=<resource_address>`
B) `terraform destroy` always destroys everything, no exceptions
C) `terraform apply -target` only
D) Manually edit the state file first

**Q50.** [Multiple Choice] What is the purpose of the refresh step that occurs as part of `terraform plan`?
A) It reformats configuration files
B) It reconciles the state file with real infrastructure to detect drift before computing the plan
C) It re-downloads providers
D) It regenerates the lock file

**Q51.** [Multiple Choice] What does Terraform do if it detects that real infrastructure has drifted from the state (e.g., someone manually changed a resource)?
A) It silently ignores the difference
B) It shows the drift in the plan output and proposes changes to reconcile config, state, and real infrastructure
C) It automatically deletes the resource
D) It crashes with an unrecoverable error

**Q52.** [Multiple Choice] Which workflow step would catch a syntax error in a `.tf` file before contacting any provider APIs?
A) `terraform apply`
B) `terraform validate` (also caught earlier by `terraform plan`/`init`)
C) `terraform destroy`
D) `terraform state list`

**Q53.** [Multiple Choice] What is the purpose of `terraform apply` after a plan is generated interactively (without `-out`)?
A) It re-runs `init`
B) It re-computes a fresh plan and prompts for approval before applying it
C) It automatically applies without any plan
D) It skips state updates

**Q54.** [Multiple Choice] Why does Terraform generally recommend running `plan` before every `apply` rather than skipping straight to apply?
A) It's a legacy requirement with no real benefit
B) It lets you review exactly what will change before it happens, reducing the risk of unintended modifications
C) It's required for provider authentication
D) It updates the CLI version

**Q121.** [Scenario] You run `terraform plan -out=tfplan`, review it, then a teammate merges an unrelated change into the same branch and someone else applies main before you apply your saved plan. What happens when you then run `terraform apply tfplan`?
A) Terraform applies the stale plan blindly, ignoring the new state
B) Terraform detects the state has changed since the plan was created and errors out rather than applying a stale plan
C) It automatically re-plans for you silently
D) It merges both changes automatically

**Q122.** [True/False] True or False: Running `terraform destroy` will prompt for confirmation by default, the same way `apply` does.
A) True
B) False

**Q123.** [Multiple Choice] During `terraform plan`, you see a resource marked with `-/+` in the diff output. What does this indicate?
A) The resource will be updated in place
B) The resource will be destroyed and then recreated (replacement)
C) The resource will only be destroyed, never recreated
D) No change will occur

**Q124.** [Scenario] You need to change an AWS instance's AMI, but the `ami` argument's documentation says changing it forces replacement. What would you expect to see in `terraform plan` output for that resource?
A) A simple in-place update (~)
B) A destroy-and-recreate action (-/+), since the attribute is defined as ForceNew
C) No change shown at all
D) An error preventing any plan from being generated

**Q125.** [Multiple Choice] What is the purpose of `terraform plan -destroy`?
A) It immediately destroys all resources
B) It previews what a `terraform destroy` would do, without executing it
C) It's not a valid flag combination
D) It only works with modules

**Q126.** [True/False] True or False: If `terraform apply` is interrupted (e.g. Ctrl+C) partway through applying multiple resources, the state file may reflect a partially-applied configuration, and running plan again is the recommended way to see what remains.
A) True
B) False

---

## Domain 7: Implement and Maintain State (~15%)

**Q55.** [Multiple Choice] What is the primary purpose of the Terraform state file?
A) To store provider credentials
B) To map real-world resources to your configuration and track metadata/dependencies
C) To store variable defaults only
D) To act as a backup of `.tf` files

**Q56.** [Multiple Choice] What is a "backend" in Terraform?
A) The provider plugin binary
B) The mechanism that determines where and how state is stored (local or remote)
C) A type of module
D) The CLI itself

**Q57.** [Multiple Choice] Why is remote state generally preferred over local state for team environments?
A) It's faster to write to disk
B) It enables shared access, locking, and avoids conflicts from multiple people applying simultaneously
C) It removes the need for `terraform init`
D) It eliminates the need for version control

**Q58.** [Multiple Choice] What problem does state locking solve?
A) It prevents unauthorized read access to state
B) It prevents concurrent operations from corrupting the state file by writing to it at the same time
C) It encrypts the state file
D) It compresses the state file

**Q59.** [Multiple Choice] Which backend types commonly support state locking? (choose the best answer)
A) None do
B) Backends like AWS S3 (with DynamoDB), Azure Storage, Google Cloud Storage, and HCP Terraform/Terraform Enterprise support locking
C) Only the local backend
D) Only HCP Terraform

**Q60.** [Multiple Choice] What command would you use to move a resource from one state address to another (e.g., after renaming it in configuration) without destroying/recreating it?
A) `terraform import`
B) `terraform state mv`
C) `terraform state rm`
D) `terraform refresh`

**Q61.** [Multiple Choice] What does `terraform state rm` do?
A) Deletes the real infrastructure resource
B) Removes a resource from Terraform's state without destroying the actual infrastructure
C) Deletes the entire state file
D) Removes a provider

**Q62.** [Multiple Choice] Why should you generally avoid manually editing the state file with a text editor?
A) State files aren't in JSON so they can't be edited
B) Manual edits can easily corrupt the state, causing mismatches with real infrastructure; `terraform state` subcommands are the supported way to modify it
C) The state file is read-only by the OS
D) It's not possible to open the file

**Q63.** [Multiple Choice] What does `terraform state list` output?
A) A list of variables
B) A list of resource addresses currently tracked in the state
C) A list of available providers
D) A list of output values

**Q64.** [Multiple Choice] What sensitive information can commonly end up in the Terraform state file?
A) Only resource names
B) Potentially sensitive attribute values (like passwords or keys) in plaintext, unless the backend/state encryption mitigates this
C) Nothing sensitive is ever stored in state
D) Only provider names

**Q65.** [Multiple Choice] What is the purpose of the `sensitive = true` argument on a variable or output?
A) It encrypts the value in the state file
B) It suppresses the value from CLI output (plan/apply/output), though it's still stored in state
C) It prevents the value from being stored in state entirely
D) It deletes the value after apply

**Q66.** [Multiple Choice] What happens if two team members run `terraform apply` at the same time against the same remote state with locking enabled?
A) Both applies succeed simultaneously
B) The second apply is blocked/fails until the first operation releases the lock
C) The state file is duplicated
D) Terraform automatically merges both changes

**Q127.** [Scenario] Two engineers both run `terraform apply` against the same S3+DynamoDB backend at nearly the same time. Engineer A's apply starts first and acquires the lock. What happens to Engineer B's apply?
A) It proceeds anyway and corrupts the state
B) It fails/waits, showing a lock error, until Engineer A's operation finishes and releases the lock
C) It silently overwrites Engineer A's changes
D) DynamoDB automatically merges both changes

**Q128.** [Multiple Choice] Why might a team choose an encrypted remote backend (e.g. S3 with SSE) for state storage over local state?
A) Local state files are always automatically encrypted
B) State can contain sensitive attribute values in plaintext, so protecting the storage location matters
C) Encryption is required by Terraform's core, not a backend choice
D) Remote state removes the risk of sensitive values entirely

**Q129.** [True/False] True or False: `terraform state show <resource_address>` displays the detailed attributes of a single resource as currently recorded in state.
A) True
B) False

**Q130.** [Code/Config] $ terraform state rm aws_db_instance.legacy
After running this command, what is true?
A) The RDS instance is deleted from AWS
B) The RDS instance still exists in AWS, but Terraform no longer tracks or manages it
C) The command fails because state rm cannot target database resources
D) The resource block is automatically deleted from the .tf file

**Q131.** [Scenario] You need to migrate state from a local backend to an S3 backend for an existing configuration. After adding the `backend "s3" {}` block, what command must you run to actually move the state?
A) terraform apply
B) terraform init (Terraform will detect the backend change and offer to migrate state)
C) terraform state mv
D) terraform import

**Q132.** [Multiple Choice] Which scenario is the strongest justification for using `-target` together with `terraform state rm`, rather than routine daily usage?
A) Recovering from a specific one-off state/config mismatch, then returning to normal full plans/applies
B) As your everyday default way of running Terraform for speed
C) To permanently avoid ever running a full plan again
D) It's required before every apply

---

## Domain 8: Read, Generate, and Modify Configuration (~20%)

**Q67.** [Multiple Choice] What does the `count` meta-argument do on a resource block?
A) Sets the resource's numeric ID
B) Creates multiple instances of a resource based on an integer, indexed by `count.index`
C) Limits the resource to a maximum count
D) Sets a billing quota

**Q68.** [Multiple Choice] What does `for_each` allow that `count` does not, when creating multiple resource instances?
A) Nothing, they're functionally identical
B) Creating instances keyed by a map or set of strings, so instances are identified by key rather than numeric index (more stable when the collection changes)
C) `for_each` can only be used with modules, not resources
D) `for_each` is deprecated

**Q69.** [Multiple Choice] Given `variable "env" { type = string }`, what does the `type` constraint enforce?
A) Nothing, types are purely cosmetic
B) That the value assigned to the variable must be a string, or Terraform will error/attempt conversion
C) The variable's default value only
D) Only affects the CLI, not `plan`/`apply`

**Q70.** [Multiple Choice] What does the `lookup()` function do?
A) Retrieves a value from a map by key, with an optional default if the key is absent
B) Looks up a resource in the state
C) Validates a provider version
D) Searches the Terraform Registry

**Q71.** [Multiple Choice] What does a `dynamic` block allow you to do in Terraform configuration?
A) Dynamically change the provider at runtime
B) Programmatically generate repeated nested configuration blocks (like multiple `ingress` blocks) from a collection
C) Dynamically resize the state file
D) Enable auto-scaling on cloud resources

**Q72.** [Multiple Choice] What is the purpose of `depends_on`?
A) It's used to declare provider dependencies only
B) It explicitly declares a dependency between resources/modules when Terraform can't infer it automatically from references
C) It sets the order of variables
D) It locks resource versions

**Q73.** [Multiple Choice] In most cases, how does Terraform determine the order to create/update/destroy resources?
A) Alphabetical order of resource names
B) Implicitly, by building a dependency graph from references between resources in configuration
C) Random order
D) The order resources appear in the file, always

**Q74.** [Multiple Choice] What does the `terraform.workspace` expression return?
A) The path to the working directory
B) The name of the currently selected workspace
C) The Terraform CLI version
D) The backend type

**Q75.** [Multiple Choice] What is a common use case for Terraform workspaces?
A) Storing secrets
B) Managing multiple distinct states (e.g., dev/staging) from the same configuration, each with isolated state
C) Formatting code differently per environment
D) Replacing modules entirely

**Q76.** [Multiple Choice] What does the `terraform.tfvars.json` file allow compared to `terraform.tfvars`?
A) Nothing different, they're identical in every way
B) The same variable-definition purpose, but expressed in JSON syntax instead of HCL
C) It's used only for outputs
D) It stores state instead of variables

**Q77.** [Multiple Choice] What does the `try()` function do?
A) Runs a resource in "dry run" mode
B) Evaluates a list of expressions and returns the first one that doesn't produce an error
C) Retries a failed apply automatically
D) Validates provider credentials

**Q78.** [Multiple Choice] What is the difference between `variable` default values and using `coalesce()`?
A) They are the same thing
B) A default applies only when no value is supplied for that variable; `coalesce()` picks the first non-null value from a list of expressions at evaluation time
C) `coalesce()` only works on resources
D) Defaults can't be overridden, `coalesce()` can

**Q79.** [Multiple Choice] What does the `templatefile()` function do?
A) Creates a new `.tf` file
B) Renders a template file with the given variables, returning the result as a string
C) Templates a provider block
D) Copies a file to the module directory

**Q80.** [Multiple Choice] What is a "precondition" or "postcondition" block (custom conditions) used for in Terraform?
A) Formatting output
B) Validating assumptions about resource/variable values, causing a plan/apply error with a custom message if violated
C) Setting default variable values
D) Locking the state file

**Q81.** [Multiple Choice] In an expression like `var.instance_count > 0 ? "yes" : "no"`, what Terraform language feature is being used?
A) A `for` expression
B) A conditional (ternary) expression
C) A `dynamic` block
D) A `lifecycle` block

**Q82.** [Multiple Choice] What does a `for` expression like `[for s in var.list : upper(s)]` produce?
A) A single string
B) A new list with each element transformed by `upper()`
C) A map
D) A boolean

**Q83.** [Multiple Choice] What is the purpose of the `lifecycle` block argument `prevent_destroy = true`?
A) It prevents any changes to the resource whatsoever
B) It causes Terraform to reject any plan that would destroy that resource
C) It disables state tracking for the resource
D) It backs up the resource automatically

**Q84.** [Multiple Choice] What does `create_before_destroy = true` inside a `lifecycle` block change about resource replacement?
A) Nothing, it's the default behavior
B) The new resource is created before the old one is destroyed, instead of the default destroy-then-create order
C) It prevents replacement entirely
D) It only applies to modules

**Q133.** [Code/Config] variable "env_settings" {
  type = map(object({
    instance_count = number
    instance_type  = string
  }))
}
Which value correctly matches this type constraint for `env_settings`?
A) { dev = { instance_count = 1, instance_type = "t3.micro" } }
B) [ { instance_count = 1, instance_type = "t3.micro" } ]
C) { dev = "t3.micro" }
D) "dev,1,t3.micro"

**Q134.** [Scenario] You want to create one `aws_iam_user` resource per name in a variable `var.usernames` (a list of strings), and you want each instance to be addressable by the username itself (not a numeric index) so that adding a name to the middle of the list doesn't cause unrelated users to be recreated. What should you use?
A) count = length(var.usernames)
B) for_each = toset(var.usernames)
C) A single resource block with a loop inside it
D) Multiple hard-coded resource blocks

**Q135.** [True/False] True or False: The `templatefile()` function can only be used to render `.tpl` files, not any other file extension.
A) True
B) False

**Q136.** [Multiple Choice] What does the expression `[for k, v in var.settings : "${k}=${v}"]` produce, given `var.settings` is a map?
A) A map with the same keys
B) A list of strings, each formatted as "key=value"
C) A single concatenated string
D) A syntax error, since maps can't be used in for expressions

**Q137.** [Code/Config] resource "aws_security_group_rule" "ingress" {
  count             = length(var.allowed_ports)
  type              = "ingress"
  from_port         = var.allowed_ports[count.index]
  to_port           = var.allowed_ports[count.index]
  protocol          = "tcp"
  security_group_id = aws_security_group.main.id
}
If `var.allowed_ports` changes from `[80, 443]` to `[443, 80]` (order reversed), what is the likely consequence with `count`-based indexing?
A) Nothing changes, order doesn't matter to count
B) Terraform may show both rules as needing replacement/update, since the index-to-value mapping shifted even though the same values still exist
C) Terraform automatically reorders them without any plan diff
D) This causes a permanent syntax error

**Q138.** [Multiple Choice] What is the purpose of a `moved` block in Terraform configuration?
A) It records that a resource/module has been renamed or moved in configuration, so Terraform updates state addresses instead of destroying and recreating
B) It moves files on disk
C) It changes which backend stores state
D) It's used to move variables between files, purely organizational with no state effect

**Q139.** [True/False] True or False: A `precondition` block inside a `lifecycle` block is checked before the resource's changes are applied, while a `postcondition` is checked after.
A) True
B) False

**Q140.** [Scenario] You have `variable "tags" { type = map(string), default = {} }` and want to merge it with a fixed set of mandatory tags before applying them to every resource. Which function is designed for this?
A) concat()
B) merge()
C) zipmap()
D) flatten()

**Q141.** [Multiple Choice] Which of these expressions correctly uses a conditional to set an instance type based on an environment variable, defaulting to a smaller type for anything that isn't 'prod'?
A) var.env = "prod" ? "m5.large" : "t3.micro"
B) var.env == "prod" ? "m5.large" : "t3.micro"
C) if var.env == "prod" then "m5.large" else "t3.micro"
D) var.env.equals("prod") ? "m5.large" : "t3.micro"

**Q142.** [Code/Config] locals {
  is_prod = var.environment == "prod"
  replica_count = local.is_prod ? 3 : 1
}

resource "aws_instance" "app" {
  count = local.replica_count
  # ...
}
If `var.environment` is set to "staging", how many `aws_instance.app` resources will Terraform create?
A) 3
B) 1
C) 0
D) This is invalid syntax

**Q143.** [True/False] True or False: The `sensitive = true` argument can be applied to an output block to prevent its value from being shown in `terraform plan`/`apply` CLI output.
A) True
B) False

**Q144.** [Multiple Choice] What does the `flatten()` function do to a nested list like `[[1, 2], [3], [4, 5]]`?
A) Removes duplicate values
B) Produces a single flat list: [1, 2, 3, 4, 5]
C) Sorts the list numerically
D) Converts the list into a map

**Q145.** [Scenario] You want a resource block to only be created when `var.enable_feature` is true, and skipped entirely otherwise. Which is the idiomatic way to achieve this?
A) Wrap the whole resource block in an `if` statement
B) Use `count = var.enable_feature ? 1 : 0` on the resource
C) Delete the resource block manually depending on environment
D) Use a `dynamic` block around the entire resource

---

## Domain 9: HCP Terraform (Terraform Cloud) Capabilities (~10%)

**Q85.** [Multiple Choice] What is HCP Terraform (formerly Terraform Cloud) primarily used for?
A) Only local state storage
B) A managed service providing remote state, remote runs, VCS integration, policy enforcement, and collaboration features for teams
C) Replacing the Terraform CLI entirely
D) Only for billing management

**Q86.** [Multiple Choice] What is a "workspace" in HCP Terraform (as distinct from CLI workspaces)?
A) The same concept with the same scope as CLI `terraform workspace`
B) A more fully-featured unit that bundles configuration, variables, state, and run history, typically mapped to one deployable configuration
C) A billing plan tier
D) A provider plugin cache

**Q87.** [Multiple Choice] What does Sentinel (or HCP Terraform's policy-as-code features) allow an organization to do?
A) Format Terraform code automatically
B) Enforce policy checks (e.g., cost, security, compliance rules) on runs before they're applied
C) Replace the state backend
D) Manage DNS records

**Q88.** [Multiple Choice] How does HCP Terraform's remote execution mode differ from running Terraform locally?
A) There is no difference
B) Runs (plan/apply) execute on HCP Terraform's infrastructure rather than your local machine, with state and logs centrally managed
C) Remote execution disables state locking
D) It only supports `plan`, never `apply`

**Q149.** [Multiple Choice] In HCP Terraform, what is the purpose of connecting a workspace to a VCS repository (e.g. GitHub)?
A) It's purely cosmetic and has no functional effect
B) It enables automatic run triggers on commits/PRs, keeping infrastructure changes tied to code review
C) It replaces the need for a state backend
D) It disables remote execution

**Q150.** [True/False] True or False: HCP Terraform workspaces can define workspace-specific variables that aren't shared with other workspaces, even in the same organization.
A) True
B) False

**Q151.** [Multiple Choice] What is a 'variable set' in HCP Terraform used for?
A) Grouping variables so they can be reused/shared across multiple workspaces without re-entering them each time
B) Encrypting the state file
C) Defining Sentinel policies
D) Setting the Terraform CLI version only

**Q152.** [Scenario] An organization wants to enforce that no one can apply a plan that would create infrastructure outside an approved AWS region, before it ever reaches production. What HCP Terraform feature is designed for this kind of automated guardrail?
A) Remote state storage alone
B) Sentinel or OPA policy checks integrated into the run pipeline
C) VCS integration alone
D) Workspace tagging

---

# ANSWER KEY & RATIONALE

**Domain 1**
1. B - repeatability/versioning/audit trail is the core IaC value prop.
2. C - IaC doesn't auto-optimize cost with zero config; that needs deliberate design.
3. A - idempotency = same input -> same result, regardless of how many times applied.
4. B - declarative = describe the "what," not the "how."
146. B - IaC makes changes repeatable and reviewable, but it doesn't inherently guarantee zero downtime - that depends on how changes are designed and sequenced.
147. B - Declarative tools like Terraform compare desired state to current state and derive the needed actions, rather than requiring you to script each step.

**Domain 2**
5. A - Terraform provisions infra; Ansible/Chef configure software on hosts.
6. B - one workflow/language, many providers.
7. B - Terraform commonly replaces rather than patches resources.
8. B - cloud-agnostic workflow is the differentiator vs. CloudFormation.
148. B - Multi-cloud requirements are the classic case where Terraform's cloud-agnostic provider model pays off over a single-cloud-native tool.

**Domain 3**
9. B - terraform block + providers + resources/data sources form the core.
10. B - providers are plugins that talk to an API.
11. B - `required_providers` inside `terraform {}`.
12. C - `~>` pessimistic constraint allows patch upgrades only, for `~> 4.16` (implicitly `4.16.x`).
13. B - no constraint = latest available at init time.
14. B - `<TYPE>.<NAME>.<ATTRIBUTE>`.
15. B - data sources are read-only lookups.
16. B - `output` blocks expose values.
17. B - variables are external inputs; locals are internal computed names.
18. B - `terraform.tfvars` auto-loads.
19. B - CLI flags > auto.tfvars > terraform.tfvars > env vars > defaults.
20. A - HashiCorp Configuration Language.
89. B - Locals are private to the module they're defined in. To expose a computed value to a caller, you must expose it via an `output` block, not by referencing the local directly.
90. C - CLI -var/-var-file flags have the highest precedence, overriding tfvars files and defaults.
91. B - Combined constraints are AND-ed together: >= 4.0 sets the floor, < 5.0 sets the ceiling, so any 4.x version qualifies.
92. B - Complex type constraints use the constructor syntax, e.g. list(string), map(number), object({...}).
93. B - nullable = false enforces that the variable can never be assigned a null value, whether or not a default exists.
94. A - Terraform builds the dependency graph from these references and resolves the actual value at apply time; you don't need the resource to already exist to reference it in config.
95. B - If no type constraint is given, Terraform defaults to accepting any type.
96. A - `provider "aws" { alias = "east" }` lets you define a second named provider configuration, referenced in a resource with `provider = aws.east`.
97. B - The address is Terraform's internal reference; id is a provider-specific attribute (e.g. an AWS instance ID) exposed on the resource.
98. B - Outputs are computed after the referenced resource is created/updated, so the ARN is known and printed once apply completes.
99. B - count.index is zero-based, so count = 3 produces indices 0, 1, and 2.
100. A - TF_VAR_<name> environment variables map directly to input variables of the same name, though they rank below CLI flags and tfvars files in precedence.

**Domain 4**
21. B - `fmt` rewrites style, doesn't touch state.
22. A - `validate` checks syntax/internal consistency, no API calls.
23. B - `terraform state list`.
24. B - taint marks for recreation on next apply.
25. B - `terraform apply -replace=`.
26. B - console is an interactive expression evaluator.
27. A - `graph` visualizes the dependency graph.
28. B - `-target` restricts scope to a resource + its dependencies.
29. B - repeated use risks state/config drift; it's meant as an exception, not routine practice.
30. B - `output` prints root module output values.
31. B - `init` sets up the working directory.
32. B - `-upgrade` updates providers/modules within constraints and updates the lock file.
33. B - import attaches existing infra to state only.
34. B - you must hand-write matching config after import.
101. B - `plan` (which includes a refresh) will detect the drift - the resource missing from real infrastructure - and show a proposal to recreate it, without making any changes yet.
102. B - `terraform state mv` re-addresses an existing state entry to a new resource address without touching real infrastructure.
103. A - The -recursive flag extends formatting to subdirectories rather than just the current one.
104. A - -get=false skips downloading modules, useful when they're already vendored/cached locally.
105. B - `terraform providers` gives a summary of which providers are required, including transitively through modules.
106. B - -replace targets a specific resource for forced replacement (destroy + recreate) while leaving the rest of the plan driven by normal diff logic.
107. B - validate only checks syntax and internal consistency (types, references) - it does not contact any remote API.
108. C - console is a read-only REPL for evaluating expressions against current state/config; it cannot apply changes.
109. B - Import only populates state - you must hand-write a resource block whose arguments match reality, or plan will show a diff trying to reconcile config with the imported state.
110. B - -lock=false bypasses the lock check for just that command invocation; it's risky since it can allow concurrent writes.
111. A - The -json flag is commonly used to feed Terraform outputs into external scripts or CI pipelines.
112. B - `terraform show` renders the state (or a saved plan file) in a readable format.

**Domain 5**
35. B - module = reusable container of resources.
36. B - root module = the main working directory's config.
37. B - local path source uses `./` or `../` prefix.
38. B - `<NAMESPACE>/<NAME>/<PROVIDER>` registry format.
39. B - inputs are passed as arguments matching the module's declared variables.
40. B - `module.<name>.<output>`.
41. B - version constraints apply to registry-sourced modules (not local paths).
42. B - reuse/standardization/reduced duplication.
113. B - When a module block uses for_each, its instances are addressed with the key in brackets, same pattern as resources.
114. B - Local path sources are read directly from disk on every run; version constraints only apply to sources that support versioning, like the public/private registry.
115. B - A variable without a default is required; omitting it from the module block causes an error.
116. B - Each module block is independently named and configured; calling the same source twice under different names/inputs is a standard pattern.
117. B - Reusable modules should be parameterized via variables and expose necessary values via outputs, keeping internals otherwise encapsulated.
118. A - To reference module.network.subnet_ids, the child module must expose an output block called subnet_ids returning that value.
119. A - Terraform supports module composition/nesting with no hard enforced depth limit, though excessive nesting hurts readability.
120. A - `terraform get` downloads/updates modules; `terraform init` calls this internally as part of its setup.

**Domain 6**
43. B - init -> plan -> apply.
44. B - plan previews, doesn't change anything.
45. B - saved plan guarantees exactly what was reviewed gets applied.
46. B - prevents drift between review and execution, important in CI/CD.
47. B - skips the manual "yes" prompt.
48. B - destroy removes everything tracked in state for that config/workspace.
49. A - `-target` works with destroy too, for scoped deletion.
50. B - refresh reconciles state with real infra before planning.
51. B - drift is surfaced in the plan, with proposed reconciling changes.
52. B - validate (and plan, which calls it) catches syntax errors early.
53. B - apply re-plans and prompts unless given a saved plan file.
54. B - reviewing before applying reduces risk of unintended changes.
121. B - Terraform checks that the state hasn't changed since a saved plan was generated; if it has, it refuses to apply the now-stale plan.
122. A - destroy also requires typing 'yes' to confirm by default, unless -auto-approve is passed.
123. B - -/+ denotes a destroy-then-create replacement, as opposed to ~ (in-place update) or + / - alone.
124. B - Attributes marked as forcing replacement in the provider schema trigger a destroy/recreate rather than an in-place update.
125. B - -destroy on plan generates a plan showing what would be destroyed, without actually destroying anything - a dry run of destroy.
126. A - Terraform updates state incrementally as resources are created/changed, so an interruption can leave a partial apply; re-running plan shows the remaining delta.

**Domain 7**
55. B - state maps config to real resources + tracks metadata/dependencies.
56. B - backend = where/how state is stored.
57. B - shared access + locking avoids team conflicts.
58. B - locking prevents concurrent writes corrupting state.
59. B - S3+DynamoDB, Azure Storage, GCS, HCP Terraform all support locking.
60. B - `terraform state mv` re-addresses without destroy/recreate.
61. B - `state rm` detaches from state only, doesn't touch real infra.
62. B - manual edits risk corrupting state; use `terraform state` commands.
63. B - lists resource addresses in state.
64. B - sensitive attribute values can appear in plaintext in state.
65. B - `sensitive = true` hides values from CLI output, but they're still in state (unencrypted by default).
66. B - the second operation is blocked until the lock releases.
127. B - State locking (via the DynamoDB table, in this backend) prevents concurrent writes; the second operation is blocked until the lock is released.
128. B - State can hold sensitive plaintext values; encrypting the backend storage is a mitigation, since Terraform itself doesn't encrypt state by default.
129. A - state show prints all tracked attributes for one specific resource address from the state file.
130. B - state rm only detaches the resource from Terraform's state; it never touches the real infrastructure, and it doesn't edit .tf files either.
131. B - Changing the backend block requires re-running init, which detects the backend change and prompts to copy existing state to the new backend.
132. A - Both -target and manual state surgery are meant as exceptions for fixing specific problems, not as a routine workflow - repeated use risks drift between state and config.

**Domain 8**
67. B - `count` creates N instances, indexed via `count.index`.
68. B - `for_each` keys instances by map/set value, more stable under collection changes.
69. B - type constraints are enforced (Terraform errors or attempts conversion).
70. A - `lookup(map, key, default)`.
71. B - `dynamic` blocks generate repeated nested blocks from a collection.
72. B - `depends_on` makes an implicit dependency explicit when references alone don't capture it.
73. B - dependency graph built from references in config.
74. B - returns the current workspace name.
75. B - isolating state per environment from shared config.
76. B - same purpose, JSON syntax instead of HCL.
77. B - `try()` returns the first expression that doesn't error.
78. B - default = fallback when unset; `coalesce()` = first non-null among given expressions.
79. B - renders a template file into a string.
80. B - custom conditions validate assumptions, erroring with a custom message if violated.
81. B - ternary conditional expression.
82. B - `for` expression transforms into a new list.
83. B - `prevent_destroy` blocks any plan that would destroy the resource.
84. B - create_before_destroy flips the default destroy-then-create order.
133. A - The type is a map keyed by strings (env names), whose values are objects with instance_count (number) and instance_type (string) - option A matches that shape.
134. B - for_each with a set keys each instance by its value (the username), so inserting/removing an item doesn't shift other instances' indices/identities like count would.
135. B - templatefile() works with any file extension; .tpl is just a common convention, not a requirement.
136. B - This for expression iterates key/value pairs and builds a list of formatted strings, one per map entry.
137. B - With count, identity is tied to index position, not value - reordering the list changes what's 'at' each index, causing unnecessary diffs. This is exactly the kind of case for_each avoids.
138. A - moved blocks let Terraform automatically handle a refactor (renamed resource/module) by updating the state address, avoiding an unwanted destroy/recreate.
139. A - Preconditions validate assumptions before the associated action; postconditions validate the resulting state afterward.
140. B - merge() combines multiple maps into one, with later arguments' keys overriding earlier ones on conflict - the standard pattern for combining default + mandatory tags.
141. B - HCL's ternary conditional uses `condition ? true_val : false_val`, and equality comparison uses ==, not =.
142. B - is_prod evaluates to false since environment isn't 'prod', so replica_count resolves to 1, and count = 1 creates a single instance.
143. A - Marking an output sensitive suppresses it from ordinary CLI output (it still exists in state and can be retrieved deliberately via `terraform output`).
144. B - flatten() collapses nested lists into a single-level list, commonly used when combining outputs of multiple for expressions or modules.
145. B - HCL has no `if` statement for whole blocks; the standard idiom for conditional resource creation is count = condition ? 1 : 0 (or for_each with an empty vs. populated set/map).

**Domain 9**
85. B - HCP Terraform = managed remote state/runs/VCS/policy/collaboration.
86. B - HCP Terraform workspaces bundle config, vars, state, run history.
87. B - Sentinel/policy-as-code enforces rules before runs apply.
88. B - remote execution runs plan/apply on HCP Terraform's infra, not locally.
149. B - VCS-connected workspaces can trigger plans/applies automatically on commits or PRs, integrating infra changes into the normal code review flow.
150. A - Each HCP Terraform workspace has its own variable set, distinct from other workspaces, unless deliberately shared via variable sets.
151. A - Variable sets let you define common variables (e.g. cloud credentials) once and attach them to multiple workspaces, avoiding duplication.
152. B - Policy-as-code (Sentinel/OPA) is specifically designed to enforce rules like allowed regions automatically as part of the run, before an apply can proceed.
