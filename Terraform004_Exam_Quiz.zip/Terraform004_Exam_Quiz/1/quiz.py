#!/usr/bin/env python3
"""
Terraform Associate 004 - Interactive Mock Quiz (with PDF report)
-------------------------------------------------------------------
Run:  python3 quiz.py

Optional flags:
  --shuffle          shuffle question order
  --num N            attempt only N random questions
  --domain "state"   only questions whose domain name contains this text
  --file path.json   load questions from an external JSON file instead of
                      the built-in set (drop in future batches this way)
  --outdir path      folder to save the PDF report in (default: ./results)

At the end you get:
  - your score printed in the terminal
  - a PDF report saved to ./results/ with:
      * summary (attempted / correct / wrong / skipped, score %)
      * domain-wise breakdown
      * full detail of every WRONG (and skipped) question with the
        correct answer and explanation
"""

import argparse
import json
import os
import sys
import random
import datetime

# Force UTF-8 output so odd characters never crash the terminal (this was
# the bug that caused the script to die silently before showing a score).
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ---- Embedded question bank (Batch 1, Q1-88) ----
# If a questions.json file sits next to this script, it overrides this
# embedded data, so future batches can be dropped in without editing this file.
QUESTIONS = [{'num': 1, 'domain': 'Domain 1: Understand Infrastructure as Code (IaC) Concepts (~5%)', 'question': 'What is the main advantage of IaC over manually provisioning infrastructure through a cloud console?', 'options': {'A': 'It removes the need for a cloud provider account', 'B': 'It makes infrastructure changes repeatable, versionable, and auditable', 'C': 'It guarantees zero downtime deployments', 'D': 'It eliminates the need for a state file'}, 'answer': 'B', 'rationale': 'repeatability/versioning/audit trail is the core IaC value prop.'}, {'num': 2, 'domain': 'Domain 1: Understand Infrastructure as Code (IaC) Concepts (~5%)', 'question': 'Which of the following is NOT typically a benefit of using IaC?', 'options': {'A': 'Consistency across environments', 'B': 'Faster provisioning through automation', 'C': 'Automatic cost optimization with no configuration', 'D': 'Version-controlled infrastructure history'}, 'answer': 'C', 'rationale': "IaC doesn't auto-optimize cost with zero config; that needs deliberate design."}, {'num': 3, 'domain': 'Domain 1: Understand Infrastructure as Code (IaC) Concepts (~5%)', 'question': 'In IaC terminology, what does "idempotency" mean?', 'options': {'A': 'Applying the same configuration multiple times produces the same end state', 'B': 'Configuration can only be applied once', 'C': 'Resources are destroyed after every apply', 'D': 'State files are encrypted by default'}, 'answer': 'A', 'rationale': 'idempotency = same input -> same result, regardless of how many times applied.'}, {'num': 4, 'domain': 'Domain 1: Understand Infrastructure as Code (IaC) Concepts (~5%)', 'question': 'Which statement best describes a declarative approach to IaC (as opposed to imperative)?', 'options': {'A': 'You write step-by-step commands to reach the desired state', 'B': 'You describe the desired end state and let the tool figure out how to get there', 'C': 'You must manually track the order of resource creation', 'D': 'It only works with shell scripts'}, 'answer': 'B', 'rationale': 'declarative = describe the "what," not the "how."'}, {'num': 5, 'domain': "Domain 2: Understand Terraform's Purpose (vs other IaC) (~5%)", 'question': 'How does Terraform differ from configuration management tools like Ansible or Chef?', 'options': {'A': 'Terraform is primarily used for provisioning infrastructure, while CM tools focus on configuring software on existing servers', 'B': 'Terraform cannot manage cloud resources', 'C': 'Ansible requires a state file, Terraform does not', 'D': 'There is no meaningful difference'}, 'answer': 'A', 'rationale': 'Terraform provisions infra; Ansible/Chef configure software on hosts.'}, {'num': 6, 'domain': "Domain 2: Understand Terraform's Purpose (vs other IaC) (~5%)", 'question': "Which of the following is a key advantage of Terraform's multi-cloud support?", 'options': {'A': 'It automatically migrates resources between providers', 'B': 'A single workflow and language can manage resources across multiple providers', 'C': 'It removes the need for provider-specific credentials', 'D': 'It only supports AWS and Azure'}, 'answer': 'B', 'rationale': 'one workflow/language, many providers.'}, {'num': 7, 'domain': "Domain 2: Understand Terraform's Purpose (vs other IaC) (~5%)", 'question': 'What is a key difference between mutable and immutable infrastructure paradigms, and where does Terraform typically fit?', 'options': {'A': 'Terraform only supports mutable infrastructure', 'B': 'Terraform can support both, but is often used to replace resources rather than patch them in place, favoring immutability', 'C': 'Immutable infrastructure cannot be described in code', 'D': 'Mutable infrastructure requires no state tracking'}, 'answer': 'B', 'rationale': 'Terraform commonly replaces rather than patches resources.'}, {'num': 8, 'domain': "Domain 2: Understand Terraform's Purpose (vs other IaC) (~5%)", 'question': 'Why might a team choose Terraform over a cloud-specific tool like AWS CloudFormation?', 'options': {'A': 'CloudFormation is faster in all cases', 'B': 'Terraform provides a cloud-agnostic workflow usable across multiple providers and services', 'C': 'CloudFormation cannot create VPCs', 'D': 'Terraform does not support AWS'}, 'answer': 'B', 'rationale': 'cloud-agnostic workflow is the differentiator vs. CloudFormation.'}, {'num': 9, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What are the three main sections typically found in a Terraform configuration file?', 'options': {'A': 'Providers, resources, and modules only', 'B': 'Terraform settings block, providers, and resources/data sources (plus optional variables/outputs)', 'C': 'Only resources', 'D': 'Backend, provider, and outputs only'}, 'answer': 'B', 'rationale': 'terraform block + providers + resources/data sources form the core.'}, {'num': 10, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What is the purpose of a Terraform provider?', 'options': {'A': 'It stores the state file', 'B': 'It is a plugin that lets Terraform interact with an API (cloud platform, SaaS, etc.)', 'C': 'It compiles the Terraform binary', 'D': 'It only manages variables'}, 'answer': 'B', 'rationale': 'providers are plugins that talk to an API.'}, {'num': 11, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'Where are providers typically declared for version constraints in modern Terraform?', 'options': {'A': 'In the `provider` block only', 'B': 'In the `required_providers` block inside `terraform {}`', 'C': 'In `variables.tf`', 'D': 'In the state file'}, 'answer': 'B', 'rationale': '`required_providers` inside `terraform {}`.'}, {'num': 12, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What does the following version constraint mean? `version = "~> 4.16"`', 'options': {'A': 'Any version greater than 4.16', 'B': 'Only version 4.16 exactly', 'C': 'Any version >= 4.16.0 and < 4.17.0 (allows patch-level updates only)', 'D': 'Any version below 4.16'}, 'answer': 'C', 'rationale': '`~>` pessimistic constraint allows patch upgrades only, for `~> 4.16` (implicitly `4.16.x`).'}, {'num': 13, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': "What happens if you don't specify a version constraint for a provider?", 'options': {'A': 'Terraform will refuse to run', 'B': 'Terraform will download the latest version available at init time', 'C': 'Terraform uses version 1.0.0 by default', 'D': 'It causes a syntax error'}, 'answer': 'B', 'rationale': 'no constraint = latest available at init time.'}, {'num': 14, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What is the correct syntax to reference an attribute from a resource named `aws_instance.web`?', 'options': {'A': '`aws_instance[web]`', 'B': '`aws_instance.web.id`', 'C': '`resource.aws_instance.web`', 'D': '`web.aws_instance.id`'}, 'answer': 'B', 'rationale': '`<TYPE>.<NAME>.<ATTRIBUTE>`.'}, {'num': 15, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What is a Terraform "data source" used for?', 'options': {'A': 'To create new infrastructure', 'B': 'To fetch read-only information about existing infrastructure or external data, for use elsewhere in configuration', 'C': 'To store the state file remotely', 'D': 'To define input variables'}, 'answer': 'B', 'rationale': 'data sources are read-only lookups.'}, {'num': 16, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'Which block type would you use to expose a value from a root module for use by other configurations or the CLI?', 'options': {'A': '`variable`', 'B': '`output`', 'C': '`local`', 'D': '`data`'}, 'answer': 'B', 'rationale': '`output` blocks expose values.'}, {'num': 17, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What is the difference between an input variable and a local value in Terraform?', 'options': {'A': 'There is no difference', 'B': 'Input variables are parameters supplied to a module; locals are computed/named values reused within a module and not meant to be set externally', 'C': 'Local values can be set on the CLI with `-var`', 'D': 'Input variables cannot have default values'}, 'answer': 'B', 'rationale': 'variables are external inputs; locals are internal computed names.'}, {'num': 18, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'Which file, if present, does Terraform automatically load to set variable values without needing `-var-file`?', 'options': {'A': '`main.tf`', 'B': '`terraform.tfvars`', 'C': '`outputs.tf`', 'D': '`providers.tf`'}, 'answer': 'B', 'rationale': '`terraform.tfvars` auto-loads.'}, {'num': 19, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What is the correct order of precedence (highest to lowest) for variable value sources in Terraform?', 'options': {'A': 'Environment variables > tfvars files > CLI `-var` flags > defaults', 'B': 'CLI `-var`/`-var-file` flags > `*.auto.tfvars` > `terraform.tfvars` > environment variables (`TF_VAR_`) > defaults', 'C': 'Defaults always win', 'D': '`terraform.tfvars` always overrides CLI flags'}, 'answer': 'B', 'rationale': 'CLI flags > auto.tfvars > terraform.tfvars > env vars > defaults.'}, {'num': 20, 'domain': 'Domain 3: Understand Terraform Basics (~15%)', 'question': 'What does HCL stand for?', 'options': {'A': 'HashiCorp Configuration Language', 'B': 'High-level Cloud Language', 'C': 'Hosted Configuration Layer', 'D': 'Hybrid Cloud Language'}, 'answer': 'A', 'rationale': 'HashiCorp Configuration Language.'}, {'num': 21, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What does `terraform fmt` do?', 'options': {'A': 'Formats the state file', 'B': 'Rewrites configuration files to a canonical style and formatting', 'C': 'Validates provider credentials', 'D': 'Deletes unused resources'}, 'answer': 'B', 'rationale': "`fmt` rewrites style, doesn't touch state."}, {'num': 22, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What is the purpose of `terraform validate`?', 'options': {'A': 'It checks configuration syntax and internal consistency without accessing remote services', 'B': 'It applies the configuration', 'C': 'It formats code', 'D': 'It checks cloud provider billing'}, 'answer': 'A', 'rationale': '`validate` checks syntax/internal consistency, no API calls.'}, {'num': 23, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'Which command would you use to see a list of resources currently tracked in the state?', 'options': {'A': '`terraform show`', 'B': '`terraform state list`', 'C': '`terraform plan`', 'D': '`terraform get`'}, 'answer': 'B', 'rationale': '`terraform state list`.'}, {'num': 24, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What does `terraform taint` (or its modern replacement) do?', 'options': {'A': 'Deletes a resource from the state permanently with no replacement', 'B': 'Marks a resource for recreation on the next apply', 'C': 'Locks the state file', 'D': 'Formats the configuration'}, 'answer': 'B', 'rationale': 'taint marks for recreation on next apply.'}, {'num': 25, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'In modern Terraform (0.15.2+), what is the recommended replacement for `terraform taint`?', 'options': {'A': '`terraform destroy -target`', 'B': '`terraform apply -replace="resource.address"`', 'C': '`terraform refresh`', 'D': '`terraform state rm`'}, 'answer': 'B', 'rationale': '`terraform apply -replace=`.'}, {'num': 26, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What does `terraform console` allow you to do?', 'options': {'A': 'Deploy resources interactively', 'B': 'Evaluate expressions and inspect values in an interactive REPL against the current state', 'C': 'Edit the state file directly', 'D': 'SSH into a provisioned instance'}, 'answer': 'B', 'rationale': 'console is an interactive expression evaluator.'}, {'num': 27, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What is the function of `terraform graph`?', 'options': {'A': 'Generates a visual representation of the dependency graph of resources', 'B': 'Shows billing graphs', 'C': 'Formats HCL as a diagram', 'D': 'Displays CPU usage of resources'}, 'answer': 'A', 'rationale': '`graph` visualizes the dependency graph.'}, {'num': 28, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What does the `-target` flag do when used with `terraform apply`?', 'options': {'A': 'Applies changes to a specific remote backend', 'B': 'Restricts the apply/plan operation to a specific resource and its dependencies', 'C': 'Targets a specific workspace only', 'D': 'Selects a specific provider version'}, 'answer': 'B', 'rationale': '`-target` restricts scope to a resource + its dependencies.'}, {'num': 29, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'Why is `-target` generally discouraged for routine use?', 'options': {'A': "It's deprecated and no longer works", 'B': "It can produce a state that's inconsistent with the full configuration if used repeatedly instead of as a targeted exception", 'C': 'It always destroys resources', 'D': 'It requires root permissions'}, 'answer': 'B', 'rationale': "repeated use risks state/config drift; it's meant as an exception, not routine practice."}, {'num': 30, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What does `terraform output` do by default?', 'options': {'A': 'Applies pending changes', 'B': 'Displays the values of output variables defined in the root module', 'C': 'Lists all providers', 'D': 'Deletes all outputs'}, 'answer': 'B', 'rationale': '`output` prints root module output values.'}, {'num': 31, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'Which command initializes a working directory containing Terraform configuration files, downloading providers and modules?', 'options': {'A': '`terraform plan`', 'B': '`terraform init`', 'C': '`terraform get`', 'D': '`terraform validate`'}, 'answer': 'B', 'rationale': '`init` sets up the working directory.'}, {'num': 32, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What is the purpose of the `-upgrade` flag with `terraform init`?', 'options': {'A': 'Upgrades the Terraform CLI binary itself', 'B': 'Upgrades provider and module versions to the latest allowed by constraints, updating the lock file', 'C': 'Upgrades the state file format', 'D': 'Upgrades the OS'}, 'answer': 'B', 'rationale': '`-upgrade` updates providers/modules within constraints and updates the lock file.'}, {'num': 33, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'What does `terraform import` do?', 'options': {'A': 'Creates new resources matching configuration', 'B': 'Brings an existing, manually-created resource under Terraform management by adding it to the state', 'C': 'Imports variable definitions from another file', 'D': 'Downloads provider plugins'}, 'answer': 'B', 'rationale': 'import attaches existing infra to state only.'}, {'num': 34, 'domain': 'Domain 4: Use the Terraform CLI (Outside of Core Workflow) (~15%)', 'question': 'After running `terraform import`, what additional manual step is required?', 'options': {'A': 'Nothing further is needed', 'B': 'You must write a matching resource configuration block yourself, since import only updates state, not configuration', 'C': 'You must run `terraform destroy` immediately', 'D': 'You must delete the state file'}, 'answer': 'B', 'rationale': 'you must hand-write matching config after import.'}, {'num': 35, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'What is a Terraform module?', 'options': {'A': 'A single resource block', 'B': 'A container for multiple resources used together, referenced as a reusable unit of configuration', 'C': 'A type of provider', 'D': 'A state file backup'}, 'answer': 'B', 'rationale': 'module = reusable container of resources.'}, {'num': 36, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'What is the "root module" in a Terraform configuration?', 'options': {'A': 'The first module ever created', 'B': 'The configuration files in the main working directory that Terraform runs against', 'C': 'A module stored in the Terraform Registry', 'D': 'A module with no resources'}, 'answer': 'B', 'rationale': "root module = the main working directory's config."}, {'num': 37, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'How do you call a module from a local path in configuration?', 'options': {'A': '`module "example" { source = "app.terraform.io/example" }`', 'B': '`module "example" { source = "./modules/example" }`', 'C': '`import "example" { path = "./modules/example" }`', 'D': '`provider "example" { path = "./modules/example" }`'}, 'answer': 'B', 'rationale': 'local path source uses `./` or `../` prefix.'}, {'num': 38, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'What format is used to reference a module hosted on the public Terraform Registry?', 'options': {'A': '`source = "github.com/user/repo"` only', 'B': '`source = "<NAMESPACE>/<NAME>/<PROVIDER>"`', 'C': '`source = "registry://module"`', 'D': '`source = "local://module"`'}, 'answer': 'B', 'rationale': '`<NAMESPACE>/<NAME>/<PROVIDER>` registry format.'}, {'num': 39, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'How do you pass a value into a module from the calling configuration?', 'options': {'A': 'Modules cannot accept inputs', 'B': 'By setting an argument inside the `module` block that matches a `variable` declared in the module', 'C': "By editing the module's source code directly every time", 'D': 'Through the state file only'}, 'answer': 'B', 'rationale': "inputs are passed as arguments matching the module's declared variables."}, {'num': 40, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'How do you reference an output value from a child module in the calling (parent) configuration?', 'options': {'A': '`output.module_name.value`', 'B': '`module.<module_name>.<output_name>`', 'C': '`child.<module_name>.<output_name>`', 'D': "Outputs can't be referenced outside the module"}, 'answer': 'B', 'rationale': '`module.<name>.<output>`.'}, {'num': 41, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'What does module versioning (e.g. `version = "~> 2.0"`) apply to?', 'options': {'A': 'Only local modules', 'B': "Modules sourced from a registry (local path and some other sources don't support version constraints)", 'C': 'The Terraform CLI version', 'D': 'The provider version'}, 'answer': 'B', 'rationale': 'version constraints apply to registry-sourced modules (not local paths).'}, {'num': 42, 'domain': 'Domain 5: Interact with Terraform Modules (~10%)', 'question': 'Why are modules considered a best practice for larger Terraform codebases?', 'options': {'A': 'They eliminate the need for state', 'B': 'They encapsulate and reuse configuration, reducing duplication and standardizing patterns', 'C': 'They remove the need for variables', 'D': 'They bypass the need for provider blocks'}, 'answer': 'B', 'rationale': 'reuse/standardization/reduced duplication.'}, {'num': 43, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What is the correct standard Terraform workflow order?', 'options': {'A': 'Apply -> Plan -> Init', 'B': 'Init -> Plan -> Apply', 'C': 'Plan -> Init -> Apply', 'D': 'Apply -> Init -> Plan'}, 'answer': 'B', 'rationale': 'init -> plan -> apply.'}, {'num': 44, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What does `terraform plan` do?', 'options': {'A': 'Applies changes immediately', 'B': 'Creates an execution plan showing what actions Terraform will take, without making changes', 'C': 'Destroys existing infrastructure', 'D': 'Downloads providers'}, 'answer': 'B', 'rationale': "plan previews, doesn't change anything."}, {'num': 45, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What is the purpose of saving a plan to a file with `terraform plan -out=tfplan`?', 'options': {'A': 'It has no practical purpose', 'B': 'It lets you apply that exact, reviewed plan later with `terraform apply tfplan`, avoiding drift between plan and apply', 'C': 'It backs up the state file', 'D': 'It formats the configuration'}, 'answer': 'B', 'rationale': 'saved plan guarantees exactly what was reviewed gets applied.'}, {'num': 46, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'In a team/CI setting, why is applying a saved plan file considered safer than running `terraform apply` directly?', 'options': {'A': "It's not safer, they're identical", 'B': "It guarantees the applied changes exactly match what was reviewed/approved, since the plan can't silently change between review and apply", 'C': 'It skips the need for a backend', 'D': 'It removes the need for state locking'}, 'answer': 'B', 'rationale': 'prevents drift between review and execution, important in CI/CD.'}, {'num': 47, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What does `terraform apply -auto-approve` do differently from a plain `terraform apply`?', 'options': {'A': 'It skips generating a plan', 'B': 'It skips the interactive approval prompt and applies the plan automatically', 'C': 'It only works in CI', 'D': 'It ignores the state file'}, 'answer': 'B', 'rationale': 'skips the manual "yes" prompt.'}, {'num': 48, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What happens during `terraform destroy`?', 'options': {'A': 'It only deletes local files', 'B': 'Terraform destroys all resources tracked in the state file for the current configuration/workspace', 'C': 'It deletes the provider plugins only', 'D': 'It resets variables to default'}, 'answer': 'B', 'rationale': 'destroy removes everything tracked in state for that config/workspace.'}, {'num': 49, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'How can you destroy only a specific resource instead of the whole configuration?', 'options': {'A': '`terraform destroy -target=<resource_address>`', 'B': '`terraform destroy` always destroys everything, no exceptions', 'C': '`terraform apply -target` only', 'D': 'Manually edit the state file first'}, 'answer': 'A', 'rationale': '`-target` works with destroy too, for scoped deletion.'}, {'num': 50, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What is the purpose of the refresh step that occurs as part of `terraform plan`?', 'options': {'A': 'It reformats configuration files', 'B': 'It reconciles the state file with real infrastructure to detect drift before computing the plan', 'C': 'It re-downloads providers', 'D': 'It regenerates the lock file'}, 'answer': 'B', 'rationale': 'refresh reconciles state with real infra before planning.'}, {'num': 51, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What does Terraform do if it detects that real infrastructure has drifted from the state (e.g., someone manually changed a resource)?', 'options': {'A': 'It silently ignores the difference', 'B': 'It shows the drift in the plan output and proposes changes to reconcile config, state, and real infrastructure', 'C': 'It automatically deletes the resource', 'D': 'It crashes with an unrecoverable error'}, 'answer': 'B', 'rationale': 'drift is surfaced in the plan, with proposed reconciling changes.'}, {'num': 52, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'Which workflow step would catch a syntax error in a `.tf` file before contacting any provider APIs?', 'options': {'A': '`terraform apply`', 'B': '`terraform validate` (also caught earlier by `terraform plan`/`init`)', 'C': '`terraform destroy`', 'D': '`terraform state list`'}, 'answer': 'B', 'rationale': 'validate (and plan, which calls it) catches syntax errors early.'}, {'num': 53, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'What is the purpose of `terraform apply` after a plan is generated interactively (without `-out`)?', 'options': {'A': 'It re-runs `init`', 'B': 'It re-computes a fresh plan and prompts for approval before applying it', 'C': 'It automatically applies without any plan', 'D': 'It skips state updates'}, 'answer': 'B', 'rationale': 'apply re-plans and prompts unless given a saved plan file.'}, {'num': 54, 'domain': 'Domain 6: Navigate Terraform Workflow (~15%)', 'question': 'Why does Terraform generally recommend running `plan` before every `apply` rather than skipping straight to apply?', 'options': {'A': "It's a legacy requirement with no real benefit", 'B': 'It lets you review exactly what will change before it happens, reducing the risk of unintended modifications', 'C': "It's required for provider authentication", 'D': 'It updates the CLI version'}, 'answer': 'B', 'rationale': 'reviewing before applying reduces risk of unintended changes.'}, {'num': 55, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What is the primary purpose of the Terraform state file?', 'options': {'A': 'To store provider credentials', 'B': 'To map real-world resources to your configuration and track metadata/dependencies', 'C': 'To store variable defaults only', 'D': 'To act as a backup of `.tf` files'}, 'answer': 'B', 'rationale': 'state maps config to real resources + tracks metadata/dependencies.'}, {'num': 56, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What is a "backend" in Terraform?', 'options': {'A': 'The provider plugin binary', 'B': 'The mechanism that determines where and how state is stored (local or remote)', 'C': 'A type of module', 'D': 'The CLI itself'}, 'answer': 'B', 'rationale': 'backend = where/how state is stored.'}, {'num': 57, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'Why is remote state generally preferred over local state for team environments?', 'options': {'A': "It's faster to write to disk", 'B': 'It enables shared access, locking, and avoids conflicts from multiple people applying simultaneously', 'C': 'It removes the need for `terraform init`', 'D': 'It eliminates the need for version control'}, 'answer': 'B', 'rationale': 'shared access + locking avoids team conflicts.'}, {'num': 58, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What problem does state locking solve?', 'options': {'A': 'It prevents unauthorized read access to state', 'B': 'It prevents concurrent operations from corrupting the state file by writing to it at the same time', 'C': 'It encrypts the state file', 'D': 'It compresses the state file'}, 'answer': 'B', 'rationale': 'locking prevents concurrent writes corrupting state.'}, {'num': 59, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'Which backend types commonly support state locking? (choose the best answer)', 'options': {'A': 'None do', 'B': 'Backends like AWS S3 (with DynamoDB), Azure Storage, Google Cloud Storage, and HCP Terraform/Terraform Enterprise support locking', 'C': 'Only the local backend', 'D': 'Only HCP Terraform'}, 'answer': 'B', 'rationale': 'S3+DynamoDB, Azure Storage, GCS, HCP Terraform all support locking.'}, {'num': 60, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What command would you use to move a resource from one state address to another (e.g., after renaming it in configuration) without destroying/recreating it?', 'options': {'A': '`terraform import`', 'B': '`terraform state mv`', 'C': '`terraform state rm`', 'D': '`terraform refresh`'}, 'answer': 'B', 'rationale': '`terraform state mv` re-addresses without destroy/recreate.'}, {'num': 61, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What does `terraform state rm` do?', 'options': {'A': 'Deletes the real infrastructure resource', 'B': "Removes a resource from Terraform's state without destroying the actual infrastructure", 'C': 'Deletes the entire state file', 'D': 'Removes a provider'}, 'answer': 'B', 'rationale': "`state rm` detaches from state only, doesn't touch real infra."}, {'num': 62, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'Why should you generally avoid manually editing the state file with a text editor?', 'options': {'A': "State files aren't in JSON so they can't be edited", 'B': 'Manual edits can easily corrupt the state, causing mismatches with real infrastructure; `terraform state` subcommands are the supported way to modify it', 'C': 'The state file is read-only by the OS', 'D': "It's not possible to open the file"}, 'answer': 'B', 'rationale': 'manual edits risk corrupting state; use `terraform state` commands.'}, {'num': 63, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What does `terraform state list` output?', 'options': {'A': 'A list of variables', 'B': 'A list of resource addresses currently tracked in the state', 'C': 'A list of available providers', 'D': 'A list of output values'}, 'answer': 'B', 'rationale': 'lists resource addresses in state.'}, {'num': 64, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What sensitive information can commonly end up in the Terraform state file?', 'options': {'A': 'Only resource names', 'B': 'Potentially sensitive attribute values (like passwords or keys) in plaintext, unless the backend/state encryption mitigates this', 'C': 'Nothing sensitive is ever stored in state', 'D': 'Only provider names'}, 'answer': 'B', 'rationale': 'sensitive attribute values can appear in plaintext in state.'}, {'num': 65, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What is the purpose of the `sensitive = true` argument on a variable or output?', 'options': {'A': 'It encrypts the value in the state file', 'B': "It suppresses the value from CLI output (plan/apply/output), though it's still stored in state", 'C': 'It prevents the value from being stored in state entirely', 'D': 'It deletes the value after apply'}, 'answer': 'B', 'rationale': "`sensitive = true` hides values from CLI output, but they're still in state (unencrypted by default)."}, {'num': 66, 'domain': 'Domain 7: Implement and Maintain State (~15%)', 'question': 'What happens if two team members run `terraform apply` at the same time against the same remote state with locking enabled?', 'options': {'A': 'Both applies succeed simultaneously', 'B': 'The second apply is blocked/fails until the first operation releases the lock', 'C': 'The state file is duplicated', 'D': 'Terraform automatically merges both changes'}, 'answer': 'B', 'rationale': 'the second operation is blocked until the lock releases.'}, {'num': 67, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does the `count` meta-argument do on a resource block?', 'options': {'A': "Sets the resource's numeric ID", 'B': 'Creates multiple instances of a resource based on an integer, indexed by `count.index`', 'C': 'Limits the resource to a maximum count', 'D': 'Sets a billing quota'}, 'answer': 'B', 'rationale': '`count` creates N instances, indexed via `count.index`.'}, {'num': 68, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does `for_each` allow that `count` does not, when creating multiple resource instances?', 'options': {'A': "Nothing, they're functionally identical", 'B': 'Creating instances keyed by a map or set of strings, so instances are identified by key rather than numeric index (more stable when the collection changes)', 'C': '`for_each` can only be used with modules, not resources', 'D': '`for_each` is deprecated'}, 'answer': 'B', 'rationale': '`for_each` keys instances by map/set value, more stable under collection changes.'}, {'num': 69, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'Given `variable "env" { type = string }`, what does the `type` constraint enforce?', 'options': {'A': 'Nothing, types are purely cosmetic', 'B': 'That the value assigned to the variable must be a string, or Terraform will error/attempt conversion', 'C': "The variable's default value only", 'D': 'Only affects the CLI, not `plan`/`apply`'}, 'answer': 'B', 'rationale': 'type constraints are enforced (Terraform errors or attempts conversion).'}, {'num': 70, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does the `lookup()` function do?', 'options': {'A': 'Retrieves a value from a map by key, with an optional default if the key is absent', 'B': 'Looks up a resource in the state', 'C': 'Validates a provider version', 'D': 'Searches the Terraform Registry'}, 'answer': 'A', 'rationale': '`lookup(map, key, default)`.'}, {'num': 71, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does a `dynamic` block allow you to do in Terraform configuration?', 'options': {'A': 'Dynamically change the provider at runtime', 'B': 'Programmatically generate repeated nested configuration blocks (like multiple `ingress` blocks) from a collection', 'C': 'Dynamically resize the state file', 'D': 'Enable auto-scaling on cloud resources'}, 'answer': 'B', 'rationale': '`dynamic` blocks generate repeated nested blocks from a collection.'}, {'num': 72, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What is the purpose of `depends_on`?', 'options': {'A': "It's used to declare provider dependencies only", 'B': "It explicitly declares a dependency between resources/modules when Terraform can't infer it automatically from references", 'C': 'It sets the order of variables', 'D': 'It locks resource versions'}, 'answer': 'B', 'rationale': "`depends_on` makes an implicit dependency explicit when references alone don't capture it."}, {'num': 73, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'In most cases, how does Terraform determine the order to create/update/destroy resources?', 'options': {'A': 'Alphabetical order of resource names', 'B': 'Implicitly, by building a dependency graph from references between resources in configuration', 'C': 'Random order', 'D': 'The order resources appear in the file, always'}, 'answer': 'B', 'rationale': 'dependency graph built from references in config.'}, {'num': 74, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does the `terraform.workspace` expression return?', 'options': {'A': 'The path to the working directory', 'B': 'The name of the currently selected workspace', 'C': 'The Terraform CLI version', 'D': 'The backend type'}, 'answer': 'B', 'rationale': 'returns the current workspace name.'}, {'num': 75, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What is a common use case for Terraform workspaces?', 'options': {'A': 'Storing secrets', 'B': 'Managing multiple distinct states (e.g., dev/staging) from the same configuration, each with isolated state', 'C': 'Formatting code differently per environment', 'D': 'Replacing modules entirely'}, 'answer': 'B', 'rationale': 'isolating state per environment from shared config.'}, {'num': 76, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does the `terraform.tfvars.json` file allow compared to `terraform.tfvars`?', 'options': {'A': "Nothing different, they're identical in every way", 'B': 'The same variable-definition purpose, but expressed in JSON syntax instead of HCL', 'C': "It's used only for outputs", 'D': 'It stores state instead of variables'}, 'answer': 'B', 'rationale': 'same purpose, JSON syntax instead of HCL.'}, {'num': 77, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does the `try()` function do?', 'options': {'A': 'Runs a resource in "dry run" mode', 'B': "Evaluates a list of expressions and returns the first one that doesn't produce an error", 'C': 'Retries a failed apply automatically', 'D': 'Validates provider credentials'}, 'answer': 'B', 'rationale': "`try()` returns the first expression that doesn't error."}, {'num': 78, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What is the difference between `variable` default values and using `coalesce()`?', 'options': {'A': 'They are the same thing', 'B': 'A default applies only when no value is supplied for that variable; `coalesce()` picks the first non-null value from a list of expressions at evaluation time', 'C': '`coalesce()` only works on resources', 'D': "Defaults can't be overridden, `coalesce()` can"}, 'answer': 'B', 'rationale': 'default = fallback when unset; `coalesce()` = first non-null among given expressions.'}, {'num': 79, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does the `templatefile()` function do?', 'options': {'A': 'Creates a new `.tf` file', 'B': 'Renders a template file with the given variables, returning the result as a string', 'C': 'Templates a provider block', 'D': 'Copies a file to the module directory'}, 'answer': 'B', 'rationale': 'renders a template file into a string.'}, {'num': 80, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What is a "precondition" or "postcondition" block (custom conditions) used for in Terraform?', 'options': {'A': 'Formatting output', 'B': 'Validating assumptions about resource/variable values, causing a plan/apply error with a custom message if violated', 'C': 'Setting default variable values', 'D': 'Locking the state file'}, 'answer': 'B', 'rationale': 'custom conditions validate assumptions, erroring with a custom message if violated.'}, {'num': 81, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'In an expression like `var.instance_count > 0 ? "yes" : "no"`, what Terraform language feature is being used?', 'options': {'A': 'A `for` expression', 'B': 'A conditional (ternary) expression', 'C': 'A `dynamic` block', 'D': 'A `lifecycle` block'}, 'answer': 'B', 'rationale': 'ternary conditional expression.'}, {'num': 82, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does a `for` expression like `[for s in var.list : upper(s)]` produce?', 'options': {'A': 'A single string', 'B': 'A new list with each element transformed by `upper()`', 'C': 'A map', 'D': 'A boolean'}, 'answer': 'B', 'rationale': '`for` expression transforms into a new list.'}, {'num': 83, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What is the purpose of the `lifecycle` block argument `prevent_destroy = true`?', 'options': {'A': 'It prevents any changes to the resource whatsoever', 'B': 'It causes Terraform to reject any plan that would destroy that resource', 'C': 'It disables state tracking for the resource', 'D': 'It backs up the resource automatically'}, 'answer': 'B', 'rationale': '`prevent_destroy` blocks any plan that would destroy the resource.'}, {'num': 84, 'domain': 'Domain 8: Read, Generate, and Modify Configuration (~20%)', 'question': 'What does `create_before_destroy = true` inside a `lifecycle` block change about resource replacement?', 'options': {'A': "Nothing, it's the default behavior", 'B': 'The new resource is created before the old one is destroyed, instead of the default destroy-then-create order', 'C': 'It prevents replacement entirely', 'D': 'It only applies to modules'}, 'answer': 'B', 'rationale': 'create_before_destroy flips the default destroy-then-create order.'}, {'num': 85, 'domain': 'Domain 9: HCP Terraform (Terraform Cloud) Capabilities (~10%)', 'question': 'What is HCP Terraform (formerly Terraform Cloud) primarily used for?', 'options': {'A': 'Only local state storage', 'B': 'A managed service providing remote state, remote runs, VCS integration, policy enforcement, and collaboration features for teams', 'C': 'Replacing the Terraform CLI entirely', 'D': 'Only for billing management'}, 'answer': 'B', 'rationale': 'HCP Terraform = managed remote state/runs/VCS/policy/collaboration.'}, {'num': 86, 'domain': 'Domain 9: HCP Terraform (Terraform Cloud) Capabilities (~10%)', 'question': 'What is a "workspace" in HCP Terraform (as distinct from CLI workspaces)?', 'options': {'A': 'The same concept with the same scope as CLI `terraform workspace`', 'B': 'A more fully-featured unit that bundles configuration, variables, state, and run history, typically mapped to one deployable configuration', 'C': 'A billing plan tier', 'D': 'A provider plugin cache'}, 'answer': 'B', 'rationale': 'HCP Terraform workspaces bundle config, vars, state, run history.'}, {'num': 87, 'domain': 'Domain 9: HCP Terraform (Terraform Cloud) Capabilities (~10%)', 'question': "What does Sentinel (or HCP Terraform's policy-as-code features) allow an organization to do?", 'options': {'A': 'Format Terraform code automatically', 'B': "Enforce policy checks (e.g., cost, security, compliance rules) on runs before they're applied", 'C': 'Replace the state backend', 'D': 'Manage DNS records'}, 'answer': 'B', 'rationale': 'Sentinel/policy-as-code enforces rules before runs apply.'}, {'num': 88, 'domain': 'Domain 9: HCP Terraform (Terraform Cloud) Capabilities (~10%)', 'question': "How does HCP Terraform's remote execution mode differ from running Terraform locally?", 'options': {'A': 'There is no difference', 'B': "Runs (plan/apply) execute on HCP Terraform's infrastructure rather than your local machine, with state and logs centrally managed", 'C': 'Remote execution disables state locking', 'D': 'It only supports `plan`, never `apply`'}, 'answer': 'B', 'rationale': "remote execution runs plan/apply on HCP Terraform's infra, not locally."}]


def load_questions(args):
    if args.file:
        path = args.file
    else:
        local_json = os.path.join(os.path.dirname(os.path.abspath(__file__)), "questions.json")
        path = local_json if os.path.exists(local_json) else None

    if path:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        print(f"[loaded {len(data)} questions from {path}]")
        return data
    return QUESTIONS


def filter_and_select(questions, args):
    qs = questions
    if args.domain:
        needle = args.domain.lower()
        qs = [q for q in qs if needle in q["domain"].lower()]
        if not qs:
            print(f"No questions matched domain filter: '{args.domain}'")
            sys.exit(1)

    if args.shuffle:
        qs = qs[:]
        random.shuffle(qs)

    if args.num:
        qs = qs[: args.num]

    return qs


def ask_question(i, total, q):
    print("\n" + "-" * 70)
    print(f"Question {i}/{total}   [{q['domain'].split(':')[0]}]")
    print("-" * 70)
    print(q["question"])
    for opt_letter in ["A", "B", "C", "D"]:
        print(f"  {opt_letter}) {q['options'][opt_letter]}")

    while True:
        try:
            ans = input("\nYour answer (A/B/C/D, or 's' to skip, 'q' to quit): ").strip().upper()
        except EOFError:
            return "QUIT"
        if ans in ("A", "B", "C", "D"):
            return ans
        if ans == "S":
            return None
        if ans == "Q":
            return "QUIT"
        print("Please enter A, B, C, D, s (skip), or q (quit).")


def run_quiz(questions):
    results = []
    total = len(questions)
    print(f"\nStarting quiz: {total} questions. Answer A/B/C/D, 's' to skip, 'q' to quit early.\n")

    for i, q in enumerate(questions, start=1):
        ans = ask_question(i, total, q)
        if ans == "QUIT":
            print("\nQuiz ended early by user.")
            break
        correct = q["answer"]
        is_correct = (ans == correct)
        results.append({
            "num": q["num"],
            "domain": q["domain"],
            "question": q["question"],
            "options": q["options"],
            "your_answer": ans,
            "correct_answer": correct,
            "is_correct": is_correct,
            "rationale": q["rationale"],
        })

    return results


def print_summary(results):
    attempted = [r for r in results if r["your_answer"] is not None]
    correct_count = sum(1 for r in attempted if r["is_correct"])
    skipped = [r for r in results if r["your_answer"] is None]

    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)
    if attempted:
        pct = 100 * correct_count / len(attempted)
        print(f"Score: {correct_count}/{len(attempted)} attempted ({pct:.1f}%)")
    else:
        print("No questions were attempted.")
    if skipped:
        print(f"Skipped: {len(skipped)}")

    domain_stats = {}
    for r in attempted:
        d = r["domain"].split(":")[0]
        domain_stats.setdefault(d, [0, 0])
        domain_stats[d][1] += 1
        if r["is_correct"]:
            domain_stats[d][0] += 1

    if domain_stats:
        print("\nBy domain:")
        for d, (c, t) in sorted(domain_stats.items()):
            print(f"  {d}: {c}/{t}")


def generate_pdf(results, outdir):
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
    )

    os.makedirs(outdir, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_path = os.path.join(outdir, f"terraform_quiz_result_{timestamp}.pdf")

    attempted = [r for r in results if r["your_answer"] is not None]
    correct = [r for r in attempted if r["is_correct"]]
    wrong = [r for r in attempted if not r["is_correct"]]
    skipped = [r for r in results if r["your_answer"] is None]

    styles = getSampleStyleSheet()
    title_style = styles["Title"]
    h2 = styles["Heading2"]
    normal = ParagraphStyle("normal", parent=styles["Normal"], fontSize=10, leading=14)
    q_style = ParagraphStyle("qstyle", parent=styles["Normal"], fontSize=11, leading=15,
                              spaceBefore=6, spaceAfter=4, textColor=colors.black)
    opt_correct = ParagraphStyle("opt_correct", parent=normal, textColor=colors.HexColor("#1a7a1a"))
    opt_wrong = ParagraphStyle("opt_wrong", parent=normal, textColor=colors.HexColor("#b00020"))
    rationale_style = ParagraphStyle("rationale", parent=normal, textColor=colors.HexColor("#444444"),
                                      spaceBefore=2, spaceAfter=10, leftIndent=10)

    story = []
    story.append(Paragraph("Terraform Associate 004 - Mock Quiz Result", title_style))
    story.append(Paragraph(datetime.datetime.now().strftime("%d %b %Y, %I:%M %p"), normal))
    story.append(Spacer(1, 16))

    # ---- Summary ----
    story.append(Paragraph("Summary", h2))
    score_pct = f"{100 * len(correct) / len(attempted):.1f}%" if attempted else "N/A"
    summary_data = [
        ["Total questions attempted", str(len(attempted))],
        ["Correct", str(len(correct))],
        ["Wrong", str(len(wrong))],
        ["Skipped", str(len(skipped))],
        ["Score", score_pct],
    ]
    summary_table = Table(summary_data, colWidths=[3 * inch, 2 * inch])
    summary_table.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f0f0f0")),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(summary_table)
    story.append(Spacer(1, 16))

    # ---- Domain breakdown ----
    domain_stats = {}
    for r in attempted:
        d = r["domain"].split(":")[0]
        domain_stats.setdefault(d, [0, 0])
        domain_stats[d][1] += 1
        if r["is_correct"]:
            domain_stats[d][0] += 1

    if domain_stats:
        story.append(Paragraph("Score by Domain", h2))
        domain_data = [["Domain", "Correct", "Attempted", "%"]]
        for d, (c, t) in sorted(domain_stats.items()):
            pct = f"{100 * c / t:.0f}%" if t else "N/A"
            domain_data.append([d, str(c), str(t), pct])
        domain_table = Table(domain_data, colWidths=[2.2 * inch, 1 * inch, 1 * inch, 0.8 * inch])
        domain_table.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfe7f5")),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(domain_table)
        story.append(Spacer(1, 16))

    # ---- Wrong answers detail ----
    story.append(PageBreak())
    story.append(Paragraph(f"Review: Wrong Answers ({len(wrong)})", h2))
    if not wrong:
        story.append(Paragraph("None - nice work.", normal))
    for r in wrong:
        story.append(Paragraph(f"Q{r['num']}. {r['question']}", q_style))
        for opt_letter in ["A", "B", "C", "D"]:
            text = f"{opt_letter}) {r['options'][opt_letter]}"
            if opt_letter == r["correct_answer"]:
                story.append(Paragraph(text + "  [correct answer]", opt_correct))
            elif opt_letter == r["your_answer"]:
                story.append(Paragraph(text + "  [your answer]", opt_wrong))
            else:
                story.append(Paragraph(text, normal))
        story.append(Paragraph(f"Why: {r['rationale']}", rationale_style))

    # ---- Skipped questions detail ----
    if skipped:
        story.append(PageBreak())
        story.append(Paragraph(f"Review: Skipped Questions ({len(skipped)})", h2))
        for r in skipped:
            story.append(Paragraph(f"Q{r['num']}. {r['question']}", q_style))
            for opt_letter in ["A", "B", "C", "D"]:
                text = f"{opt_letter}) {r['options'][opt_letter]}"
                if opt_letter == r["correct_answer"]:
                    story.append(Paragraph(text + "  [correct answer]", opt_correct))
                else:
                    story.append(Paragraph(text, normal))
            story.append(Paragraph(f"Why: {r['rationale']}", rationale_style))

    # ---- Correct answers (brief list, for completeness) ----
    if correct:
        story.append(PageBreak())
        story.append(Paragraph(f"Correctly Answered ({len(correct)})", h2))
        for r in correct:
            story.append(Paragraph(f"Q{r['num']}. {r['question']} -> {r['correct_answer']}", normal))

    doc = SimpleDocTemplate(pdf_path, pagesize=letter,
                             topMargin=0.7 * inch, bottomMargin=0.7 * inch,
                             leftMargin=0.7 * inch, rightMargin=0.7 * inch)
    doc.build(story)
    return pdf_path


def main():
    parser = argparse.ArgumentParser(description="Terraform Associate 004 mock quiz")
    parser.add_argument("--shuffle", action="store_true", help="shuffle question order")
    parser.add_argument("--num", type=int, default=None, help="attempt only N questions")
    parser.add_argument("--domain", type=str, default=None, help="filter by domain name substring")
    parser.add_argument("--file", type=str, default=None, help="load questions from an external JSON file")
    parser.add_argument("--outdir", type=str, default="results", help="folder to save the PDF report in")
    args = parser.parse_args()

    all_questions = load_questions(args)
    selected = filter_and_select(all_questions, args)

    results = []
    try:
        results = run_quiz(selected)
    except KeyboardInterrupt:
        print("\n\nInterrupted - generating report for what you completed so far...")
    except Exception as e:
        print(f"\n\n[Unexpected error during quiz: {e}]")
        print("Generating a report for what you completed so far...")

    if results:
        print_summary(results)
        try:
            pdf_path = generate_pdf(results, args.outdir)
            print(f"\nDetailed PDF report saved to: {os.path.abspath(pdf_path)}")
        except Exception as e:
            print(f"\n[Could not generate PDF report: {e}]")
    else:
        print("No questions attempted - nothing to report.")


if __name__ == "__main__":
    main()
